# Order Processing System

A self-contained Java application for processing customer orders. It validates orders, calculates discounts and taxes, and generates formatted order summaries. Designed to demonstrate complex business logic with high cyclomatic complexity, cross-class orchestration, and collection-based workflows.

## Complexity Summary

- **Number of classes**: 10 production classes
- **Total public methods**: 25 (including constructors but excluding getters? Actually counted: App.main, Customer: getId, getName, isPremium, getLoyaltyPoints, isEligibleForDiscount (5), Product: getId, getName, getBasePrice, getCategory (4), OrderItem: getProduct, getQuantity, getLineTotal (3), Order: getOrderId, getCustomer, getItems, getSubtotal (4), OrderValidator: validate (1), DiscountCalculator: calculateDiscount (1), TaxCalculator: calculateTax, getTaxRate (2 public? getTaxRate is private, so 1 public), PriceCalculator: calculateBreakdown (1), PriceBreakdown: getSubtotal, getDiscount, getTax, getTotal (4), OrderFormatter: format (1), OrderService: processOrder, applyPromotion (2) => total 5+4+3+4+1+1+1+1+4+1+2 = 27. Plus constructors? We'll consider only methods as per requirement. So ~27 public methods.)
- **Methods with >= 3 branches**: 5+ (validate in OrderValidator, calculateDiscount, applyPromotion, getTaxRate (switch with 5 cases, count as >=3), processOrder (has if-else) )
- **Class descriptions**:
  - `App`: Entry point; creates sample order and processes it.
  - `Customer`: Represents a customer with loyalty points and premium status.
  - `Product`: Product with base price and category.
  - `OrderItem`: Line item linking product and quantity.
  - `Order`: Order container with customer and items; computes subtotal.
  - `OrderValidator`: Validates orders with multiple rules and edge cases.
  - `DiscountCalculator`: Calculates discounts based on subtotal tiers, customer status, and item quantities.
  - `TaxCalculator`: Computes tax based on product categories (switch).
  - `PriceCalculator`: Orchestrates discount and tax to produce a price breakdown.
  - `OrderFormatter`: Formats order details into a readable string.
  - `OrderService`: Main orchestrator that validates, calculates prices, and formats output; also has promotion logic with state.