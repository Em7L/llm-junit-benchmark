package com.example.app.model;

public class Customer {
    private final String id;
    private final String name;
    private final boolean premium;
    private final int loyaltyPoints;

    public Customer(String id, String name, boolean premium, int loyaltyPoints) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Customer ID must not be blank");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Customer name must not be blank");
        }
        if (loyaltyPoints < 0) {
            throw new IllegalArgumentException("Loyalty points cannot be negative");
        }
        this.id = id;
        this.name = name;
        this.premium = premium;
        this.loyaltyPoints = loyaltyPoints;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public boolean isPremium() { return premium; }
    public int getLoyaltyPoints() { return loyaltyPoints; }

    public boolean isEligibleForDiscount() {
        return premium || loyaltyPoints > 100;
    }
}