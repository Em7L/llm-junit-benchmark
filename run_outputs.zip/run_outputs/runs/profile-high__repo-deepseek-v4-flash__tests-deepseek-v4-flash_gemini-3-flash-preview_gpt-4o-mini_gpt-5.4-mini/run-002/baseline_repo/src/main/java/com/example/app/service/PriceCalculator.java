package com.example.app.service;

import com.example.app.model.Order;

public class PriceCalculator {

    private final DiscountCalculator discountCalculator;
    private final TaxCalculator taxCalculator;

    public PriceCalculator() {
        this.discountCalculator = new DiscountCalculator();
        this.taxCalculator = new TaxCalculator();
    }

    public PriceBreakdown calculateBreakdown(Order order) {
        double subtotal = order.getSubtotal();
        double discount = discountCalculator.calculateDiscount(order);
        double afterDiscount = subtotal - discount;
        double tax = taxCalculator.calculateTax(order, afterDiscount);
        double total = afterDiscount + tax;

        // Edge case: if after discount negative (should not happen), clamp
        if (afterDiscount < 0) {
            afterDiscount = 0;
            total = tax;
        }

        // Boundary check ensuring total is not negative
        if (total < 0) {
            total = 0;
        }

        return new PriceBreakdown(subtotal, discount, tax, total);
    }

    public static class PriceBreakdown {
        private final double subtotal;
        private final double discount;
        private final double tax;
        private final double total;

        public PriceBreakdown(double subtotal, double discount, double tax, double total) {
            this.subtotal = subtotal;
            this.discount = discount;
            this.tax = tax;
            this.total = total;
        }

        public double getSubtotal() { return subtotal; }
        public double getDiscount() { return discount; }
        public double getTax() { return tax; }
        public double getTotal() { return total; }
    }
}