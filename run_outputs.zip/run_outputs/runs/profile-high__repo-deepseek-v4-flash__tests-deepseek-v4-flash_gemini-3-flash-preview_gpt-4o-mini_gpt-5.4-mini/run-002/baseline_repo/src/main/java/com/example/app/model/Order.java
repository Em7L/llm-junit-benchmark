package com.example.app.model;

import java.util.Collections;
import java.util.List;

public class Order {
    private final String orderId;
    private final Customer customer;
    private final List<OrderItem> items;

    public Order(String orderId, Customer customer, List<OrderItem> items) {
        if (orderId == null || orderId.isBlank()) {
            throw new IllegalArgumentException("Order ID must not be blank");
        }
        if (customer == null) {
            throw new IllegalArgumentException("Customer must not be null");
        }
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Order must have at least one item");
        }
        this.orderId = orderId;
        this.customer = customer;
        this.items = Collections.unmodifiableList(items);
    }

    public String getOrderId() { return orderId; }
    public Customer getCustomer() { return customer; }
    public List<OrderItem> getItems() { return items; }

    public double getSubtotal() {
        return items.stream()
                .mapToDouble(OrderItem::getLineTotal)
                .sum();
    }
}