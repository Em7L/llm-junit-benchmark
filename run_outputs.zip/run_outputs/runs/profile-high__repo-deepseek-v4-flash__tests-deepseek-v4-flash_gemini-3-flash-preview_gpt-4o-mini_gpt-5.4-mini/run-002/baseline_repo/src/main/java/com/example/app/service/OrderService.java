package com.example.app.service;

import com.example.app.model.*;
import com.example.app.service.PriceCalculator.PriceBreakdown;

import java.util.List;

public class OrderService {

    private final OrderValidator validator;
    private final PriceCalculator priceCalculator;
    private final OrderFormatter formatter;

    public OrderService() {
        this.validator = new OrderValidator();
        this.priceCalculator = new PriceCalculator();
        this.formatter = new OrderFormatter();
    }

    public String processOrder(Order order) {
        // Step 1: Validate
        List<String> errors = validator.validate(order);
        if (!errors.isEmpty()) {
            StringBuilder sb = new StringBuilder("Order validation failed:\n");
            for (String err : errors) {
                sb.append(" - ").append(err).append("\n");
            }
            return sb.toString();
        }

        // Step 2: Calculate price breakdown (involves discount, tax)
        PriceBreakdown breakdown = priceCalculator.calculateBreakdown(order);

        // Step 3: Format and return
        return formatter.format(order, breakdown);
    }

    // Method that returns different results based on state built from prior calls
    // Here we simulate a promotion that depends on order history (but we don't have history, so we use a flag)
    private boolean promotionApplied = false;

    public String applyPromotion(Order order, String promoCode) {
        if (promotionApplied) {
            return "Promotion already applied to this session";
        }
        // Complex decision logic
        if (promoCode == null || promoCode.isBlank()) {
            return "No promo code provided";
        }
        if (!promoCode.startsWith("PROMO")) {
            return "Invalid promo code format";
        }
        // Check order total
        if (order.getSubtotal() < 50) {
            return "Order total too low for promotion";
        }
        // Multi-condition
        if (order.getCustomer().isPremium() && order.getSubtotal() > 200 && promoCode.length() == 10) {
            promotionApplied = true;
            return "Premium promotion applied: extra 10% discount";
        } else if (order.getCustomer().getLoyaltyPoints() > 500 && promoCode.endsWith("VIP")) {
            promotionApplied = true;
            return "VIP promotion applied: free shipping";
        } else {
            return "Promotion conditions not met";
        }
    }
}