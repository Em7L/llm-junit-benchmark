package com.example.app.service;

import com.example.app.model.*;

import java.util.ArrayList;
import java.util.List;

public class OrderValidator {

    public List<String> validate(Order order) {
        List<String> errors = new ArrayList<>();

        // Check customer eligibility
        if (order.getCustomer() == null) {
            errors.add("Customer is null");
        } else {
            Customer c = order.getCustomer();
            if (c.getName() == null || c.getName().isBlank()) {
                errors.add("Customer name is blank");
            }
            if (c.getLoyaltyPoints() < 0) {
                errors.add("Loyalty points cannot be negative");
            }
            // Additional complex checks
            if (c.isPremium() && c.getLoyaltyPoints() > 0 && c.getLoyaltyPoints() % 10 == 0) {
                // Special validation for premium customers with round loyalty points
            }
        }

        // Validate order items
        if (order.getItems() == null || order.getItems().isEmpty()) {
            errors.add("Order has no items");
        } else {
            for (OrderItem item : order.getItems()) {
                if (item.getProduct() == null) {
                    errors.add("Order item has null product");
                } else {
                    Product p = item.getProduct();
                    if (p.getBasePrice() <= 0) {
                        errors.add("Product " + p.getId() + " has non-positive base price");
                    }
                    if (p.getCategory() == null || p.getCategory().isBlank()) {
                        errors.add("Product " + p.getId() + " has blank category");
                    }
                    if (item.getQuantity() <= 0) {
                        errors.add("Product " + p.getId() + " has non-positive quantity");
                    }
                    // Nested condition for high-value items
                    if (item.getLineTotal() > 1000 && p.getCategory().equals("Electronics") && !p.getName().contains("Pro")) {
                        errors.add("High-value electronics without 'Pro' require additional approval");
                    }
                }
                // Another condition: check quantity boundary
                if (item.getQuantity() > 100) {
                    errors.add("Quantity for product " + item.getProduct().getId() + " exceeds limit of 100");
                }
            }
        }

        // Check order totals (multi-condition)
        if (order.getSubtotal() <= 0 && order.getItems() != null && !order.getItems().isEmpty()) {
            errors.add("Subtotal is zero or negative despite having items");
        }

        // Edge case: order with only one item but very specific conditions
        if (order.getItems() != null && order.getItems().size() == 1) {
            OrderItem onlyItem = order.getItems().get(0);
            if (onlyItem.getProduct() != null && onlyItem.getProduct().getCategory().equals("Books") && onlyItem.getQuantity() == 1) {
                // Special case for single book order
                if (order.getCustomer() != null && !order.getCustomer().isPremium()) {
                    errors.add("Single book order by non-premium customer requires manager approval");
                }
            }
        }

        return errors;
    }
}