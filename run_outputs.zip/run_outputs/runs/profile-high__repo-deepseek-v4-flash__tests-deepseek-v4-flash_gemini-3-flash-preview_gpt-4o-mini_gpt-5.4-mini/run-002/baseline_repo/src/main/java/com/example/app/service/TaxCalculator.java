package com.example.app.service;

import com.example.app.model.*;

public class TaxCalculator {

    public double calculateTax(Order order, double amountAfterDiscount) {
        double totalTax = 0.0;
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            double itemPrice = product.getBasePrice() * item.getQuantity();
            double taxRate = getTaxRate(product.getCategory());
            totalTax += itemPrice * taxRate;
        }
        // Tax is applied to the original item prices, not discounted amount
        // But we can also compute on after-discount proportionally? For simplicity, use original.
        return totalTax;
    }

    private double getTaxRate(String category) {
        return switch (category) {
            case "Electronics" -> 0.08;
            case "Books" -> 0.05;
            case "Clothing" -> 0.12;
            case "Food" -> 0.0;
            default -> 0.10;
        };
    }
}