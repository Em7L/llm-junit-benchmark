package com.example.app.service;

import com.example.app.model.*;

import java.util.List;

public class DiscountCalculator {

    public double calculateDiscount(Order order) {
        double totalDiscount = 0.0;
        Customer customer = order.getCustomer();
        List<OrderItem> items = order.getItems();
        double subtotal = order.getSubtotal();

        // Tiered discount based on subtotal
        if (subtotal > 1000) {
            totalDiscount += subtotal * 0.10;
        } else if (subtotal > 500) {
            totalDiscount += subtotal * 0.05;
        } else if (subtotal > 100) {
            totalDiscount += subtotal * 0.02;
        }

        // Additional discount for premium customers
        if (customer.isPremium()) {
            totalDiscount += subtotal * 0.03;
        }

        // Loyalty points discount: each 100 points gives 1% discount
        int points = customer.getLoyaltyPoints();
        if (points >= 100) {
            int hundredBlocks = points / 100;
            double loyaltyDiscount = Math.min(hundredBlocks * 0.01 * subtotal, subtotal * 0.15); // cap at 15%
            totalDiscount += loyaltyDiscount;
        }

        // Item-specific discounts: for items with quantity >= 5, apply 5% on that item
        for (OrderItem item : items) {
            if (item.getQuantity() >= 5) {
                double itemDiscount = item.getLineTotal() * 0.05;
                // But only if product is not already heavily discounted elsewhere? Not needed.
                totalDiscount += itemDiscount;
            }
        }

        // Boundary check: discount cannot exceed subtotal
        if (totalDiscount > subtotal) {
            totalDiscount = subtotal;
        }

        return totalDiscount;
    }
}