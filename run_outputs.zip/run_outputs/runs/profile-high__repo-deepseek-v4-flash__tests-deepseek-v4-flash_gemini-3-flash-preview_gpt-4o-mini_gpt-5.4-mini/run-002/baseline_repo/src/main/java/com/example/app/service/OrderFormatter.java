package com.example.app.service;

import com.example.app.model.*;
import com.example.app.service.PriceCalculator.PriceBreakdown;

public class OrderFormatter {

    public String format(Order order, PriceBreakdown breakdown) {
        StringBuilder sb = new StringBuilder();
        sb.append("Order ID: ").append(order.getOrderId()).append("\n");
        sb.append("Customer: ").append(order.getCustomer().getName()).append(" (").append(order.getCustomer().getId()).append(")\n");
        sb.append("Items:\n");
        for (OrderItem item : order.getItems()) {
            sb.append("  - ").append(item.getProduct().getName())
              .append(" x ").append(item.getQuantity())
              .append(" @ ").append(String.format("$%.2f", item.getProduct().getBasePrice()))
              .append(" = ").append(String.format("$%.2f", item.getLineTotal()))
              .append("\n");
        }
        sb.append("\nSubtotal: ").append(String.format("$%.2f", breakdown.getSubtotal())).append("\n");
        sb.append("Discount: ").append(String.format("$%.2f", breakdown.getDiscount())).append("\n");
        sb.append("Tax: ").append(String.format("$%.2f", breakdown.getTax())).append("\n");
        sb.append("Total: ").append(String.format("$%.2f", breakdown.getTotal())).append("\n");
        return sb.toString();
    }
}