package com.example.app.model;

public class Product {
    private final String id;
    private final String name;
    private final double basePrice;
    private final String category;

    public Product(String id, String name, double basePrice, String category) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Product ID must not be blank");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name must not be blank");
        }
        if (basePrice <= 0) {
            throw new IllegalArgumentException("Base price must be positive");
        }
        if (category == null || category.isBlank()) {
            throw new IllegalArgumentException("Category must not be blank");
        }
        this.id = id;
        this.name = name;
        this.basePrice = basePrice;
        this.category = category;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getBasePrice() { return basePrice; }
    public String getCategory() { return category; }
}