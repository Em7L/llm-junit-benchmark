package com.example.app;

import com.example.app.model.*;
import com.example.app.service.*;

import java.util.List;

public class App {
    public static void main(String[] args) {
        Customer customer = new Customer("C001", "John Doe", true, 5);
        Product product1 = new Product("P001", "Widget", 25.0, "Electronics");
        Product product2 = new Product("P002", "Gadget", 50.0, "Electronics");
        Product product3 = new Product("P003", "Book", 15.0, "Books");

        List<OrderItem> items = List.of(
                new OrderItem(product1, 3),
                new OrderItem(product2, 1),
                new OrderItem(product3, 2)
        );

        Order order = new Order("O001", customer, items);

        OrderService orderService = new OrderService();
        String result = orderService.processOrder(order);
        System.out.println(result);
    }
}