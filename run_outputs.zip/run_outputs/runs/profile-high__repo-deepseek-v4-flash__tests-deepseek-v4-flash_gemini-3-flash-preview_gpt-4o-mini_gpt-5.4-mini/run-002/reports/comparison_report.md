# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-002/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_partially_improved | 1 |
| deepseek-v4-flash | passed | repair_successful | 1 |
| gemini-3-flash-preview | passed | repair_successful | 1 |
| gpt-4o-mini | passed | repair_not_needed | 0 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 20 | 4 | 0 | 71.62% | 68.63% | 150 | 108 | 18 | 24 | 72.00% |
| deepseek-v4-flash | test_failures | 75 | 3 | 2 | 89.19% | 81.70% | 150 | 129 | 18 | 3 | 86.00% |
| gemini-3-flash-preview | test_failures | 15 | 1 | 1 | 78.83% | 59.48% | 150 | 100 | 33 | 17 | 66.67% |
| gpt-4o-mini | passed | 7 | 0 | 0 | 7.66% | 7.84% | 150 | 12 | 3 | 135 | 8.00% |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 20 | 1 | 0 | 88.29% | 75.16% | 150 | 122 | 22 | 6 | 81.33% |
| deepseek-v4-flash | passed | 72 | 0 | 0 | 89.19% | 81.70% | 150 | 129 | 18 | 3 | 86.00% |
| gemini-3-flash-preview | passed | 15 | 0 | 0 | 82.43% | 63.40% | 150 | 107 | 33 | 10 | 71.33% |
| gpt-4o-mini | passed | 7 | 0 | 0 | 7.66% | 7.84% | 150 | 12 | 3 | 135 | 8.00% |

## Mutant Set Consistency
- Comparable PIT suites: `7`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `150`
- Union mutant IDs: `150`
- `_final_selected/deepseek-v4-flash` mutant IDs: `150`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `150`
- `_final_selected/gpt-4o-mini` mutant IDs: `150`
- `_final_selected/gpt-5.4-mini` mutant IDs: `150`
- `_initial_snapshot/deepseek-v4-flash` mutant IDs: `150`
- `_initial_snapshot/gemini-3-flash-preview` mutant IDs: `150`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `150`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `repair_not_needed`: The initial generated test suite already passed verification, so no repair attempt was needed.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.