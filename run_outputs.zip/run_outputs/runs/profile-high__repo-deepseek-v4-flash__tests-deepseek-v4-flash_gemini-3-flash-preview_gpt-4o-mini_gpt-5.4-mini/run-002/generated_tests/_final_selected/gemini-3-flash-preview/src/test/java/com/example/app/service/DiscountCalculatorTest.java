package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class DiscountCalculatorTest {
    private final DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void calculateTieredDiscounts() {
        Customer c = new Customer("C1", "N", false, 0);
        Product p = new Product("P1", "N", 100.0, "Other");

        // > 100 (2%): Subtotal 200 * 0.02 = 4.0. No bulk discount (quantity < 5).
        Order o1 = new Order("O1", c, List.of(new OrderItem(p, 2)));
        assertEquals(4.0, calculator.calculateDiscount(o1), 0.001);

        // > 500 (5%): Subtotal 600 * 0.05 = 30.0. 
        // PLUS Bulk discount: Quantity 6 >= 5, so 600 * 0.05 = 30.0.
        // Total = 30.0 + 30.0 = 60.0.
        Order o2 = new Order("O2", c, List.of(new OrderItem(p, 6)));
        assertEquals(60.0, calculator.calculateDiscount(o2), 0.001);

        // > 1000 (10%): Subtotal 1100 * 0.10 = 110.0.
        // PLUS Bulk discount: Quantity 11 >= 5, so 1100 * 0.05 = 55.0.
        // Total = 110.0 + 55.0 = 165.0.
        Order o3 = new Order("O3", c, List.of(new OrderItem(p, 11)));
        assertEquals(165.0, calculator.calculateDiscount(o3), 0.001);
    }

    @Test
    void loyaltyAndPremiumStackedDiscounts() {
        Customer c = new Customer("C1", "N", true, 250);
        Product p = new Product("P1", "N", 50.0, "Other");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1)));
        // Subtotal 50. Tiered: 0. Premium: 50 * 0.03 = 1.5. Loyalty (2 blocks): 2 * 0.01 * 50 = 1.0. Total: 2.5
        assertEquals(2.5, calculator.calculateDiscount(o), 0.001);
    }

    @Test
    void bulkQuantityDiscount() {
        Customer c = new Customer("C1", "N", false, 0);
        Product p = new Product("P1", "N", 10.0, "Other");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 5)));
        // Subtotal 50. Tiered: 0. Bulk: 50 * 0.05 = 2.5.
        assertEquals(2.5, calculator.calculateDiscount(o), 0.001);
    }
}