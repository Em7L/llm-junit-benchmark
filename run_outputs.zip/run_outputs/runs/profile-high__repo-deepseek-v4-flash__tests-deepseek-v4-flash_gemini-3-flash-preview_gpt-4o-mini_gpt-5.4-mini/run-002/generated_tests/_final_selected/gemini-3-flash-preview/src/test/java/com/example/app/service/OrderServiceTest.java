package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    @Test
    void processOrderReturnsFormattedSuccessString() {
        OrderService service = new OrderService();
        Customer c = new Customer("C001", "Alice", true, 0);
        Product p = new Product("P001", "Widget", 100.0, "Electronics");
        Order o = new Order("O001", c, List.of(new OrderItem(p, 1)));

        String result = service.processOrder(o);

        assertTrue(result.contains("Order ID: O001"));
        assertTrue(result.contains("Customer: Alice"));
        assertTrue(result.contains("Total:"));
    }

    @Test
    void processOrderReturnsErrorsOnValidationFailure() {
        OrderService service = new OrderService();
        // Fixed: Use valid Customer constructor parameters, but cause business logic failure (Book order rule)
        Customer c = new Customer("C1", "Alice", false, 0);
        Product p = new Product("P1", "Book", 10.0, "Books");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1)));

        String result = service.processOrder(o);
        assertTrue(result.contains("Order validation failed"));
        assertTrue(result.contains("Single book order by non-premium customer requires manager approval"));
    }

    @Test
    void applyPromotionLogicAndState() {
        OrderService service = new OrderService();
        Customer c = new Customer("C1", "N", true, 600);
        Product p = new Product("P1", "N", 300.0, "Electronics");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1)));

        String res1 = service.applyPromotion(o, "PROMO12345");
        assertEquals("Premium promotion applied: extra 10% discount", res1);

        String res2 = service.applyPromotion(o, "PROMOVIP");
        assertEquals("Promotion already applied to this session", res2);
    }

    @Test
    void applyPromotionFailsForInvalidInputs() {
        OrderService service = new OrderService();
        Customer c = new Customer("C1", "N", false, 0);
        Product p = new Product("P1", "N", 10.0, "Electronics");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1)));

        assertEquals("No promo code provided", service.applyPromotion(o, ""));
        assertEquals("Invalid promo code format", service.applyPromotion(o, "SUMMER2023"));
        assertEquals("Order total too low for promotion", service.applyPromotion(o, "PROMO123"));
    }
}