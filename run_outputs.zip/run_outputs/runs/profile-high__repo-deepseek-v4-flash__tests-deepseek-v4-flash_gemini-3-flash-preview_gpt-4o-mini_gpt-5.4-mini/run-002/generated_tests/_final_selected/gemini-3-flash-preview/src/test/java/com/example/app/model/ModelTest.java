package com.example.app.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class ModelTest {
    @Test
    void customerConstructorValidatesInput() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "Name", false, 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer("ID", " ", false, 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer("ID", "Name", false, -1));
    }

    @Test
    void customerEligibilityChecks() {
        Customer regular = new Customer("C1", "Name", false, 50);
        Customer premium = new Customer("C2", "Name", true, 0);
        Customer highPoints = new Customer("C3", "Name", false, 101);

        assertFalse(regular.isEligibleForDiscount());
        assertTrue(premium.isEligibleForDiscount());
        assertTrue(highPoints.isEligibleForDiscount());
    }

    @Test
    void orderItemCalculatesLineTotal() {
        Product p = new Product("P1", "N", 10.0, "Cat");
        OrderItem item = new OrderItem(p, 3);
        assertEquals(30.0, item.getLineTotal());
    }

    @Test
    void orderSubtotalAggregation() {
        Customer c = new Customer("C1", "N", false, 0);
        Product p1 = new Product("P1", "N", 10.0, "Cat");
        Product p2 = new Product("P2", "N", 5.0, "Cat");
        Order order = new Order("O1", c, List.of(
            new OrderItem(p1, 2), 
            new OrderItem(p2, 1)
        ));
        assertEquals(25.0, order.getSubtotal());
    }
}