package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class TaxCalculatorTest {
    private final TaxCalculator calculator = new TaxCalculator();

    @Test
    void calculatesTaxBasedOnCategory() {
        Customer c = new Customer("C1", "N", false, 0);
        Product electronics = new Product("P1", "E", 100.0, "Electronics");
        Product books = new Product("P2", "B", 100.0, "Books");
        Product food = new Product("P3", "F", 100.0, "Food");
        
        Order o = new Order("O1", c, List.of(
            new OrderItem(electronics, 1), 
            new OrderItem(books, 1), 
            new OrderItem(food, 1)
        ));

        // (100 * 0.08) + (100 * 0.05) + (100 * 0.0) = 8 + 5 + 0 = 13
        assertEquals(13.0, calculator.calculateTax(o, 300.0), 0.001);
    }
}