package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {
    private final OrderValidator validator = new OrderValidator();

    @Test
    void rejectsHighValueElectronicsWithoutPro() {
        Customer c = new Customer("C1", "N", true, 0);
        Product p = new Product("P1", "Standard TV", 1500.0, "Electronics");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1)));
        
        List<String> errors = validator.validate(o);
        assertTrue(errors.stream().anyMatch(e -> e.contains("require additional approval")));
    }

    @Test
    void rejectsSingleBookForNonPremium() {
        Customer c = new Customer("C1", "N", false, 0);
        Product p = new Product("P1", "Book", 20.0, "Books");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1)));
        
        List<String> errors = validator.validate(o);
        assertTrue(errors.contains("Single book order by non-premium customer requires manager approval"));
    }

    @Test
    void rejectsExcessiveQuantity() {
        Customer c = new Customer("C1", "N", true, 0);
        Product p = new Product("P1", "Gadget", 10.0, "Electronics");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 101)));
        
        List<String> errors = validator.validate(o);
        assertTrue(errors.stream().anyMatch(e -> e.contains("exceeds limit of 100")));
    }
}