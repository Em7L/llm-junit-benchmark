package com.example.app.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorRejectsNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(null, "Name", false, 0));
    }

    @Test
    void constructorRejectsBlankId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "Name", false, 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer("   ", "Name", false, 0));
    }

    @Test
    void constructorRejectsNullName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", null, false, 0));
    }

    @Test
    void constructorRejectsBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "", false, 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "   ", false, 0));
    }

    @Test
    void constructorRejectsNegativeLoyaltyPoints() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Name", false, -1));
    }

    @Test
    void constructorAcceptsValidInput() {
        Customer c = new Customer("C1", "Name", true, 100);
        assertEquals("C1", c.getId());
        assertEquals("Name", c.getName());
        assertTrue(c.isPremium());
        assertEquals(100, c.getLoyaltyPoints());
    }

    @Test
    void isEligibleForDiscountReturnsTrueForPremium() {
        Customer c = new Customer("C1", "Name", true, 0);
        assertTrue(c.isEligibleForDiscount());
    }

    @Test
    void isEligibleForDiscountReturnsTrueForHighLoyalty() {
        Customer c = new Customer("C1", "Name", false, 101);
        assertTrue(c.isEligibleForDiscount());
    }

    @Test
    void isEligibleForDiscountReturnsFalseForLowLoyaltyNonPremium() {
        Customer c = new Customer("C1", "Name", false, 100);
        assertFalse(c.isEligibleForDiscount());
    }

    @Test
    void isEligibleForDiscountReturnsFalseForZeroLoyaltyNonPremium() {
        Customer c = new Customer("C1", "Name", false, 0);
        assertFalse(c.isEligibleForDiscount());
    }
}