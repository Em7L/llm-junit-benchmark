package com.example.app.model;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @Test
    void constructorRejectsNullOrderId() {
        Customer c = new Customer("C1", "Name", false, 0);
        List<OrderItem> items = Collections.singletonList(new OrderItem(new Product("P1", "Test", 10, "Cat"), 1));
        assertThrows(IllegalArgumentException.class, () -> new Order(null, c, items));
    }

    @Test
    void constructorRejectsBlankOrderId() {
        Customer c = new Customer("C1", "Name", false, 0);
        List<OrderItem> items = Collections.singletonList(new OrderItem(new Product("P1", "Test", 10, "Cat"), 1));
        assertThrows(IllegalArgumentException.class, () -> new Order("", c, items));
    }

    @Test
    void constructorRejectsNullCustomer() {
        List<OrderItem> items = Collections.singletonList(new OrderItem(new Product("P1", "Test", 10, "Cat"), 1));
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", null, items));
    }

    @Test
    void constructorRejectsNullItems() {
        Customer c = new Customer("C1", "Name", false, 0);
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", c, null));
    }

    @Test
    void constructorRejectsEmptyItems() {
        Customer c = new Customer("C1", "Name", false, 0);
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", c, Collections.emptyList()));
    }

    @Test
    void getSubtotalReturnsSumOfLineTotals() {
        Product p1 = new Product("P1", "A", 10, "Cat");
        Product p2 = new Product("P2", "B", 20, "Cat");
        OrderItem item1 = new OrderItem(p1, 2); // 20
        OrderItem item2 = new OrderItem(p2, 3); // 60
        Customer c = new Customer("C1", "Name", false, 0);
        Order order = new Order("O1", c, Arrays.asList(item1, item2));
        assertEquals(80.0, order.getSubtotal());
    }

    @Test
    void getItemsReturnsUnmodifiableList() {
        Product p = new Product("P1", "Test", 10, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Customer c = new Customer("C1", "Name", false, 0);
        Order order = new Order("O1", c, Collections.singletonList(item));
        List<OrderItem> items = order.getItems();
        assertThrows(UnsupportedOperationException.class, () -> items.add(item));
    }

    @Test
    void constructorSetsFields() {
        Customer c = new Customer("C1", "Name", true, 50);
        List<OrderItem> items = Collections.singletonList(new OrderItem(new Product("P1", "Test", 10, "Cat"), 1));
        Order order = new Order("O1", c, items);
        assertEquals("O1", order.getOrderId());
        assertSame(c, order.getCustomer());
        assertEquals(1, order.getItems().size());
    }
}