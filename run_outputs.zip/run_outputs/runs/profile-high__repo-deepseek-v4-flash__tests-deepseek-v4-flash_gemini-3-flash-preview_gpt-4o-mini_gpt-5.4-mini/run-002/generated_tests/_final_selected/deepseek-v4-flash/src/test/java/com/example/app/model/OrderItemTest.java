package com.example.app.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderItemTest {

    @Test
    void constructorRejectsNullProduct() {
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(null, 1));
    }

    @Test
    void constructorRejectsNonPositiveQuantity() {
        Product p = new Product("P1", "Test", 10, "Cat");
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(p, 0));
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(p, -1));
    }

    @Test
    void getLineTotalReturnsProductPriceTimesQuantity() {
        Product p = new Product("P1", "Test", 10, "Cat");
        OrderItem item = new OrderItem(p, 3);
        assertEquals(30.0, item.getLineTotal());
    }

    @Test
    void constructorSetsFieldsCorrectly() {
        Product p = new Product("P1", "Test", 10, "Cat");
        OrderItem item = new OrderItem(p, 5);
        assertSame(p, item.getProduct());
        assertEquals(5, item.getQuantity());
    }
}