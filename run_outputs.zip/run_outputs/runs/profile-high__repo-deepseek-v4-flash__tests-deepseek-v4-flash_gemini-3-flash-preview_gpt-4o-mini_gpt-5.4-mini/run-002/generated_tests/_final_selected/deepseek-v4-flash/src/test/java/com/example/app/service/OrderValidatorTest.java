package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {

    private final OrderValidator validator = new OrderValidator();

    @Test
    void noErrorsForValidOrder() {
        Customer customer = new Customer("C1", "John", true, 50);
        Product p = new Product("P1", "Widget", 25.0, "Electronics");
        OrderItem item = new OrderItem(p, 2);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertTrue(errors.isEmpty());
    }

    @Test
    void errorForQuantityOver100() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 10, "Cat");
        OrderItem item = new OrderItem(p, 101);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertTrue(errors.stream().anyMatch(e -> e.contains("exceeds limit")));
    }

    @Test
    void errorForHighValueElectronicsWithoutPro() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "TV", 1200, "Electronics"); // line total = 1200*1 = 1200 > 1000
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertTrue(errors.stream().anyMatch(e -> e.contains("additional approval")));
    }

    @Test
    void noErrorForHighValueElectronicsWithPro() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Pro TV", 1200, "Electronics");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertFalse(errors.stream().anyMatch(e -> e.contains("additional approval")));
    }

    @Test
    void errorForSingleBookByNonPremiumCustomer() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Book", 15, "Books");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertTrue(errors.stream().anyMatch(e -> e.contains("manager approval")));
    }

    @Test
    void noErrorForSingleBookByPremiumCustomer() {
        Customer customer = new Customer("C1", "John", true, 0);
        Product p = new Product("P1", "Book", 15, "Books");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertFalse(errors.stream().anyMatch(e -> e.contains("manager approval")));
    }

    @Test
    void noErrorForMultipleItemsEvenIfSingleBookNonPremium() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p1 = new Product("P1", "Book", 15, "Books");
        Product p2 = new Product("P2", "Pen", 2, "Stationery");
        OrderItem item1 = new OrderItem(p1, 1);
        OrderItem item2 = new OrderItem(p2, 1);
        Order order = new Order("O1", customer, Arrays.asList(item1, item2));
        List<String> errors = validator.validate(order);
        assertFalse(errors.stream().anyMatch(e -> e.contains("manager approval")));
    }

    @Test
    void noErrorForSubtotalZeroOrNegativeDespiteItems() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 0.01, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", customer, Collections.singletonList(item));
        List<String> errors = validator.validate(order);
        assertFalse(errors.stream().anyMatch(e -> e.contains("Subtotal is zero")));
    }
}
