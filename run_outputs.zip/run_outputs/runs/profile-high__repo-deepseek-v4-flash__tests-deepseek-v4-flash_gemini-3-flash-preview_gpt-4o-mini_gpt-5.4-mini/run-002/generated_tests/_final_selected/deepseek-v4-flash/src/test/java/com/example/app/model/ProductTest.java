package com.example.app.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void constructorRejectsNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Name", 10, "Cat"));
    }

    @Test
    void constructorRejectsBlankId() {
        assertThrows(IllegalArgumentException.class, () -> new Product("", "Name", 10, "Cat"));
    }

    @Test
    void constructorRejectsNullName() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", null, 10, "Cat"));
    }

    @Test
    void constructorRejectsBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "", 10, "Cat"));
    }

    @Test
    void constructorRejectsNonPositivePrice() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", -1, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 0, "Cat"));
    }

    @Test
    void constructorRejectsNullCategory() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 10, null));
    }

    @Test
    void constructorRejectsBlankCategory() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 10, ""));
    }

    @Test
    void constructorAcceptsValidInput() {
        Product p = new Product("P1", "Widget", 25.0, "Electronics");
        assertEquals("P1", p.getId());
        assertEquals("Widget", p.getName());
        assertEquals(25.0, p.getBasePrice());
        assertEquals("Electronics", p.getCategory());
    }
}