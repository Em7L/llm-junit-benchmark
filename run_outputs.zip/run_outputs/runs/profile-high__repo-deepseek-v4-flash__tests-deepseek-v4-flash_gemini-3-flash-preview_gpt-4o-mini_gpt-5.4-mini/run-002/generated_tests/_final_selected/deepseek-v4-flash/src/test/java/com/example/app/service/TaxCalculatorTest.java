package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

class TaxCalculatorTest {

    private final TaxCalculator calculator = new TaxCalculator();

    @Test
    void calculatesElectronicsTax() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Gadget", 100, "Electronics");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        double tax = calculator.calculateTax(order, 0); // second param unused in current impl
        assertEquals(100 * 0.08, tax, 1e-9);
    }

    @Test
    void calculatesBooksTax() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Novel", 20, "Books");
        OrderItem item = new OrderItem(p, 2);
        Order order = new Order("O1", c, Collections.singletonList(item));
        double tax = calculator.calculateTax(order, 0);
        assertEquals(40 * 0.05, tax, 1e-9);
    }

    @Test
    void calculatesClothingTax() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Shirt", 50, "Clothing");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        double tax = calculator.calculateTax(order, 0);
        assertEquals(50 * 0.12, tax, 1e-9);
    }

    @Test
    void calculatesFoodTaxFree() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Apple", 1, "Food");
        OrderItem item = new OrderItem(p, 10);
        Order order = new Order("O1", c, Collections.singletonList(item));
        double tax = calculator.calculateTax(order, 0);
        assertEquals(0.0, tax, 1e-9);
    }

    @Test
    void calculatesDefaultTaxForUnknownCategory() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Stuff", 100, "Other");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        double tax = calculator.calculateTax(order, 0);
        assertEquals(100 * 0.10, tax, 1e-9);
    }

    @Test
    void calculatesTaxForMultipleItems() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p1 = new Product("P1", "Laptop", 1000, "Electronics"); // 80 tax
        Product p2 = new Product("P2", "Book", 20, "Books"); // 1 tax
        OrderItem item1 = new OrderItem(p1, 1);
        OrderItem item2 = new OrderItem(p2, 1);
        Order order = new Order("O1", c, java.util.Arrays.asList(item1, item2));
        double tax = calculator.calculateTax(order, 0);
        assertEquals(80 + 1, tax, 1e-9);
    }
}