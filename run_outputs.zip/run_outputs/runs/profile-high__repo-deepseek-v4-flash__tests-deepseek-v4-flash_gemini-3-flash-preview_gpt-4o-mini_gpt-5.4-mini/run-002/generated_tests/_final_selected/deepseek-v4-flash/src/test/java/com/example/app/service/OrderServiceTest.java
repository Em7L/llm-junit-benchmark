package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    @Test
    void processOrderReturnsFormattedStringForValidOrder() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 100, "Electronics");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.processOrder(order);
        assertTrue(result.startsWith("Order ID: O1"));
        assertTrue(result.contains("Total:"));
    }

    @Test
    void processOrderReturnsErrorsForInvalidOrder() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 100, "Electronics");
        OrderItem item = new OrderItem(p, 101); // quantity > 100 triggers error
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.processOrder(order);
        assertTrue(result.startsWith("Order validation failed:"));
        assertTrue(result.contains("exceeds limit"));
    }

    @Test
    void applyPromotionReturnsNoPromoCodeIfNull() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 10, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.applyPromotion(order, null);
        assertEquals("No promo code provided", result);
    }

    @Test
    void applyPromotionReturnsInvalidFormatIfNotStartingWithPROMO() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 10, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.applyPromotion(order, "INVALID");
        assertEquals("Invalid promo code format", result);
    }

    @Test
    void applyPromotionReturnsLowTotalIfSubtotalBelow50() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Cheap", 10, "Cat");
        OrderItem item = new OrderItem(p, 1); // subtotal 10
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.applyPromotion(order, "PROMO1234");
        assertEquals("Order total too low for promotion", result);
    }

    @Test
    void applyPromotionPremiumPromotionSuccess() {
        Customer c = new Customer("C1", "John", true, 0); // premium
        Product p = new Product("P1", "Expensive", 300, "Cat");
        OrderItem item = new OrderItem(p, 1); // subtotal 300 > 200
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.applyPromotion(order, "PROMO12345"); // length 10? Actually "PROMO12345" is 10 characters
        // Must meet premium, subtotal>200, promo length==10 -> true
        assertEquals("Premium promotion applied: extra 10% discount", result);
    }

    @Test
    void applyPromotionVIPPromotionSuccess() {
        Customer c = new Customer("C1", "John", false, 600); // loyalty >500
        Product p = new Product("P1", "Item", 100, "Cat");
        OrderItem item = new OrderItem(p, 1); // subtotal 100 >=50
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.applyPromotion(order, "PROMO123VIP"); // ends with VIP
        assertEquals("VIP promotion applied: free shipping", result);
    }

    @Test
    void applyPromotionConditionsNotMet() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 100, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        String result = service.applyPromotion(order, "PROMO1234"); // meets length? length=9? Actually "PROMO1234" is 9, not 10, so not premium condition. Not VIP because not ends with VIP. Not premium because not premium? Actually customer not premium, so fail.
        assertEquals("Promotion conditions not met", result);
    }

    @Test
    void applyPromotionAlreadyApplied() {
        Customer c = new Customer("C1", "John", true, 0);
        Product p = new Product("P1", "Expensive", 300, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        OrderService service = new OrderService();
        service.applyPromotion(order, "PROMO12345"); // first call succeeds
        String result = service.applyPromotion(order, "PROMO12345"); // second call
        assertEquals("Promotion already applied to this session", result);
    }
}