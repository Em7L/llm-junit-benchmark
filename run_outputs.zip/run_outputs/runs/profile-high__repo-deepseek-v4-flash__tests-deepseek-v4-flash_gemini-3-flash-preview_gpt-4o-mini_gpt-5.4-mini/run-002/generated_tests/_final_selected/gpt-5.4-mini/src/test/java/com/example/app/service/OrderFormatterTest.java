package com.example.app.service;

import com.example.app.model.Customer;
import com.example.app.model.Order;
import com.example.app.model.OrderItem;
import com.example.app.model.Product;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

class OrderFormatterTest {

    @Test
    void formatIncludesOrderCustomerItemsAndTotals() {
        Customer customer = new Customer("C1", "John Doe", true, 5);
        Order order = new Order("O1", customer, List.of(
                new OrderItem(new Product("P1", "Widget", 25.0, "Electronics"), 2),
                new OrderItem(new Product("P2", "Book", 15.5, "Books"), 1)
        ));
        PriceCalculator.PriceBreakdown breakdown = new PriceCalculator.PriceBreakdown(65.5, 3.0, 3.4, 65.9);

        String output = new OrderFormatter().format(order, breakdown);

        assertTrue(output.contains("Order ID: O1"));
        assertTrue(output.contains("Customer: John Doe (C1)"));
        assertTrue(output.contains("Items:"));
        assertTrue(output.contains("Widget x 2"));
        assertTrue(output.contains("Book x 1"));
        assertTrue(output.contains("Subtotal:"));
        assertTrue(output.contains("Discount:"));
        assertTrue(output.contains("Tax:"));
        assertTrue(output.contains("Total:"));
        assertTrue(output.contains("65.50") || output.contains("65,50"));
        assertTrue(output.contains("3.00") || output.contains("3,00"));
        assertTrue(output.contains("3.40") || output.contains("3,40"));
        assertTrue(output.contains("65.90") || output.contains("65,90"));
    }
}
