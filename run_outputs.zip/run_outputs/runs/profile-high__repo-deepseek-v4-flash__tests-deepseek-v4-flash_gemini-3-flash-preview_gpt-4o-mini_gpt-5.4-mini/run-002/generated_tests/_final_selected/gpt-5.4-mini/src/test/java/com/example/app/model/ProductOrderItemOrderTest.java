package com.example.app.model;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProductOrderItemOrderTest {

    @Test
    void productConstructorValidatesFields() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Widget", 10.0, "Electronics"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", " ", 10.0, "Electronics"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Widget", 0.0, "Electronics"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Widget", 10.0, ""));
    }

    @Test
    void productAccessorsReturnValues() {
        Product product = new Product("P1", "Widget", 19.99, "Electronics");

        assertEquals("P1", product.getId());
        assertEquals("Widget", product.getName());
        assertEquals(19.99, product.getBasePrice(), 0.0001);
        assertEquals("Electronics", product.getCategory());
    }

    @Test
    void orderItemConstructorValidatesAndComputesLineTotal() {
        Product product = new Product("P1", "Widget", 12.5, "Books");
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(null, 1));
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(product, 0));

        OrderItem item = new OrderItem(product, 4);
        assertEquals(product, item.getProduct());
        assertEquals(4, item.getQuantity());
        assertEquals(50.0, item.getLineTotal(), 0.0001);
    }

    @Test
    void orderConstructorValidatesInputsAndSubtotalUsesLineTotals() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product p1 = new Product("P1", "Widget", 10.0, "Electronics");
        Product p2 = new Product("P2", "Book", 15.0, "Books");
        List<OrderItem> items = List.of(new OrderItem(p1, 2), new OrderItem(p2, 3));

        assertThrows(IllegalArgumentException.class, () -> new Order(" ", customer, items));
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", null, items));
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", customer, List.of()));

        Order order = new Order("O1", customer, items);
        assertEquals("O1", order.getOrderId());
        assertEquals(customer, order.getCustomer());
        assertEquals(2, order.getItems().size());
        assertEquals(65.0, order.getSubtotal(), 0.0001);
        assertTrue(order.getItems().containsAll(items));
    }
}
