package com.example.app.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CustomerTest {

    @Test
    void constructorRejectsBlankId() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Customer(" ", "John", false, 0));
        assertEquals("Customer ID must not be blank", ex.getMessage());
    }

    @Test
    void constructorRejectsBlankName() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Customer("C1", "", false, 0));
        assertEquals("Customer name must not be blank", ex.getMessage());
    }

    @Test
    void constructorRejectsNegativeLoyaltyPoints() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Customer("C1", "John", false, -1));
        assertEquals("Loyalty points cannot be negative", ex.getMessage());
    }

    @Test
    void accessorsReturnConstructorValuesAndEligibilityDependsOnPremiumOrPoints() {
        Customer premiumCustomer = new Customer("C1", "John", true, 0);
        assertEquals("C1", premiumCustomer.getId());
        assertEquals("John", premiumCustomer.getName());
        assertTrue(premiumCustomer.isPremium());
        assertEquals(0, premiumCustomer.getLoyaltyPoints());
        assertTrue(premiumCustomer.isEligibleForDiscount());

        Customer loyalCustomer = new Customer("C2", "Jane", false, 101);
        assertFalse(loyalCustomer.isPremium());
        assertTrue(loyalCustomer.isEligibleForDiscount());

        Customer regularCustomer = new Customer("C3", "Bob", false, 100);
        assertFalse(regularCustomer.isEligibleForDiscount());
    }
}
