package com.example.app.service;

import com.example.app.model.Customer;
import com.example.app.model.Order;
import com.example.app.model.OrderItem;
import com.example.app.model.Product;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OrderValidatorTest {

    private final OrderValidator validator = new OrderValidator();

    @Test
    void validOrderProducesNoErrors() {
        Customer customer = new Customer("C1", "John Doe", true, 120);
        Product product = new Product("P1", "Widget", 25.0, "Electronics");
        Order order = new Order("O1", customer, List.of(new OrderItem(product, 2)));

        assertEquals(List.of(), validator.validate(order));
    }

    @Test
    void detectsMultipleItemAndCustomerViolations() {
        Customer customer = new Customer("C1", "John Doe", false, 0);
        Product expensiveElectronics = new Product("P1", "Laptop", 200.0, "Electronics");
        Product bulkProduct = new Product("P2", "Gizmo", 1.0, "Food");
        Order order = new Order("O1", customer, List.of(
                new OrderItem(expensiveElectronics, 6),
                new OrderItem(bulkProduct, 101)
        ));

        List<String> errors = validator.validate(order);

        assertTrue(errors.contains("High-value electronics without 'Pro' require additional approval"));
        assertTrue(errors.contains("Quantity for product P2 exceeds limit of 100"));
    }

    @Test
    void flagsSingleBookOrderByNonPremiumCustomer() {
        Customer customer = new Customer("C1", "John Doe", false, 0);
        Product book = new Product("B1", "Novel", 20.0, "Books");
        Order order = new Order("O1", customer, List.of(new OrderItem(book, 1)));

        List<String> errors = validator.validate(order);

        assertTrue(errors.contains("Single book order by non-premium customer requires manager approval"));
    }

    @Test
    void flagsNullProductThroughItemList() {
        Customer customer = new Customer("C1", "John Doe", true, 0);
        OrderItem invalidItem = new OrderItem(new Product("P1", "Widget", 10.0, "Books"), 1) {
            @Override
            public Product getProduct() {
                return null;
            }
        };
        Order order = new Order("O1", customer, List.of(invalidItem));

        List<String> errors = validator.validate(order);
        assertTrue(errors.contains("Order item has null product"));
    }
}
