package com.example.app.service;

import com.example.app.model.Customer;
import com.example.app.model.Order;
import com.example.app.model.OrderItem;
import com.example.app.model.Product;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OrderServiceTest {

    @Test
    void processOrderReturnsValidationErrorsWhenInvalid() {
        Customer customer = new Customer("C1", "John", false, 0);
        Product book = new Product("B1", "Novel", 20.0, "Books");
        Order invalidOrder = new Order("O1", customer, List.of(new OrderItem(book, 1)));

        String result = new OrderService().processOrder(invalidOrder);

        assertTrue(result.startsWith("Order validation failed:"));
        assertTrue(result.contains("Single book order by non-premium customer requires manager approval"));
    }

    @Test
    void processOrderFormatsSuccessfulOrder() {
        Customer customer = new Customer("C1", "John Doe", true, 10);
        Order order = new Order("O1", customer, List.of(
                new OrderItem(new Product("P1", "Widget", 25.0, "Electronics"), 2),
                new OrderItem(new Product("P2", "Book", 15.0, "Books"), 1)
        ));

        String result = new OrderService().processOrder(order);

        assertTrue(result.contains("Order ID: O1"));
        assertTrue(result.contains("Customer: John Doe (C1)"));
        assertTrue(result.contains("Subtotal: $65.00") || result.contains("Subtotal: 65.00") || result.contains("Subtotal: $65,00"));
        assertTrue(result.contains("Discount: $1.95") || result.contains("Discount: 1.95") || result.contains("Discount: $1,95"));
        assertTrue(result.contains("Tax: $4.75") || result.contains("Tax: 4.75") || result.contains("Tax: $4,75"));
        assertTrue(result.contains("Total: $68.80") || result.contains("Total: 68.80") || result.contains("Total: $68,80"));
    }

    @Test
    void applyPromotionHandlesStateAndBranchConditions() {
        OrderService service = new OrderService();

        Customer premiumCustomer = new Customer("C1", "John", true, 0);
        Order premiumOrder = new Order("O1", premiumCustomer, List.of(new OrderItem(new Product("P1", "Widget", 100.0, "Electronics"), 3)));

        assertEquals("No promo code provided", service.applyPromotion(premiumOrder, null));
        assertEquals("Invalid promo code format", service.applyPromotion(premiumOrder, "BADCODE"));
        assertEquals("Premium promotion applied: extra 10% discount", service.applyPromotion(premiumOrder, "PROMO1234X"));
        assertEquals("Promotion already applied to this session", service.applyPromotion(premiumOrder, "PROMO1234X"));

        OrderService vipService = new OrderService();
        Customer vipCustomer = new Customer("C2", "Jane", false, 600);
        Order vipOrder = new Order("O2", vipCustomer, List.of(new OrderItem(new Product("P2", "Widget", 60.0, "Books"), 1)));
        assertEquals("VIP promotion applied: free shipping", vipService.applyPromotion(vipOrder, "PROMO-123VIP"));

        OrderService lowTotalService = new OrderService();
        Order lowTotalOrder = new Order("O3", premiumCustomer, List.of(new OrderItem(new Product("P3", "Pen", 10.0, "Books"), 4)));
        assertEquals("Order total too low for promotion", lowTotalService.applyPromotion(lowTotalOrder, "PROMO12345"));

        OrderService noMatchService = new OrderService();
        Order noMatchOrder = new Order("O4", new Customer("C4", "Bob", false, 0), List.of(new OrderItem(new Product("P4", "Chair", 30.0, "Clothing"), 2)));
        assertEquals("Promotion conditions not met", noMatchService.applyPromotion(noMatchOrder, "PROMO12345"));
    }
}
