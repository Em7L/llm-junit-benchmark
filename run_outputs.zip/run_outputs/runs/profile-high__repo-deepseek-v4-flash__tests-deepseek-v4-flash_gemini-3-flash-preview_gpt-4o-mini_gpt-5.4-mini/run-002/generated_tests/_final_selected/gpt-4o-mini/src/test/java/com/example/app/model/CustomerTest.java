package com.example.app.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {
    @Test
    void createsCustomerSuccessfully() {
        Customer customer = new Customer("C001", "John Doe", true, 50);
        assertEquals("C001", customer.getId());
        assertEquals("John Doe", customer.getName());
        assertTrue(customer.isPremium());
        assertEquals(50, customer.getLoyaltyPoints());
    }

    @Test
    void rejectsBlankId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "Name", true, 0));
    }

    @Test
    void rejectsBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "", true, 0));
    }

    @Test
    void rejectsNegativeLoyaltyPoints() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "Name", true, -1));
    }

    @Test
    void eligibleForDiscountIfPremium() {
        Customer premiumCustomer = new Customer("C001", "John Doe", true, 50);
        assertTrue(premiumCustomer.isEligibleForDiscount());
    }

    @Test
    void eligibleForDiscountIfLoyaltyPointsGreaterThan100() {
        Customer loyalCustomer = new Customer("C002", "Jane Doe", false, 150);
        assertTrue(loyalCustomer.isEligibleForDiscount());
    }

    @Test
    void notEligibleForDiscountIfLowLoyaltyPoints() {
        Customer nonEligibleCustomer = new Customer("C003", "Mark Smith", false, 50);
        assertFalse(nonEligibleCustomer.isEligibleForDiscount());
    }
}