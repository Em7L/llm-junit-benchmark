package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

class DiscountCalculatorTest {

    private final DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void noDiscountForSubtotalBelow100() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Cheap", 10, "Cat");
        OrderItem item = new OrderItem(p, 5); // 50
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(0.0, discount, 1e-9);
    }

    @Test
    void tierDiscountSubtotalBetween100And500() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Item", 50, "Cat");
        OrderItem item = new OrderItem(p, 3); // 150
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(150 * 0.02, discount, 1e-9);
    }

    @Test
    void tierDiscountSubtotalBetween500And1000() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Item", 200, "Cat");
        OrderItem item = new OrderItem(p, 3); // 600
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(600 * 0.05, discount, 1e-9);
    }

    @Test
    void tierDiscountSubtotalAbove1000() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Expensive", 500, "Cat");
        OrderItem item = new OrderItem(p, 3); // 1500
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(1500 * 0.10, discount, 1e-9);
    }

    @Test
    void premiumAdditionalDiscount() {
        Customer c = new Customer("C1", "Name", true, 0);
        Product p = new Product("P1", "Item", 100, "Cat");
        OrderItem item = new OrderItem(p, 1); // 100, below tier threshold, so only premium
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(100 * 0.03, discount, 1e-9);
    }

    @Test
    void loyaltyPointsDiscount() {
        Customer c = new Customer("C1", "Name", false, 200); // 2 blocks of 100 -> 2% up to 15% cap
        Product p = new Product("P1", "Item", 100, "Cat");
        OrderItem item = new OrderItem(p, 1); // 100
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(100 * 0.02, discount, 1e-9); // no tier discount because subtotal 100 not >100, so just loyalty
    }

    @Test
    void loyaltyPointsDiscountCap() {
        Customer c = new Customer("C1", "Name", false, 2000); // 20 blocks -> 20% capped at 15%
        Product p = new Product("P1", "Item", 100, "Cat");
        OrderItem item = new OrderItem(p, 1); // 100
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(100 * 0.15, discount, 1e-9);
    }

    @Test
    void itemQuantityDiscountApplies() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p = new Product("P1", "Bulk", 20, "Cat");
        OrderItem item = new OrderItem(p, 5); // line total 100, quantity >=5 -> 5% of 100 = 5
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertEquals(5.0, discount, 1e-9); // no tier (100 is not >100), no premium, no loyalty, only item discount
    }

    @Test
    void itemQuantityDiscountOnMultipleItems() {
        Customer c = new Customer("C1", "Name", false, 0);
        Product p1 = new Product("P1", "A", 10, "Cat");
        Product p2 = new Product("P2", "B", 20, "Cat");
        OrderItem item1 = new OrderItem(p1, 5); // line total 50, discount 2.5
        OrderItem item2 = new OrderItem(p2, 2); // no discount (quantity <5)
        Order order = new Order("O1", c, Arrays.asList(item1, item2));
        double discount = calculator.calculateDiscount(order);
        assertEquals(2.5, discount, 1e-9);
    }

    @Test
    void discountCappedAtSubtotal() {
        Customer c = new Customer("C1", "Name", true, 100000); // many points
        Product p = new Product("P1", "Cheap", 10, "Cat");
        OrderItem item = new OrderItem(p, 1); // subtotal 10
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        assertTrue(discount <= 10.0);
    }

    @Test
    void combinedDiscounts() {
        Customer c = new Customer("C1", "Name", true, 100); // premium (3%) + loyalty (1%) = 4% on subtotal
        Product p = new Product("P1", "Item", 500, "Cat");
        OrderItem item = new OrderItem(p, 3); // subtotal 1500 -> tier 10% + premium 3% + loyalty 1% = 14% of 1500 = 210, plus item discount if quantity >=5? quantity 3 so no item discount
        Order order = new Order("O1", c, Collections.singletonList(item));
        double discount = calculator.calculateDiscount(order);
        double expected = 1500 * 0.14;
        assertEquals(expected, discount, 1e-9);
    }
}