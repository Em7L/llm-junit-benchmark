package com.example.app.service;

import com.example.app.model.*;
import com.example.app.service.PriceCalculator.PriceBreakdown;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

class OrderFormatterTest {

    private final OrderFormatter formatter = new OrderFormatter();

    @Test
    void formatIncludesOrderIdAndCustomer() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 10, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O123", c, Collections.singletonList(item));
        PriceBreakdown breakdown = new PriceBreakdown(10, 0, 0, 10);
        String result = formatter.format(order, breakdown);
        assertTrue(result.contains("Order ID: O123"));
        assertTrue(result.contains("Customer: John (C1)"));
    }

    @Test
    void formatIncludesItemDetails() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Widget", 25.0, "Cat");
        OrderItem item = new OrderItem(p, 3);
        Order order = new Order("O1", c, Collections.singletonList(item));
        PriceBreakdown breakdown = new PriceBreakdown(75, 5, 6, 76);
        String result = formatter.format(order, breakdown);
        assertTrue(result.contains("Widget x 3 @ $25.00 = $75.00"));
    }

    @Test
    void formatIncludesSubtotalDiscountTaxTotal() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Item", 100, "Cat");
        OrderItem item = new OrderItem(p, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        PriceBreakdown breakdown = new PriceBreakdown(100, 10, 5, 95);
        String result = formatter.format(order, breakdown);
        assertTrue(result.contains("Subtotal: $100.00"));
        assertTrue(result.contains("Discount: $10.00"));
        assertTrue(result.contains("Tax: $5.00"));
        assertTrue(result.contains("Total: $95.00"));
    }

    @Test
    void formatHandlesZeroValues() {
        Customer c = new Customer("C1", "John", false, 0);
        Product p = new Product("P1", "Free", 0, "Cat"); // price positive? Actually 0 is not allowed. So we use small value.
        // Use valid product with small price
        Product p2 = new Product("P1", "Cheap", 0.01, "Cat");
        OrderItem item = new OrderItem(p2, 1);
        Order order = new Order("O1", c, Collections.singletonList(item));
        PriceBreakdown breakdown = new PriceBreakdown(0.01, 0, 0, 0.01);
        String result = formatter.format(order, breakdown);
        assertTrue(result.contains("Subtotal: $0.01"));
        assertTrue(result.contains("Discount: $0.00"));
        assertTrue(result.contains("Tax: $0.00"));
        assertTrue(result.contains("Total: $0.01"));
    }
}