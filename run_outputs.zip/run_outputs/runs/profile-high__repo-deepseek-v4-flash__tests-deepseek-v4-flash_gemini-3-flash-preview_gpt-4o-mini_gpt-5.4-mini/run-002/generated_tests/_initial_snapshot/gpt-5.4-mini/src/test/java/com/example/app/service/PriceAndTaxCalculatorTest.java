package com.example.app.service;

import com.example.app.model.Customer;
import com.example.app.model.Order;
import com.example.app.model.OrderItem;
import com.example.app.model.Product;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PriceAndTaxCalculatorTest {

    @Test
    void discountCalculatorAppliesTierPremiumLoyaltyAndItemQuantityDiscounts() {
        Customer customer = new Customer("C1", "John", true, 250);
        Product expensive = new Product("P1", "Laptop", 300.0, "Electronics");
        Product bulk = new Product("P2", "Accessory", 20.0, "Clothing");
        Order order = new Order("O1", customer, List.of(
                new OrderItem(expensive, 4),  // 1200
                new OrderItem(bulk, 5)        // 100
        ));

        DiscountCalculator calculator = new DiscountCalculator();
        double discount = calculator.calculateDiscount(order);

        // subtotal = 1300
        // tier > 1000 => 130
        // premium => 39
        // loyalty 250 => 2 blocks => 26, capped under 15% of subtotal so still 26
        // item quantity >= 5 => 5 on accessory line total 100 => 5
        assertEquals(200.0, discount, 0.0001);
    }

    @Test
    void discountCalculatorCapsDiscountAtSubtotal() {
        Customer customer = new Customer("C1", "John", true, 1000);
        Product product = new Product("P1", "Widget", 10.0, "Electronics");
        Order order = new Order("O1", customer, List.of(new OrderItem(product, 1)));

        double discount = new DiscountCalculator().calculateDiscount(order);
        assertEquals(order.getSubtotal(), discount, 0.0001);
    }

    @Test
    void taxCalculatorUsesCategorySpecificRates() {
        Customer customer = new Customer("C1", "John", false, 0);
        Order order = new Order("O1", customer, List.of(
                new OrderItem(new Product("P1", "Laptop", 100.0, "Electronics"), 1),
                new OrderItem(new Product("P2", "Novel", 50.0, "Books"), 2),
                new OrderItem(new Product("P3", "Shirt", 40.0, "Clothing"), 1),
                new OrderItem(new Product("P4", "Apple", 10.0, "Food"), 3),
                new OrderItem(new Product("P5", "Other", 20.0, "Toys"), 2)
        ));

        double tax = new TaxCalculator().calculateTax(order, 0.0);
        // 100*0.08 + 100*0.05 + 40*0.12 + 30*0.0 + 40*0.10 = 21.8
        assertEquals(21.8, tax, 0.0001);
    }

    @Test
    void priceCalculatorProducesConsistentBreakdown() {
        Customer customer = new Customer("C1", "John", false, 0);
        Order order = new Order("O1", customer, List.of(
                new OrderItem(new Product("P1", "Book", 50.0, "Books"), 2),
                new OrderItem(new Product("P2", "Shirt", 25.0, "Clothing"), 1)
        ));

        PriceCalculator.PriceBreakdown breakdown = new PriceCalculator().calculateBreakdown(order);

        assertEquals(125.0, breakdown.getSubtotal(), 0.0001);
        assertEquals(2.5, breakdown.getDiscount(), 0.0001); // subtotal > 100 => 2%
        assertEquals(7.5, breakdown.getTax(), 0.0001);      // 100*0.05 + 25*0.12
        assertEquals(130.0, breakdown.getTotal(), 0.0001);
    }
}
