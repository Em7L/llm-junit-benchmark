package com.example.app.service;

import com.example.app.model.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class DiscountCalculatorTest {
    private final DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void calculateTieredDiscounts() {
        Customer c = new Customer("C1", "N", false, 0);
        Product p = new Product("P1", "N", 100.0, "Other");

        // > 100 (2%)
        Order o1 = new Order("O1", c, List.of(new OrderItem(p, 2)));
        assertEquals(4.0, calculator.calculateDiscount(o1), 0.001);

        // > 500 (5%)
        Order o2 = new Order("O2", c, List.of(new OrderItem(p, 6)));
        assertEquals(30.0, calculator.calculateDiscount(o2), 0.001);

        // > 1000 (10%)
        Order o3 = new Order("O3", c, List.of(new OrderItem(p, 11)));
        assertEquals(110.0, calculator.calculateDiscount(o3), 0.001);
    }

    @Test
    void loyaltyAndPremiumStackedDiscounts() {
        // Premium (3%) + 200 points (2%) = 5% of subtotal
        Customer c = new Customer("C1", "N", true, 250);
        Product p = new Product("P1", "N", 50.0, "Other");
        Order o = new Order("O1", c, List.of(new OrderItem(p, 1))); // subtotal 50
        
        // Premium discount: 50 * 0.03 = 1.5
        // Loyalty discount: 2 blocks * 0.01 * 50 = 1.0
        // Total = 2.5
        assertEquals(2.5, calculator.calculateDiscount(o), 0.001);
    }

    @Test
    void bulkQuantityDiscount() {
        Customer c = new Customer("C1", "N", false, 0);
        Product p = new Product("P1", "N", 10.0, "Other");
        // 5 items @ 10 = 50 subtotal. Bulk discount = 50 * 0.05 = 2.5
        Order o = new Order("O1", c, List.of(new OrderItem(p, 5)));
        assertEquals(2.5, calculator.calculateDiscount(o), 0.001);
    }
}