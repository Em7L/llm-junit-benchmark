# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-006/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_successful | 1 |
| deepseek-v4-flash | passed | repair_successful | 1 |
| gemini-3-flash-preview | passed | repair_partially_improved | 1 |
| gpt-4o-mini | passed | repair_no_improvement | 1 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 32 | 4 | 0 | 78.72% | 73.81% | 219 | 165 | 29 | 25 | 75.34% |
| deepseek-v4-flash | test_failures | 116 | 10 | 0 | 86.82% | 81.55% | 219 | 172 | 34 | 13 | 78.54% |
| gemini-3-flash-preview | test_compile_failure | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| gpt-4o-mini | test_failures | 8 | 3 | 0 | 55.41% | 33.33% | 219 | 49 | 76 | 94 | 22.37% |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | passed | 32 | 0 | 0 | 87.84% | 82.14% | 219 | 181 | 27 | 11 | 82.65% |
| deepseek-v4-flash | passed | 116 | 0 | 0 | 94.93% | 88.10% | 219 | 186 | 30 | 3 | 84.93% |
| gemini-3-flash-preview | test_failures | 21 | 3 | 0 | 70.27% | 60.71% | 219 | 124 | 53 | 42 | 56.62% |
| gpt-4o-mini | test_failures | 8 | 3 | 0 | 55.74% | 33.33% | 219 | 49 | 77 | 93 | 22.37% |

## Mutant Set Consistency
- Comparable PIT suites: `7`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `219`
- Union mutant IDs: `219`
- `_final_selected/deepseek-v4-flash` mutant IDs: `219`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `219`
- `_final_selected/gpt-4o-mini` mutant IDs: `219`
- `_final_selected/gpt-5.4-mini` mutant IDs: `219`
- `_initial_snapshot/deepseek-v4-flash` mutant IDs: `219`
- `_initial_snapshot/gpt-4o-mini` mutant IDs: `219`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `219`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_no_improvement`: One or more repair attempts were applied, but the final generated test suite did not verify any better than the first verifiable suite.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `maven_status=test_compile_failure`: The generated or existing test sources did not compile during Maven test validation.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.