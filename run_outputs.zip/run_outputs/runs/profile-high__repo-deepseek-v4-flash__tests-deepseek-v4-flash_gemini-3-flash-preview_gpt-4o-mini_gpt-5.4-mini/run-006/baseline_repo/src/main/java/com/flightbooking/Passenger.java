package com.flightbooking;

import java.util.ArrayList;
import java.util.List;

public class Passenger {
    private final String firstName;
    private final String lastName;
    private int age;
    private int loyaltyPoints;
    private final List<Booking> bookings;

    public Passenger(String firstName, String lastName, int age, int loyaltyPoints) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.loyaltyPoints = loyaltyPoints;
        this.bookings = new ArrayList<>();
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public int getAge() {
        return age;
    }

    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }

    public void addLoyaltyPoints(int points) {
        this.loyaltyPoints += points;
    }

    public void deductLoyaltyPoints(int points) {
        if (loyaltyPoints >= points) {
            loyaltyPoints -= points;
        }
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public void removeBooking(Booking booking) {
        bookings.remove(booking);
    }

    public List<Booking> getBookings() {
        return new ArrayList<>(bookings);
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setLoyaltyPoints(int loyaltyPoints) {
        this.loyaltyPoints = loyaltyPoints;
    }
}
