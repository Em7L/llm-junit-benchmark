package com.flightbooking;

public class DiscountCalculator {

    public double calculateDiscount(Passenger passenger, int groupSize, boolean isPeakSeason) {
        double discount = 0.0;

        // Loyalty discount: 1% per 100 points, max 20%
        if (passenger.getLoyaltyPoints() >= 100) {
            int points = passenger.getLoyaltyPoints();
            double loyaltyDiscount = Math.min(points / 100.0, 20.0);
            discount = Math.max(discount, loyaltyDiscount / 100.0);
        }

        // Age discount: seniors (>=60) get 10%, children (<12) get 15%
        if (passenger.getAge() >= 60) {
            double ageDiscount = 0.10;
            if (discount < ageDiscount) {
                discount = ageDiscount;
            }
        } else if (passenger.getAge() < 12) {
            double ageDiscount = 0.15;
            if (discount < ageDiscount) {
                discount = ageDiscount;
            }
        }

        // Group discount: 5% for groups of 3-5, 10% for 6+
        if (groupSize >= 6) {
            if (discount < 0.10) {
                discount = 0.10;
            }
        } else if (groupSize >= 3) {
            if (discount < 0.05) {
                discount = 0.05;
            }
        }

        // Peak season penalty: no discount during peak season
        if (isPeakSeason) {
            discount = 0.0;
        }

        return discount;
    }
}
