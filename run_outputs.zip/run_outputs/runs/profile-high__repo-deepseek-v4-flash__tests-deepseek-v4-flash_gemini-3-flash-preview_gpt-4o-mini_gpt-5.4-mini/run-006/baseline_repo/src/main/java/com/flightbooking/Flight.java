package com.flightbooking;

import java.util.ArrayList;
import java.util.List;

public class Flight {
    private final String flightNumber;
    private double basePrice;
    private int totalSeats;
    private int availableSeats;
    private final List<Booking> bookings;

    public Flight(String flightNumber, double basePrice, int totalSeats) {
        this.flightNumber = flightNumber;
        this.basePrice = basePrice;
        this.totalSeats = totalSeats;
        this.availableSeats = totalSeats;
        this.bookings = new ArrayList<>();
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public boolean hasAvailableSeats() {
        return availableSeats > 0;
    }

    public boolean bookSeat() {
        if (availableSeats <= 0) {
            return false;
        }
        availableSeats--;
        return true;
    }

    public void cancelSeat() {
        if (availableSeats < totalSeats) {
            availableSeats++;
        }
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public void removeBooking(Booking booking) {
        bookings.remove(booking);
    }

    public List<Booking> getBookings() {
        return new ArrayList<>(bookings);
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
        if (availableSeats > totalSeats) {
            availableSeats = totalSeats;
        }
    }
}
