package com.flightbooking;

public class BookingValidator {

    public boolean validateBooking(Flight flight, Passenger passenger, Payment payment) {
        if (flight == null) {
            return false;
        }
        if (passenger == null) {
            return false;
        }
        if (payment == null) {
            return false;
        }
        if (flight.getAvailableSeats() <= 0) {
            return false;
        }
        if (passenger.getAge() <= 0) {
            return false;
        }
        if (payment.getAmount() <= 0) {
            return false;
        }
        if (!isValidPaymentMethod(payment.getMethod())) {
            return false;
        }
        return true;
    }

    private boolean isValidPaymentMethod(String method) {
        if (method == null || method.isEmpty()) {
            return false;
        }
        // Only accept CREDIT_CARD, DEBIT_CARD, PAYPAL
        if (!method.equals("CREDIT_CARD") && !method.equals("DEBIT_CARD") && !method.equals("PAYPAL")) {
            return false;
        }
        return true;
    }

    public boolean validatePassengerAge(Passenger passenger, int minAge, int maxAge) {
        int age = passenger.getAge();
        if (age < minAge || age > maxAge) {
            return false;
        }
        return true;
    }

    public boolean validateBookingDate(String date) {
        if (date == null || date.isEmpty()) {
            return false;
        }
        // Simple date format check: YYYY-MM-DD
        if (date.length() != 10) {
            return false;
        }
        if (date.charAt(4) != '-' || date.charAt(7) != '-') {
            return false;
        }
        try {
            int year = Integer.parseInt(date.substring(0,4));
            int month = Integer.parseInt(date.substring(5,7));
            int day = Integer.parseInt(date.substring(8,10));
            if (year < 2020 || year > 2030) {
                return false;
            }
            if (month < 1 || month > 12) {
                return false;
            }
            if (day < 1 || day > 31) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
}
