package com.flightbooking;

import java.util.List;

public class BookingFormatter {

    public static String formatBookingSummary(Booking booking) {
        if (booking == null) {
            return "No booking.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Booking ID: ").append(booking.getId()).append("\n");
        sb.append("Flight: ").append(booking.getFlight().getFlightNumber()).append("\n");
        sb.append("Passenger: ").append(booking.getPassenger().getFullName()).append("\n");
        sb.append("Total Cost: $").append(String.format("%.2f", booking.getTotalCost())).append("\n");
        sb.append("Confirmed: ").append(booking.isConfirmed() ? "Yes" : "No").append("\n");
        sb.append("Cancelled: ").append(booking.isCancelled() ? "Yes" : "No").append("\n");
        return sb.toString();
    }

    public static String formatItinerary(List<Booking> bookings) {
        if (bookings == null || bookings.isEmpty()) {
            return "No bookings in itinerary.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Itinerary for ").append(bookings.get(0).getPassenger().getFullName()).append(":\n");
        for (Booking b : bookings) {
            sb.append("- ").append(b.getFlight().getFlightNumber()).append(" $").append(String.format("%.2f", b.getTotalCost())).append("\n");
        }
        return sb.toString();
    }

    public static String formatRevenueReport(List<Booking> bookings) {
        double total = 0.0;
        int count = 0;
        for (Booking b : bookings) {
            if (b.isConfirmed()) {
                total += b.getTotalCost();
                count++;
            }
        }
        return "Total confirmed bookings: " + count + ", Revenue: $" + String.format("%.2f", total);
    }
}
