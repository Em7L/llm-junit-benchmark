package com.flightbooking;

import java.util.ArrayList;
import java.util.List;

public class BookingService {
    private final List<Booking> allBookings;
    private final Pricing pricing;
    private final DiscountCalculator discountCalculator;
    private final Cancellation cancellation;
    private final BookingValidator validator;

    public BookingService() {
        this.allBookings = new ArrayList<>();
        this.pricing = new Pricing();
        this.discountCalculator = new DiscountCalculator();
        this.cancellation = new Cancellation();
        this.validator = new BookingValidator();
    }

    public Booking createBooking(Flight flight, Passenger passenger, Payment payment,
                                  boolean isPeakSeason, int groupSize) {
        // Validate booking
        if (!validator.validateBooking(flight, passenger, payment)) {
            return null;
        }

        // Check seat availability
        if (!flight.hasAvailableSeats()) {
            return null;
        }

        // Calculate discount
        double discount = discountCalculator.calculateDiscount(passenger, groupSize, isPeakSeason);

        // Calculate total price
        double baseTotal = pricing.calculateBasePrice(flight.getBasePrice(), 1);
        double total = pricing.applyDiscount(baseTotal, discount);
        // Apply a standard surcharge of 5% for credit card
        if ("CREDIT_CARD".equals(payment.getMethod())) {
            total = pricing.applySurcharge(total, 0.05);
        }

        // Create booking
        payment.setAmount(total);
        Booking booking = new Booking(flight, passenger, payment, total);

        // Book seat and tie relationships
        boolean seatBooked = flight.bookSeat();
        if (!seatBooked) {
            return null;
        }
        flight.addBooking(booking);
        passenger.addBooking(booking);
        allBookings.add(booking);

        // Confirm payment
        booking.confirm();

        return booking;
    }

    public double cancelBooking(Booking booking) {
        if (booking == null || booking.isCancelled()) {
            return 0.0;
        }
        // Assume 10 days before departure for simplicity
        boolean success = cancellation.processCancellation(booking, 10);
        if (success) {
            allBookings.remove(booking);
            booking.getFlight().removeBooking(booking);
            booking.getPassenger().removeBooking(booking);
            return cancellation.computeRefundAmount(booking, 10);
        }
        return 0.0;
    }

    public Booking modifyBooking(Booking booking, Flight newFlight, boolean isPeakSeason, int groupSize) {
        if (booking == null || booking.isCancelled() || !booking.isConfirmed()) {
            return null;
        }
        // Cancel old booking
        cancelBooking(booking);
        // Create new booking with same passenger but new flight
        return createBooking(newFlight, booking.getPassenger(), booking.getPayment(), isPeakSeason, groupSize);
    }

    public List<Booking> getBookingsByPassenger(Passenger passenger) {
        List<Booking> result = new ArrayList<>();
        for (Booking b : allBookings) {
            if (b.getPassenger().getFullName().equals(passenger.getFullName()) && !b.isCancelled()) {
                result.add(b);
            }
        }
        return result;
    }

    public double getTotalRevenue() {
        double total = 0.0;
        for (Booking b : allBookings) {
            if (b.isConfirmed()) {
                total += b.getTotalCost();
            }
        }
        return total;
    }

    public List<Booking> getAllBookings() {
        return new ArrayList<>(allBookings);
    }
}
