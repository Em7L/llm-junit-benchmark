package com.flightbooking;

public class Payment {
    private final String method;
    private double amount;
    private boolean processed;

    public Payment(String method, double amount) {
        this.method = method;
        this.amount = amount;
        this.processed = false;
    }

    public String getMethod() {
        return method;
    }

    public double getAmount() {
        return amount;
    }

    public boolean isProcessed() {
        return processed;
    }

    public boolean process() {
        if (amount <= 0) {
            return false;
        }
        processed = true;
        return true;
    }

    public double refund() {
        if (!processed) {
            return 0.0;
        }
        processed = false;
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
