package com.flightbooking;

public class Main {
    public static void main(String[] args) {
        // Quick demonstration of the booking system
        Flight flight = new Flight("AA100", 150.0, 200);
        Passenger passenger = new Passenger("John", "Doe", 30, 500);
        Payment payment = new Payment("CREDIT_CARD", 150.0);
        BookingService service = new BookingService();
        Booking booking = service.createBooking(flight, passenger, payment, false, 1);
        System.out.println(BookingFormatter.formatBookingSummary(booking));
        System.out.println("Cancellation refund: " + service.cancelBooking(booking));
    }
}
