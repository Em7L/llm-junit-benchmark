package com.flightbooking;

public class Cancellation {

    public double computeRefundAmount(Booking booking, int daysBeforeDeparture) {
        if (booking == null || booking.isCancelled()) {
            return 0.0;
        }

        double totalPaid = booking.getPayment().getAmount();
        if (totalPaid <= 0) {
            return 0.0;
        }

        double feePercent;
        if (daysBeforeDeparture >= 14) {
            feePercent = 0.10;
        } else if (daysBeforeDeparture >= 7) {
            feePercent = 0.25;
        } else if (daysBeforeDeparture >= 3) {
            feePercent = 0.50;
        } else if (daysBeforeDeparture >= 1) {
            feePercent = 0.75;
        } else {
            feePercent = 1.0; // no refund
        }

        double refund = totalPaid * (1 - feePercent);
        return refund;
    }

    public boolean processCancellation(Booking booking, int daysBeforeDeparture) {
        if (booking == null || booking.isCancelled()) {
            return false;
        }
        double refund = computeRefundAmount(booking, daysBeforeDeparture);
        booking.getPayment().refund();
        booking.getFlight().cancelSeat();
        booking.getPassenger().addLoyaltyPoints((int)(refund * 0.1));
        booking.cancel();
        return true;
    }
}
