package com.flightbooking;

public class Pricing {

    public double calculateBasePrice(double basePrice, int passengers) {
        if (basePrice <= 0 || passengers <= 0) {
            return 0.0;
        }
        return basePrice * passengers;
    }

    public double applyDiscount(double price, double discount) {
        if (discount < 0 || discount > 1) {
            return price;
        }
        return price * (1 - discount);
    }

    public double applySurcharge(double price, double surchargePercent) {
        if (surchargePercent < 0 || surchargePercent > 0.5) {
            return price;
        }
        return price * (1 + surchargePercent);
    }

    public double calculateTotal(double basePrice, int passengers, double discount, double surchargePercent) {
        double total = calculateBasePrice(basePrice, passengers);
        total = applyDiscount(total, discount);
        total = applySurcharge(total, surchargePercent);
        return total;
    }
}
