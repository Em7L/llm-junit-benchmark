package com.flightbooking;

public class Booking {
    private static int nextId = 1;
    private final int id;
    private final Flight flight;
    private final Passenger passenger;
    private final Payment payment;
    private double totalCost;
    private boolean confirmed;
    private boolean cancelled;

    public Booking(Flight flight, Passenger passenger, Payment payment, double totalCost) {
        this.id = nextId++;
        this.flight = flight;
        this.passenger = passenger;
        this.payment = payment;
        this.totalCost = totalCost;
        this.confirmed = false;
        this.cancelled = false;
    }

    public int getId() {
        return id;
    }

    public Flight getFlight() {
        return flight;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public Payment getPayment() {
        return payment;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public boolean confirm() {
        if (confirmed || cancelled) {
            return false;
        }
        if (!payment.process()) {
            return false;
        }
        confirmed = true;
        return true;
    }

    public boolean cancel() {
        if (cancelled) {
            return false;
        }
        cancelled = true;
        confirmed = false;
        return true;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
}
