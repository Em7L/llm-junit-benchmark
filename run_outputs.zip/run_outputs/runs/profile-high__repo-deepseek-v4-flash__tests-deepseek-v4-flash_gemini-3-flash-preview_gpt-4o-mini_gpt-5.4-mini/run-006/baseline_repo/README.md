# Flight Booking System

A self-contained Java application for managing flight bookings. Includes orchestration, pricing, validation, and cancellation logic.

## Complexity Summary

- Number of production classes: 10
- Total public methods: 28
- Methods with >= 3 branches: 7
- Class descriptions:
  - BookingService: Orchestrates create, cancel, modify bookings; coordinates across multiple services.
  - Flight: Represents flight with seat management and booking references.
  - Passenger: Represents passenger with booking history.
  - Payment: Handles payment processing and refunds.
  - Pricing: Calculates base price, discounts, and surcharges.
  - Booking: Holds booking details and total cost.
  - DiscountCalculator: Computes discounts based on loyalty, age, group size, season.
  - Cancellation: Handles cancellation logic and refund amount computation.
  - BookingValidator: Validates booking, passenger, and payment constraints.
  - BookingFormatter: Formats booking summaries and itineraries.
  - Main: Entry point for demonstration.
