package com.flightbooking;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BookingAndCancellationTest {

    private static final double EPS = 1e-9;

    @Test
    void confirmProcessesPaymentOnceAndIsIdempotent() {
        Flight flight = new Flight("AA200", 200.0, 2);
        Passenger passenger = new Passenger("Mia", "Brown", 28, 100);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);

        assertTrue(booking.confirm());
        assertTrue(booking.isConfirmed());
        assertTrue(payment.isProcessed());
        assertFalse(booking.confirm());
    }

    @Test
    void confirmFailsForNonPositivePaymentAmount() {
        Booking booking = new Booking(
                new Flight("AA201", 200.0, 1),
                new Passenger("Mia", "Brown", 28, 100),
                new Payment("CREDIT_CARD", 0.0),
                0.0
        );

        assertFalse(booking.confirm());
        assertFalse(booking.isConfirmed());
    }

    @Test
    void cancelMarksBookingCancelledAndPreventsSecondCancellation() {
        Booking booking = new Booking(
                new Flight("AA202", 200.0, 1),
                new Passenger("Mia", "Brown", 28, 100),
                new Payment("CREDIT_CARD", 200.0),
                200.0
        );

        assertTrue(booking.cancel());
        assertTrue(booking.isCancelled());
        assertFalse(booking.isConfirmed());
        assertFalse(booking.cancel());
    }

    @Test
    void paymentRefundReturnsAmountOnlyWhenProcessed() {
        Payment payment = new Payment("PAYPAL", 123.45);

        assertEquals(0.0, payment.refund(), EPS);
        assertTrue(payment.process());
        assertEquals(123.45, payment.refund(), EPS);
        assertFalse(payment.isProcessed());
    }

    @Test
    void cancellationComputesRefundByDaysBeforeDeparture() {
        Flight flight = new Flight("AA300", 100.0, 1);
        Passenger passenger = new Passenger("Eve", "Stone", 40, 0);
        Payment payment = new Payment("DEBIT_CARD", 200.0);
        payment.process();
        Booking booking = new Booking(flight, passenger, payment, 200.0);

        Cancellation cancellation = new Cancellation();

        assertEquals(180.0, cancellation.computeRefundAmount(booking, 14), EPS);
        assertEquals(150.0, cancellation.computeRefundAmount(booking, 7), EPS);
        assertEquals(100.0, cancellation.computeRefundAmount(booking, 3), EPS);
        assertEquals(50.0, cancellation.computeRefundAmount(booking, 1), EPS);
        assertEquals(0.0, cancellation.computeRefundAmount(booking, 0), EPS);
    }

    @Test
    void processCancellationUpdatesFlightPassengerAndBookingState() {
        Flight flight = new Flight("AA301", 100.0, 1);
        Passenger passenger = new Passenger("Eve", "Stone", 40, 0);
        Payment payment = new Payment("DEBIT_CARD", 200.0);
        payment.process();
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        flight.bookSeat();
        flight.addBooking(booking);
        passenger.addBooking(booking);

        Cancellation cancellation = new Cancellation();

        assertTrue(cancellation.processCancellation(booking, 14));
        assertTrue(booking.isCancelled());
        assertFalse(booking.isConfirmed());
        assertEquals(1, flight.getAvailableSeats());
        assertTrue(passenger.getLoyaltyPoints() > 0);
    }

    @Test
    void bookingIdsIncreaseMonotonically() {
        Booking first = new Booking(new Flight("A1", 10.0, 1), new Passenger("A", "B", 20, 0),
                new Payment("PAYPAL", 10.0), 10.0);
        Booking second = new Booking(new Flight("A2", 10.0, 1), new Passenger("C", "D", 20, 0),
                new Payment("PAYPAL", 10.0), 10.0);

        assertNotEquals(first.getId(), second.getId());
        assertTrue(second.getId() > first.getId());
    }
}