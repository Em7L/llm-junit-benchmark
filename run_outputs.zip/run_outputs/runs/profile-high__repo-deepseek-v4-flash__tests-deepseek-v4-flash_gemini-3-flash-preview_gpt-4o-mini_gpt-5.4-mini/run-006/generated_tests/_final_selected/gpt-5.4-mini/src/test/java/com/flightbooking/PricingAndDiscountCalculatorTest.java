package com.flightbooking;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PricingAndDiscountCalculatorTest {

    private static final double EPS = 1e-9;

    @Test
    void calculateBasePriceReturnsZeroForInvalidInputs() {
        Pricing pricing = new Pricing();

        assertEquals(0.0, pricing.calculateBasePrice(0.0, 1), EPS);
        assertEquals(0.0, pricing.calculateBasePrice(100.0, 0), EPS);
        assertEquals(0.0, pricing.calculateBasePrice(-5.0, 3), EPS);
    }

    @Test
    void calculateBasePriceMultipliesBasePriceByPassengerCount() {
        Pricing pricing = new Pricing();

        assertEquals(375.0, pricing.calculateBasePrice(125.0, 3), EPS);
    }

    @Test
    void applyDiscountRejectsOutOfRangeDiscounts() {
        Pricing pricing = new Pricing();

        assertEquals(200.0, pricing.applyDiscount(200.0, -0.01), EPS);
        assertEquals(200.0, pricing.applyDiscount(200.0, 1.01), EPS);
    }

    @Test
    void applyDiscountAppliesPercentageReduction() {
        Pricing pricing = new Pricing();

        assertEquals(150.0, pricing.applyDiscount(200.0, 0.25), EPS);
    }

    @Test
    void applySurchargeRejectsOutOfRangeSurcharge() {
        Pricing pricing = new Pricing();

        assertEquals(200.0, pricing.applySurcharge(200.0, -0.01), EPS);
        assertEquals(200.0, pricing.applySurcharge(200.0, 0.51), EPS);
    }

    @Test
    void applySurchargeAppliesPercentageIncrease() {
        Pricing pricing = new Pricing();

        assertEquals(210.0, pricing.applySurcharge(200.0, 0.05), EPS);
    }

    @Test
    void calculateTotalAppliesBasePriceDiscountAndSurchargeInSequence() {
        Pricing pricing = new Pricing();

        double total = pricing.calculateTotal(100.0, 2, 0.10, 0.05);

        assertEquals(189.0, total, EPS);
    }

    @Test
    void discountCalculatorUsesHighestApplicableDiscountAndHandlesPeakSeason() {
        DiscountCalculator calculator = new DiscountCalculator();

        Passenger seniorLoyalPassenger = new Passenger("Ana", "Stone", 65, 1200);
        assertEquals(0.12, calculator.calculateDiscount(seniorLoyalPassenger, 1, false), EPS,
                "Expected loyalty discount (12%) to exceed age discount (10%)");

        Passenger childGroupPassenger = new Passenger("Max", "Lee", 10, 0);
        assertEquals(0.15, calculator.calculateDiscount(childGroupPassenger, 4, false), EPS,
                "Expected child discount to dominate group discount");

        Passenger largeGroupPassenger = new Passenger("Zoe", "Kim", 35, 50);
        assertEquals(0.10, calculator.calculateDiscount(largeGroupPassenger, 6, false), EPS);

        Passenger peakSeasonPassenger = new Passenger("Tom", "Ray", 70, 5000);
        assertEquals(0.0, calculator.calculateDiscount(peakSeasonPassenger, 8, true), EPS);
    }

    @Test
    void discountCalculatorReturnsZeroWhenNoRuleApplies() {
        DiscountCalculator calculator = new DiscountCalculator();
        Passenger passenger = new Passenger("Liam", "Nash", 35, 0);

        assertEquals(0.0, calculator.calculateDiscount(passenger, 1, false), EPS);
    }
}