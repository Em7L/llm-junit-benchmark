package com.flightbooking;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BookingValidatorTest {

    @Test
    void validateBookingRejectsNullAndInvalidObjects() {
        BookingValidator validator = new BookingValidator();
        Flight validFlight = new Flight("AA101", 100.0, 1);
        Passenger validPassenger = new Passenger("Jane", "Doe", 25, 0);
        Payment validPayment = new Payment("CREDIT_CARD", 100.0);

        assertFalse(validator.validateBooking(null, validPassenger, validPayment));
        assertFalse(validator.validateBooking(validFlight, null, validPayment));
        assertFalse(validator.validateBooking(validFlight, validPassenger, null));
    }

    @Test
    void validateBookingRejectsNoSeatsInvalidAgeZeroAmountAndUnsupportedPaymentMethod() {
        BookingValidator validator = new BookingValidator();
        Passenger validPassenger = new Passenger("Jane", "Doe", 25, 0);

        assertFalse(validator.validateBooking(new Flight("AA101", 100.0, 0), validPassenger,
                new Payment("CREDIT_CARD", 100.0)));
        assertFalse(validator.validateBooking(new Flight("AA101", 100.0, 1),
                new Passenger("Tim", "Q", 0, 0), new Payment("CREDIT_CARD", 100.0)));
        assertFalse(validator.validateBooking(new Flight("AA101", 100.0, 1), validPassenger,
                new Payment("CREDIT_CARD", 0.0)));
        assertFalse(validator.validateBooking(new Flight("AA101", 100.0, 1), validPassenger,
                new Payment("BANK_TRANSFER", 100.0)));
        assertFalse(validator.validateBooking(new Flight("AA101", 100.0, 1), validPassenger,
                new Payment(null, 100.0)));
    }

    @Test
    void validateBookingAcceptsValidInput() {
        BookingValidator validator = new BookingValidator();

        boolean valid = validator.validateBooking(
                new Flight("AA101", 100.0, 1),
                new Passenger("Jane", "Doe", 25, 0),
                new Payment("DEBIT_CARD", 100.0)
        );

        assertTrue(valid);
    }

    @Test
    void validatePassengerAgeChecksInclusiveBounds() {
        BookingValidator validator = new BookingValidator();
        Passenger passenger = new Passenger("Jane", "Doe", 18, 0);

        assertTrue(validator.validatePassengerAge(passenger, 18, 65));
        assertFalse(validator.validatePassengerAge(passenger, 19, 65));
        assertFalse(validator.validatePassengerAge(passenger, 1, 17));
    }

    @Test
    void validateBookingDateChecksFormatAndRange() {
        BookingValidator validator = new BookingValidator();

        assertTrue(validator.validateBookingDate("2024-12-31"));
        assertFalse(validator.validateBookingDate(null));
        assertFalse(validator.validateBookingDate(""));
        assertFalse(validator.validateBookingDate("2024/12/31"));
        assertFalse(validator.validateBookingDate("2019-12-31"));
        assertFalse(validator.validateBookingDate("2031-01-01"));
        assertFalse(validator.validateBookingDate("2024-13-01"));
        assertFalse(validator.validateBookingDate("2024-00-01"));
        assertFalse(validator.validateBookingDate("2024-12-32"));
        assertFalse(validator.validateBookingDate("abcd-ef-gh"));
    }
}