package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PassengerTest {

    @Test
    void testConstructorAndGetters() {
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        assertEquals("John Doe", passenger.getFullName());
        assertEquals(30, passenger.getAge());
        assertEquals(100, passenger.getLoyaltyPoints());
        assertTrue(passenger.getBookings().isEmpty());
    }

    @Test
    void testAddLoyaltyPoints() {
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        passenger.addLoyaltyPoints(50);
        assertEquals(150, passenger.getLoyaltyPoints());
    }

    @Test
    void testDeductLoyaltyPointsSufficient() {
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        passenger.deductLoyaltyPoints(30);
        assertEquals(70, passenger.getLoyaltyPoints());
    }

    @Test
    void testDeductLoyaltyPointsInsufficient() {
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        passenger.deductLoyaltyPoints(200);
        assertEquals(100, passenger.getLoyaltyPoints()); // no change
    }

    @Test
    void testAddAndRemoveBooking() {
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        Flight flight = new Flight("AA100", 150.0, 50);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        passenger.addBooking(booking);
        assertEquals(1, passenger.getBookings().size());
        passenger.removeBooking(booking);
        assertTrue(passenger.getBookings().isEmpty());
    }

    @Test
    void testSetAge() {
        Passenger passenger = new Passenger("John", "Doe", 30, 0);
        passenger.setAge(25);
        assertEquals(25, passenger.getAge());
    }

    @Test
    void testSetLoyaltyPoints() {
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        passenger.setLoyaltyPoints(200);
        assertEquals(200, passenger.getLoyaltyPoints());
    }

    @Test
    void testGetBookingsReturnsCopy() {
        Passenger passenger = new Passenger("John", "Doe", 30, 0);
        Flight flight = new Flight("AA100", 150.0, 50);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        passenger.addBooking(booking);
        passenger.getBookings().clear();
        assertEquals(1, passenger.getBookings().size()); // original unaffected
    }
}
