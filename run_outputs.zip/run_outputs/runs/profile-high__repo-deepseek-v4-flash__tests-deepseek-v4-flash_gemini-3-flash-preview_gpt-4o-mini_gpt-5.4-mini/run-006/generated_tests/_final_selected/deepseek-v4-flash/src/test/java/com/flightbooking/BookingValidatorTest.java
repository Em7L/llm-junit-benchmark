package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BookingValidatorTest {

    private Flight validFlight = new Flight("AA100", 150.0, 50);
    private Passenger validPassenger = new Passenger("Jane", "Doe", 25, 0);
    private Payment validPayment = new Payment("CREDIT_CARD", 200.0);

    @Test
    void testValidateBookingSuccess() {
        BookingValidator validator = new BookingValidator();
        assertTrue(validator.validateBooking(validFlight, validPassenger, validPayment));
    }

    @Test
    void testValidateBookingNullFlight() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(null, validPassenger, validPayment));
    }

    @Test
    void testValidateBookingNullPassenger() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(validFlight, null, validPayment));
    }

    @Test
    void testValidateBookingNullPayment() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(validFlight, validPassenger, null));
    }

    @Test
    void testValidateBookingNoSeats() {
        Flight noSeats = new Flight("BB200", 200.0, 0);
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(noSeats, validPassenger, validPayment));
    }

    @Test
    void testValidateBookingNegativeAge() {
        Passenger negAge = new Passenger("Bad", "Age", -1, 0);
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(validFlight, negAge, validPayment));
    }

    @Test
    void testValidateBookingZeroAge() {
        Passenger zeroAge = new Passenger("Bad", "Age", 0, 0);
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(validFlight, zeroAge, validPayment));
    }

    @Test
    void testValidateBookingNonPositivePayment() {
        Payment badPayment = new Payment("CREDIT_CARD", 0.0);
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(validFlight, validPassenger, badPayment));
    }

    @Test
    void testValidateBookingInvalidPaymentMethod() {
        Payment badMethod = new Payment("BITCOIN", 100.0);
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBooking(validFlight, validPassenger, badMethod));
    }

    @Test
    void testValidatePassengerAgeWithinRange() {
        BookingValidator validator = new BookingValidator();
        Passenger passenger = new Passenger("John", "Doe", 30, 0);
        assertTrue(validator.validatePassengerAge(passenger, 18, 65));
    }

    @Test
    void testValidatePassengerAgeBelowMin() {
        BookingValidator validator = new BookingValidator();
        Passenger passenger = new Passenger("John", "Doe", 10, 0);
        assertFalse(validator.validatePassengerAge(passenger, 18, 65));
    }

    @Test
    void testValidatePassengerAgeAboveMax() {
        BookingValidator validator = new BookingValidator();
        Passenger passenger = new Passenger("John", "Doe", 70, 0);
        assertFalse(validator.validatePassengerAge(passenger, 18, 65));
    }

    @Test
    void testValidateBookingDateValid() {
        BookingValidator validator = new BookingValidator();
        assertTrue(validator.validateBookingDate("2024-05-10"));
    }

    @Test
    void testValidateBookingDateNull() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate(null));
    }

    @Test
    void testValidateBookingDateEmpty() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate(""));
    }

    @Test
    void testValidateBookingDateWrongLength() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate("2024-5-10")); // missing leading zero
    }

    @Test
    void testValidateBookingDateWrongFormat() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate("10-05-2024"));
    }

    @Test
    void testValidateBookingDateYearOutOfRange() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate("2019-12-31"));
        assertFalse(validator.validateBookingDate("2031-01-01"));
    }

    @Test
    void testValidateBookingDateMonthOutOfRange() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate("2024-13-01"));
    }

    @Test
    void testValidateBookingDateDayOutOfRange() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate("2024-02-32"));
    }

    @Test
    void testValidateBookingDateNonNumeric() {
        BookingValidator validator = new BookingValidator();
        assertFalse(validator.validateBookingDate("abcd-ef-gh"));
    }
}
