package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PricingTest {

    private Pricing pricing = new Pricing();

    @Test
    void testCalculateBasePrice() {
        assertEquals(300.0, pricing.calculateBasePrice(150.0, 2), 0.01);
    }

    @Test
    void testCalculateBasePriceZeroBase() {
        assertEquals(0.0, pricing.calculateBasePrice(0.0, 2), 0.01);
    }

    @Test
    void testCalculateBasePriceZeroPassengers() {
        assertEquals(0.0, pricing.calculateBasePrice(150.0, 0), 0.01);
    }

    @Test
    void testCalculateBasePriceNegativeBase() {
        assertEquals(0.0, pricing.calculateBasePrice(-100.0, 2), 0.01);
    }

    @Test
    void testApplyDiscount() {
        assertEquals(80.0, pricing.applyDiscount(100.0, 0.2), 0.01);
    }

    @Test
    void testApplyDiscountZero() {
        assertEquals(100.0, pricing.applyDiscount(100.0, 0.0), 0.01);
    }

    @Test
    void testApplyDiscountFull() {
        assertEquals(0.0, pricing.applyDiscount(100.0, 1.0), 0.01);
    }

    @Test
    void testApplyDiscountInvalidNegative() {
        assertEquals(100.0, pricing.applyDiscount(100.0, -0.1), 0.01);
    }

    @Test
    void testApplyDiscountInvalidOverOne() {
        assertEquals(100.0, pricing.applyDiscount(100.0, 1.1), 0.01);
    }

    @Test
    void testApplySurcharge() {
        assertEquals(110.0, pricing.applySurcharge(100.0, 0.1), 0.01);
    }

    @Test
    void testApplySurchargeZero() {
        assertEquals(100.0, pricing.applySurcharge(100.0, 0.0), 0.01);
    }

    @Test
    void testApplySurchargeInvalidNegative() {
        assertEquals(100.0, pricing.applySurcharge(100.0, -0.1), 0.01);
    }

    @Test
    void testApplySurchargeInvalidOverHalf() {
        assertEquals(100.0, pricing.applySurcharge(100.0, 0.6), 0.01);
    }

    @Test
    void testCalculateTotal() {
        double total = pricing.calculateTotal(100.0, 2, 0.1, 0.05);
        // base: 200, discount 10% -> 180, surcharge 5% -> 189
        assertEquals(189.0, total, 0.01);
    }

    @Test
    void testCalculateTotalNoDiscountNoSurcharge() {
        double total = pricing.calculateTotal(100.0, 1, 0.0, 0.0);
        assertEquals(100.0, total, 0.01);
    }

    @Test
    void testCalculateTotalWithInvalidDiscount() {
        double total = pricing.calculateTotal(100.0, 1, 2.0, 0.0);
        assertEquals(100.0, total, 0.01); // discount ignored because invalid
    }
}
