package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PaymentTest {

    @Test
    void testConstructor() {
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        assertEquals("CREDIT_CARD", payment.getMethod());
        assertEquals(200.0, payment.getAmount(), 0.01);
        assertFalse(payment.isProcessed());
    }

    @Test
    void testProcessSuccess() {
        Payment payment = new Payment("CREDIT_CARD", 100.0);
        assertTrue(payment.process());
        assertTrue(payment.isProcessed());
    }

    @Test
    void testProcessZeroAmount() {
        Payment payment = new Payment("CREDIT_CARD", 0.0);
        assertFalse(payment.process());
        assertFalse(payment.isProcessed());
    }

    @Test
    void testProcessNegativeAmount() {
        Payment payment = new Payment("CREDIT_CARD", -50.0);
        assertFalse(payment.process());
        assertFalse(payment.isProcessed());
    }

    @Test
    void testRefundAfterProcess() {
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        payment.process();
        double refunded = payment.refund();
        assertEquals(200.0, refunded, 0.01);
        assertFalse(payment.isProcessed());
    }

    @Test
    void testRefundWithoutProcess() {
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        double refunded = payment.refund();
        assertEquals(0.0, refunded, 0.01);
        assertFalse(payment.isProcessed());
    }

    @Test
    void testSetAmount() {
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        payment.setAmount(150.0);
        assertEquals(150.0, payment.getAmount(), 0.01);
    }

    @Test
    void testMultipleProcessCalls() {
        Payment payment = new Payment("CREDIT_CARD", 100.0);
        payment.process();
        // second process should still work? Actually process checks amount>0 and sets processed to true, but doesn't check if already processed. So it will set processed to true again. That's fine.
        assertTrue(payment.process());
        assertTrue(payment.isProcessed());
    }
}
