package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiscountCalculatorTest {

    private DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void testNoDiscount() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 0);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.0, discount, 0.01);
    }

    @Test
    void testLoyaltyDiscount() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 500);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.05, discount, 0.01); // 500/100 = 5%
    }

    @Test
    void testLoyaltyDiscountMax() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 3000);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.20, discount, 0.01); // capped at 20%
    }

    @Test
    void testSeniorDiscount() {
        Passenger passenger = new Passenger("Old", "Man", 70, 0);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.10, discount, 0.01);
    }

    @Test
    void testChildDiscount() {
        Passenger passenger = new Passenger("Kid", "Young", 10, 0);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.15, discount, 0.01);
    }

    @Test
    void testGroupDiscount3to5() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 0);
        double discount = calculator.calculateDiscount(passenger, 4, false);
        assertEquals(0.05, discount, 0.01);
    }

    @Test
    void testGroupDiscount6Plus() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 0);
        double discount = calculator.calculateDiscount(passenger, 10, false);
        assertEquals(0.10, discount, 0.01);
    }

    @Test
    void testMultipleDiscountsTakeHighest() {
        Passenger passenger = new Passenger("Jane", "Doe", 70, 200); // senior 10%, loyalty 2%
        double discount = calculator.calculateDiscount(passenger, 5, false); // group 5%
        // should take max: 10%
        assertEquals(0.10, discount, 0.01);
    }

    @Test
    void testPeakSeasonNoDiscount() {
        Passenger passenger = new Passenger("Jane", "Doe", 70, 200);
        double discount = calculator.calculateDiscount(passenger, 10, true);
        assertEquals(0.0, discount, 0.01);
    }

    @Test
    void testEdgeCaseAgeExactly60() {
        Passenger passenger = new Passenger("Jane", "Doe", 60, 0);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.10, discount, 0.01);
    }

    @Test
    void testEdgeCaseAgeExactly12() {
        Passenger passenger = new Passenger("Jane", "Doe", 12, 0);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.0, discount, 0.01); // not <12
    }

    @Test
    void testEdgeCaseGroupSizeExactly3() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 0);
        double discount = calculator.calculateDiscount(passenger, 3, false);
        assertEquals(0.05, discount, 0.01);
    }

    @Test
    void testEdgeCaseGroupSizeExactly6() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 0);
        double discount = calculator.calculateDiscount(passenger, 6, false);
        assertEquals(0.10, discount, 0.01);
    }

    @Test
    void testLoyaltyMinPoints() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 100);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.01, discount, 0.01);
    }

    @Test
    void testLoyaltyBelowMinPoints() {
        Passenger passenger = new Passenger("Jane", "Doe", 30, 99);
        double discount = calculator.calculateDiscount(passenger, 1, false);
        assertEquals(0.0, discount, 0.01);
    }
}
