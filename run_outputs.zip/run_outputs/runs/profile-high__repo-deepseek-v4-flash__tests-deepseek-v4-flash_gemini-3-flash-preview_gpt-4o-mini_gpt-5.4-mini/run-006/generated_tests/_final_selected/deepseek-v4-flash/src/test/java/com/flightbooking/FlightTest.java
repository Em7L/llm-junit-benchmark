package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FlightTest {

    @Test
    void testConstructor() {
        Flight flight = new Flight("AA100", 150.0, 100);
        assertEquals("AA100", flight.getFlightNumber());
        assertEquals(150.0, flight.getBasePrice(), 0.01);
        assertEquals(100, flight.getAvailableSeats());
        assertEquals(100, flight.getTotalSeats());
        assertTrue(flight.hasAvailableSeats());
    }

    @Test
    void testBookSeat() {
        Flight flight = new Flight("AA100", 150.0, 100);
        assertTrue(flight.bookSeat());
        assertEquals(99, flight.getAvailableSeats());
        assertTrue(flight.hasAvailableSeats());
    }

    @Test
    void testBookSeatNoSeats() {
        Flight flight = new Flight("AA100", 150.0, 0);
        assertFalse(flight.bookSeat());
        assertEquals(0, flight.getAvailableSeats());
        assertFalse(flight.hasAvailableSeats());
    }

    @Test
    void testCancelSeat() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.bookSeat();
        flight.cancelSeat();
        assertEquals(100, flight.getAvailableSeats());
    }

    @Test
    void testCancelSeatWhenFull() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.cancelSeat(); // should not increase beyond total
        assertEquals(100, flight.getAvailableSeats());
    }

    @Test
    void testAddAndRemoveBooking() {
        Flight flight = new Flight("AA100", 150.0, 100);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        flight.addBooking(booking);
        assertEquals(1, flight.getBookings().size());
        flight.removeBooking(booking);
        assertTrue(flight.getBookings().isEmpty());
    }

    @Test
    void testSetBasePrice() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.setBasePrice(200.0);
        assertEquals(200.0, flight.getBasePrice(), 0.01);
    }

    @Test
    void testSetTotalSeatsGreaterThanCurrent() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.setTotalSeats(150);
        assertEquals(150, flight.getTotalSeats());
        assertEquals(100, flight.getAvailableSeats()); // available unchanged
    }

    @Test
    void testSetTotalSeatsLessThanCurrent() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.setTotalSeats(80);
        assertEquals(80, flight.getTotalSeats());
        assertEquals(80, flight.getAvailableSeats()); // reduced
    }

    @Test
    void testSetTotalSeatsLessThanAvailable() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.bookSeat(); // 99 available
        flight.setTotalSeats(50); // should cap available to 50
        assertEquals(50, flight.getAvailableSeats());
    }

    @Test
    void testGetBookingsReturnsCopy() {
        Flight flight = new Flight("AA100", 150.0, 100);
        flight.addBooking(new Booking(flight, new Passenger("A", "B", 20, 0), new Payment("CREDIT_CARD", 100.0), 100.0));
        flight.getBookings().clear();
        assertEquals(1, flight.getBookings().size()); // original unaffected
    }
}
