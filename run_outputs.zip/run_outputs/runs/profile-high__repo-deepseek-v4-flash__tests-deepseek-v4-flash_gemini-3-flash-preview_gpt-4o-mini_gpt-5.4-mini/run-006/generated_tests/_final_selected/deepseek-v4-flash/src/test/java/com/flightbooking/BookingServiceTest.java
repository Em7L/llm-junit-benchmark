package com.flightbooking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BookingServiceTest {

    private BookingService service;
    private Flight flight;
    private Passenger passenger;
    private Payment payment;

    @BeforeEach
    void setUp() {
        service = new BookingService();
        flight = new Flight("AA100", 150.0, 100);
        passenger = new Passenger("Jane", "Doe", 25, 0);
        payment = new Payment("CREDIT_CARD", 200.0);
    }

    @Test
    void testCreateBookingSuccess() {
        Booking booking = service.createBooking(flight, passenger, payment, false, 1);
        assertNotNull(booking);
        assertTrue(booking.isConfirmed());
        assertEquals(157.5, booking.getTotalCost(), 0.01);
    }

    @Test
    void testCreateBookingInvalidValidation() {
        assertNull(service.createBooking(null, passenger, payment, false, 1));
    }

    @Test
    void testCreateBookingNoSeats() {
        flight.setTotalSeats(0);
        assertNull(service.createBooking(flight, passenger, payment, false, 1));
    }

    @Test
    void testCancelBooking() {
        Booking booking = service.createBooking(flight, passenger, payment, false, 1);
        assertNotNull(booking);
        double refund = service.cancelBooking(booking);
        assertEquals(0.0, refund, 0.01);
        assertTrue(booking.isCancelled());
        assertFalse(booking.isConfirmed());
    }

    @Test
    void testCancelBookingAlreadyCancelled() {
        Booking booking = service.createBooking(flight, passenger, payment, false, 1);
        service.cancelBooking(booking);
        double refund = service.cancelBooking(booking);
        assertEquals(0.0, refund, 0.01);
    }

    @Test
    void testModifyBooking() {
        Booking booking = service.createBooking(flight, passenger, payment, false, 1);
        Flight newFlight = new Flight("BB200", 200.0, 50);
        Payment newPayment = new Payment("DEBIT_CARD", 300.0);
        Booking modified = service.modifyBooking(booking, newFlight, false, 2);
        assertNotNull(modified);
        assertEquals(newFlight, modified.getFlight());
        assertTrue(booking.isCancelled());
        assertTrue(modified.isConfirmed());
    }

    @Test
    void testModifyBookingNull() {
        assertNull(service.modifyBooking(null, flight, false, 1));
    }

    @Test
    void testGetBookingsByPassenger() {
        Booking booking1 = service.createBooking(flight, passenger, payment, false, 1);
        Flight flight2 = new Flight("BB200", 300.0, 50);
        Payment payment2 = new Payment("PAYPAL", 500.0);
        Booking booking2 = service.createBooking(flight2, passenger, payment2, false, 2);
        assertEquals(2, service.getBookingsByPassenger(passenger).size());
        service.cancelBooking(booking1);
        assertEquals(1, service.getBookingsByPassenger(passenger).size());
    }

    @Test
    void testGetTotalRevenue() {
        service.createBooking(flight, passenger, payment, false, 1);
        Passenger passenger2 = new Passenger("Bob", "Smith", 30, 0);
        Payment payment2 = new Payment("CREDIT_CARD", 300.0);
        service.createBooking(new Flight("CC300", 200.0, 30), passenger2, payment2, false, 1);
        double revenue = service.getTotalRevenue();
        assertTrue(revenue > 0);
    }

    @Test
    void testAllBookings() {
        assertTrue(service.getAllBookings().isEmpty());
        service.createBooking(flight, passenger, payment, false, 1);
        assertEquals(1, service.getAllBookings().size());
    }
}
