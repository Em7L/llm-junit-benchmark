package com.flightbooking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class BookingServiceTest {
    private BookingService bookingService;
    private Flight flight;
    private Passenger passenger;

    @BeforeEach
    void setUp() {
        bookingService = new BookingService();
        flight = new Flight("AF123", 200.0, 100);
        passenger = new Passenger("Alice", "Smith", 25, 0);
    }

    @Test
    void testCreateBookingSuccess() {
        Payment payment = new Payment("DEBIT_CARD", 200.0);
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);

        assertNotNull(booking);
        assertEquals(99, flight.getAvailableSeats());
        assertTrue(booking.isConfirmed());
        assertEquals(1, bookingService.getAllBookings().size());
    }

    @Test
    void testCreateBookingWithCreditCardSurcharge() {
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);

        // Base 200 + 5% surcharge = 210
        assertNotNull(booking);
        assertEquals(210.0, booking.getTotalCost(), 0.001);
    }

    @Test
    void testCreateBookingNoSeats() {
        Flight fullFlight = new Flight("FULL", 100.0, 0);
        Payment payment = new Payment("PAYPAL", 100.0);
        Booking booking = bookingService.createBooking(fullFlight, passenger, payment, false, 1);

        assertNull(booking);
    }

    @Test
    void testCancelBookingFlow() {
        Payment payment = new Payment("DEBIT_CARD", 100.0);
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);
        
        double refund = bookingService.cancelBooking(booking);
        
        // 10 days before: 25% fee, 75% refund of 200.0 = 150.0
        assertEquals(150.0, refund, 0.001);
        assertTrue(booking.isCancelled());
        assertEquals(100, flight.getAvailableSeats());
        assertEquals(0, bookingService.getAllBookings().size());
    }

    @Test
    void testGetBookingsByPassenger() {
        Payment p1 = new Payment("PAYPAL", 200.0);
        bookingService.createBooking(flight, passenger, p1, false, 1);
        
        List<Booking> result = bookingService.getBookingsByPassenger(passenger);
        assertEquals(1, result.size());
        assertEquals("Alice Smith", result.get(0).getPassenger().getFullName());
    }

    @Test
    void testModifyBooking() {
        Payment payment = new Payment("DEBIT_CARD", 200.0);
        Booking oldBooking = bookingService.createBooking(flight, passenger, payment, false, 1);
        Flight newFlight = new Flight("AF456", 300.0, 50);

        Booking newBooking = bookingService.modifyBooking(oldBooking, newFlight, false, 1);

        assertNotNull(newBooking);
        assertTrue(oldBooking.isCancelled());
        assertEquals(newFlight.getFlightNumber(), newBooking.getFlight().getFlightNumber());
        assertEquals(300.0, newBooking.getTotalCost(), 0.001);
    }
}