package com.flightbooking;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import static org.junit.jupiter.api.Assertions.*;

public class BookingFormatterTest {

    @Test
    void testFormatBookingSummary() {
        Flight f = new Flight("LH400", 500, 10);
        Passenger p = new Passenger("Bob", "Vance", 45, 0);
        Payment pay = new Payment("PAYPAL", 500);
        Booking b = new Booking(f, p, pay, 500.556);

        String summary = BookingFormatter.formatBookingSummary(b);
        
        assertTrue(summary.contains("Booking ID:"));
        assertTrue(summary.contains("Flight: LH400"));
        assertTrue(summary.contains("Passenger: Bob Vance"));
        assertTrue(summary.contains("Total Cost: $500.56"));
    }

    @Test
    void testFormatRevenueReport() {
        Flight f = new Flight("X", 100, 10);
        Passenger p = new Passenger("A", "B", 20, 0);
        
        Booking b1 = new Booking(f, p, new Payment("P", 100), 100.0);
        b1.confirm();
        
        Booking b2 = new Booking(f, p, new Payment("P", 50), 50.0);
        // b2 not confirmed

        String report = BookingFormatter.formatRevenueReport(Arrays.asList(b1, b2));
        assertEquals("Total confirmed bookings: 1, Revenue: $100.00", report);
    }

    @Test
    void testFormatItineraryEmpty() {
        assertEquals("No bookings in itinerary.", BookingFormatter.formatItinerary(null));
    }
}