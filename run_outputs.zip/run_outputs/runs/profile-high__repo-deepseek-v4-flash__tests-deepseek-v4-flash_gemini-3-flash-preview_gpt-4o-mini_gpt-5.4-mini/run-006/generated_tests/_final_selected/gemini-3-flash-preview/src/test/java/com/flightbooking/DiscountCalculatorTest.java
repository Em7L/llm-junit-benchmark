package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiscountCalculatorTest {
    private final DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void testLoyaltyDiscount() {
        Passenger p = new Passenger("A", "B", 30, 1000);
        double discount = calculator.calculateDiscount(p, 1, false);
        // 1000 points / 100 = 10% -> 0.10
        assertEquals(0.10, discount, 0.001);
    }

    @Test
    void testSeniorDiscount() {
        Passenger p = new Passenger("A", "B", 65, 0);
        double discount = calculator.calculateDiscount(p, 1, false);
        assertEquals(0.10, discount, 0.001);
    }

    @Test
    void testChildDiscount() {
        Passenger p = new Passenger("A", "B", 10, 0);
        double discount = calculator.calculateDiscount(p, 1, false);
        assertEquals(0.15, discount, 0.001);
    }

    @Test
    void testGroupDiscount() {
        Passenger p = new Passenger("A", "B", 30, 0);
        assertEquals(0.05, calculator.calculateDiscount(p, 4, false), 0.001);
        assertEquals(0.10, calculator.calculateDiscount(p, 7, false), 0.001);
    }

    @Test
    void testPeakSeasonOverridesAll() {
        Passenger p = new Passenger("A", "B", 70, 5000);
        double discount = calculator.calculateDiscount(p, 10, true);
        assertEquals(0.0, discount);
    }
}