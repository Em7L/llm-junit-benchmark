package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CancellationTest {
    private final Cancellation cancellation = new Cancellation();

    @Test
    void testComputeRefundAmountTiers() {
        Flight f = new Flight("F", 100, 10);
        Passenger p = new Passenger("N", "M", 20, 0);
        Payment pay = new Payment("DEBIT_CARD", 100.0);
        pay.process();
        Booking b = new Booking(f, p, pay, 100.0);

        // 14+ days -> 10% fee -> 90.0 refund
        assertEquals(90.0, cancellation.computeRefundAmount(b, 15), 0.001);
        // 7-13 days -> 25% fee -> 75.0 refund
        assertEquals(75.0, cancellation.computeRefundAmount(b, 8), 0.001);
        // 3-6 days -> 50% fee -> 50.0 refund
        assertEquals(50.0, cancellation.computeRefundAmount(b, 4), 0.001);
        // 1-2 days -> 75% fee -> 25.0 refund
        assertEquals(25.0, cancellation.computeRefundAmount(b, 1), 0.001);
        // 0 days -> 100% fee -> 0.0 refund
        assertEquals(0.0, cancellation.computeRefundAmount(b, 0), 0.001);
    }

    @Test
    void testProcessCancellationLoyaltyPoints() {
        Flight f = new Flight("F", 100, 10);
        Passenger p = new Passenger("N", "M", 20, 0);
        Payment pay = new Payment("DEBIT_CARD", 100.0);
        pay.process();
        Booking b = new Booking(f, p, pay, 100.0);

        cancellation.processCancellation(b, 15);
        
        // Refund is 90.0, loyalty gain is 10% of refund = 9
        assertEquals(9, p.getLoyaltyPoints());
        assertFalse(pay.isProcessed());
        assertTrue(b.isCancelled());
    }
}