package com.flightbooking;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BookingServiceWorkflowTest {

    private static final double EPS = 1e-9;

    @Test
    void createBookingCalculatesDiscountAndSurchargeThenLinksEntities() {
        BookingService service = new BookingService();
        Flight flight = new Flight("AA400", 100.0, 2);
        Passenger passenger = new Passenger("Sam", "Hill", 30, 0);
        Payment payment = new Payment("CREDIT_CARD", 100.0);

        Booking booking = service.createBooking(flight, passenger, payment, false, 1);

        assertNotNull(booking);
        assertTrue(booking.isConfirmed());
        assertTrue(payment.isProcessed());
        assertEquals(105.0, booking.getTotalCost(), EPS);
        assertEquals(1, flight.getAvailableSeats());
        assertEquals(1, flight.getBookings().size());
        assertEquals(1, passenger.getBookings().size());
        assertEquals(1, service.getAllBookings().size());
        assertEquals(105.0, service.getTotalRevenue(), EPS);
    }

    @Test
    void createBookingAppliesBestDiscountForLargeGroupAndNoCreditCardSurchargeForOtherMethods() {
        BookingService service = new BookingService();
        Flight flight = new Flight("AA401", 100.0, 3);
        Passenger passenger = new Passenger("Lena", "Fox", 35, 0);
        Payment payment = new Payment("PAYPAL", 100.0);

        Booking booking = service.createBooking(flight, passenger, payment, false, 6);

        assertNotNull(booking);
        assertEquals(90.0, booking.getTotalCost(), EPS);
    }

    @Test
    void createBookingReturnsNullWhenValidationOrSeatAvailabilityFails() {
        BookingService service = new BookingService();

        assertNull(service.createBooking(null, new Passenger("A", "B", 20, 0), new Payment("CREDIT_CARD", 10.0), false, 1));
        assertNull(service.createBooking(new Flight("AA402", 100.0, 0), new Passenger("A", "B", 20, 0), new Payment("CREDIT_CARD", 10.0), false, 1));
    }

    @Test
    void cancelBookingRemovesBookingAndReturnsRefundAmount() {
        BookingService service = new BookingService();
        Flight flight = new Flight("AA403", 100.0, 2);
        Passenger passenger = new Passenger("Ivy", "Green", 27, 0);
        Payment payment = new Payment("DEBIT_CARD", 100.0);

        Booking booking = service.createBooking(flight, passenger, payment, false, 1);
        assertNotNull(booking);

        double refund = service.cancelBooking(booking);

        assertEquals(90.0, refund, EPS);
        assertTrue(booking.isCancelled());
        assertEquals(0, service.getAllBookings().size());
        assertEquals(0, flight.getBookings().size());
        assertEquals(0, passenger.getBookings().size());
        assertEquals(0.0, service.getTotalRevenue(), EPS);
    }

    @Test
    void cancelBookingReturnsZeroForNullOrAlreadyCancelledBooking() {
        BookingService service = new BookingService();

        assertEquals(0.0, service.cancelBooking(null), EPS);

        Booking booking = new Booking(new Flight("AA404", 100.0, 1), new Passenger("Ivy", "Green", 27, 0),
                new Payment("DEBIT_CARD", 100.0), 100.0);
        booking.cancel();
        assertEquals(0.0, service.cancelBooking(booking), EPS);
    }

    @Test
    void modifyBookingCreatesNewBookingForSamePassengerAndCancelsOldOne() {
        BookingService service = new BookingService();
        Flight originalFlight = new Flight("AA405", 100.0, 2);
        Flight newFlight = new Flight("BB500", 200.0, 2);
        Passenger passenger = new Passenger("Nia", "Cole", 29, 0);
        Payment payment = new Payment("PAYPAL", 100.0);

        Booking original = service.createBooking(originalFlight, passenger, payment, false, 1);
        assertNotNull(original);

        Booking modified = service.modifyBooking(original, newFlight, false, 1);

        assertNotNull(modified);
        assertTrue(original.isCancelled());
        assertTrue(modified.isConfirmed());
        assertEquals(passenger, modified.getPassenger());
        assertEquals(newFlight, modified.getFlight());
        assertEquals(1, service.getAllBookings().size());
        assertEquals(1, newFlight.getBookings().size());
        assertEquals(0, originalFlight.getBookings().size());
    }

    @Test
    void getBookingsByPassengerFiltersByFullNameAndIgnoresCancelledBookings() {
        BookingService service = new BookingService();
        Flight flight1 = new Flight("AA406", 100.0, 2);
        Flight flight2 = new Flight("AA407", 100.0, 2);
        Passenger passenger1 = new Passenger("Alex", "Kim", 31, 0);
        Passenger passenger2 = new Passenger("Alex", "Kim", 44, 0);

        Booking booking1 = service.createBooking(flight1, passenger1, new Payment("PAYPAL", 100.0), false, 1);
        Booking booking2 = service.createBooking(flight2, passenger2, new Payment("PAYPAL", 100.0), false, 1);
        assertNotNull(booking1);
        assertNotNull(booking2);

        service.cancelBooking(booking1);

        List<Booking> bookings = service.getBookingsByPassenger(new Passenger("Alex", "Kim", 20, 0));
        assertEquals(1, bookings.size());
        assertEquals(booking2, bookings.get(0));
    }

    @Test
    void getAllBookingsReturnsDefensiveCopy() {
        BookingService service = new BookingService();
        service.getAllBookings().add(new Booking(new Flight("AA408", 100.0, 1), new Passenger("P", "Q", 20, 0),
                new Payment("PAYPAL", 100.0), 100.0));

        assertEquals(0, service.getAllBookings().size());
    }
}