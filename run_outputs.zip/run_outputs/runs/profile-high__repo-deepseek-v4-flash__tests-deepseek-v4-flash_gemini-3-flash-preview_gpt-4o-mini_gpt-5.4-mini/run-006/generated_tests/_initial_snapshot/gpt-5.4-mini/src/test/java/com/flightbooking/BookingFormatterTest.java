package com.flightbooking;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BookingFormatterTest {

    @Test
    void formatBookingSummaryHandlesNullAndFormatsFields() {
        assertEquals("No booking.", BookingFormatter.formatBookingSummary(null));

        Flight flight = new Flight("AA900", 150.0, 1);
        Passenger passenger = new Passenger("Rita", "Moss", 33, 0);
        Payment payment = new Payment("CREDIT_CARD", 150.0);
        Booking booking = new Booking(flight, passenger, payment, 189.5);

        String summary = BookingFormatter.formatBookingSummary(booking);

        assertEquals("Booking ID: " + booking.getId() + "\n" +
                "Flight: AA900\n" +
                "Passenger: Rita Moss\n" +
                "Total Cost: $189.50\n" +
                "Confirmed: No\n" +
                "Cancelled: No\n", summary);
    }

    @Test
    void formatItineraryHandlesEmptyAndFormatsMultipleBookings() {
        assertEquals("No bookings in itinerary.", BookingFormatter.formatItinerary(null));
        assertEquals("No bookings in itinerary.", BookingFormatter.formatItinerary(List.of()));

        Passenger passenger = new Passenger("Rita", "Moss", 33, 0);
        Booking first = new Booking(new Flight("AA901", 100.0, 1), passenger, new Payment("PAYPAL", 100.0), 100.0);
        Booking second = new Booking(new Flight("AA902", 120.0, 1), passenger, new Payment("PAYPAL", 120.0), 108.0);

        String itinerary = BookingFormatter.formatItinerary(List.of(first, second));

        assertEquals("Itinerary for Rita Moss:\n" +
                "- AA901 $100.00\n" +
                "- AA902 $108.00\n", itinerary);
    }

    @Test
    void formatRevenueReportCountsOnlyConfirmedBookings() {
        Passenger passenger = new Passenger("Rita", "Moss", 33, 0);
        Flight flight1 = new Flight("AA903", 100.0, 1);
        Flight flight2 = new Flight("AA904", 100.0, 1);
        Booking confirmed = new Booking(flight1, passenger, new Payment("PAYPAL", 100.0), 100.0);
        Booking unconfirmed = new Booking(flight2, passenger, new Payment("PAYPAL", 200.0), 200.0);

        confirmed.confirm();

        String report = BookingFormatter.formatRevenueReport(List.of(confirmed, unconfirmed));

        assertEquals("Total confirmed bookings: 1, Revenue: $100.00", report);
    }
}