package com.flightbooking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BookingServiceTest {

    private BookingService bookingService;
    private Flight flight;
    private Passenger passenger;
    private Payment payment;

    @BeforeEach
    void setUp() {
        bookingService = new BookingService();
        flight = new Flight("AA100", 150.0, 2);
        passenger = new Passenger("John", "Doe", 30, 500);
        payment = new Payment("CREDIT_CARD", 150.0);
    }

    @Test
    void createBookingSuccessful() {
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);
        assertNotNull(booking);
        assertEquals(passenger, booking.getPassenger());
        assertTrue(booking.isConfirmed());
    }

    @Test
    void createBookingInvalidPassenger() {
        Passenger invalidPassenger = new Passenger("John", "Doe", -5, 500);
        Booking booking = bookingService.createBooking(flight, invalidPassenger, payment, false, 1);
        assertNull(booking);
    }

    @Test
    void createBookingFlightNotAvailable() {
        flight.bookSeat(); // Book the only available seat
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);
        assertNull(booking);
    }

    @Test
    void cancelBookingSuccessful() {
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);
        double refund = bookingService.cancelBooking(booking);
        assertTrue(booking.isCancelled());
        assertTrue(refund > 0);
    }

    @Test
    void cancelBookingAlreadyCancelled() {
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);
        bookingService.cancelBooking(booking);
        double refund = bookingService.cancelBooking(booking);
        assertEquals(0.0, refund);
    }

    @Test
    void modifyBookingSuccessful() {
        Booking booking = bookingService.createBooking(flight, passenger, payment, false, 1);
        Flight newFlight = new Flight("BB200", 200.0, 2);
        Booking modifiedBooking = bookingService.modifyBooking(booking, newFlight, false, 1);
        assertNotNull(modifiedBooking);
        assertEquals(newFlight, modifiedBooking.getFlight());
        assertTrue(modifiedBooking.isConfirmed());
    }

    @Test
    void getBookingsByPassenger() {
        bookingService.createBooking(flight, passenger, payment, false, 1);
        assertEquals(1, bookingService.getBookingsByPassenger(passenger).size());
    }

    @Test
    void getTotalRevenue() {
        bookingService.createBooking(flight, passenger, payment, false, 1);
        assertEquals(150.0, bookingService.getTotalRevenue());
    }
}
