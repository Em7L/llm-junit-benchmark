package com.flightbooking;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

public class BookingValidatorTest {
    private final BookingValidator validator = new BookingValidator();

    @Test
    void testValidateBookingBasic() {
        Flight f = new Flight("X", 100, 10);
        Passenger p = new Passenger("J", "D", 25, 0);
        Payment pay = new Payment("CREDIT_CARD", 100);

        assertTrue(validator.validateBooking(f, p, pay));
    }

    @Test
    void testValidateBookingInvalidPayment() {
        Flight f = new Flight("X", 100, 10);
        Passenger p = new Passenger("J", "D", 25, 0);
        Payment pay = new Payment("CRYPTO", 100);

        assertFalse(validator.validateBooking(f, p, pay));
    }

    @ParameterizedTest
    @ValueSource(strings = {"2023-05-15", "2030-12-31", "2020-01-01"})
    void testValidBookingDates(String date) {
        assertTrue(validator.validateBookingDate(date));
    }

    @ParameterizedTest
    @ValueSource(strings = {"2019-12-31", "2031-01-01", "2023/05/15", "invalid", "2023-13-01", "2023-05-32"})
    void testInvalidBookingDates(String date) {
        assertFalse(validator.validateBookingDate(date));
    }

    @Test
    void testPassengerAgeRange() {
        Passenger p = new Passenger("A", "B", 15, 0);
        assertTrue(validator.validatePassengerAge(p, 10, 20));
        assertFalse(validator.validatePassengerAge(p, 20, 30));
    }
}