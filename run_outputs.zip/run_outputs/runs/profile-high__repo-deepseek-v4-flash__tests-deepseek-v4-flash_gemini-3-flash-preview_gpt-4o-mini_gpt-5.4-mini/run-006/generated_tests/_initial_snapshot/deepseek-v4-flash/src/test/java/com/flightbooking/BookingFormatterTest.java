package com.flightbooking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class BookingFormatterTest {

    private Booking booking;
    private List<Booking> bookings;

    @BeforeEach
    void setUp() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("John", "Doe", 30, 100);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        booking = new Booking(flight, passenger, payment, 200.0);
        booking.confirm();
        bookings = new ArrayList<>();
        bookings.add(booking);
    }

    @Test
    void testFormatBookingSummary() {
        String summary = BookingFormatter.formatBookingSummary(booking);
        assertTrue(summary.contains("Booking ID: "));
        assertTrue(summary.contains("AA100"));
        assertTrue(summary.contains("John Doe"));
        assertTrue(summary.contains("200.00"));
        assertTrue(summary.contains("Confirmed: Yes"));
        assertTrue(summary.contains("Cancelled: No"));
    }

    @Test
    void testFormatBookingSummaryNull() {
        assertEquals("No booking.", BookingFormatter.formatBookingSummary(null));
    }

    @Test
    void testFormatItinerary() {
        String itinerary = BookingFormatter.formatItinerary(bookings);
        assertTrue(itinerary.contains("Itinerary for John Doe:"));
        assertTrue(itinerary.contains("- AA100 $200.00"));
    }

    @Test
    void testFormatItineraryNullList() {
        assertEquals("No bookings in itinerary.", BookingFormatter.formatItinerary(null));
    }

    @Test
    void testFormatItineraryEmptyList() {
        assertEquals("No bookings in itinerary.", BookingFormatter.formatItinerary(new ArrayList<>()));
    }

    @Test
    void testFormatRevenueReport() {
        String report = BookingFormatter.formatRevenueReport(bookings);
        assertEquals("Total confirmed bookings: 1, Revenue: $200.00", report);
    }

    @Test
    void testFormatRevenueReportNoConfirmed() {
        bookings.get(0).cancel();
        String report = BookingFormatter.formatRevenueReport(bookings);
        assertEquals("Total confirmed bookings: 0, Revenue: $0.00", report);
    }

    @Test
    void testFormatRevenueReportEmptyList() {
        String report = BookingFormatter.formatRevenueReport(new ArrayList<>());
        assertEquals("Total confirmed bookings: 0, Revenue: $0.00", report);
    }
}
