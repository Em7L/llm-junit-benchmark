package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BookingTest {

    @Test
    void testConfirmSuccess() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        assertTrue(booking.confirm());
        assertTrue(booking.isConfirmed());
        assertFalse(booking.isCancelled());
        assertTrue(payment.isProcessed());
    }

    @Test
    void testConfirmAlreadyConfirmed() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        booking.confirm();
        assertFalse(booking.confirm());
        assertTrue(booking.isConfirmed());
    }

    @Test
    void testConfirmAlreadyCancelled() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        booking.cancel();
        assertFalse(booking.confirm());
        assertFalse(booking.isConfirmed());
        assertTrue(booking.isCancelled());
    }

    @Test
    void testCancelSuccess() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        assertTrue(booking.cancel());
        assertTrue(booking.isCancelled());
        assertFalse(booking.isConfirmed());
    }

    @Test
    void testCancelAlreadyCancelled() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        booking.cancel();
        assertFalse(booking.cancel());
        assertTrue(booking.isCancelled());
    }

    @Test
    void testGetters() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 100);
        Payment payment = new Payment("PAYPAL", 300.0);
        Booking booking = new Booking(flight, passenger, payment, 300.0);
        assertEquals(1, booking.getId()); // assuming first booking id starts at 1; may need to reset static state
        assertEquals(flight, booking.getFlight());
        assertEquals(passenger, booking.getPassenger());
        assertEquals(payment, booking.getPayment());
        assertEquals(300.0, booking.getTotalCost(), 0.01);
    }

    @Test
    void testSetTotalCost() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 100);
        Payment payment = new Payment("DEBIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        booking.setTotalCost(250.0);
        assertEquals(250.0, booking.getTotalCost(), 0.01);
    }

    @Test
    void testInitialState() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        assertFalse(booking.isConfirmed());
        assertFalse(booking.isCancelled());
        assertFalse(payment.isProcessed());
    }

    @Test
    void testConfirmWithFailedPayment() {
        // Payment.amount <= 0 causes process to fail
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 0.0);
        Booking booking = new Booking(flight, passenger, payment, 0.0);
        assertFalse(booking.confirm());
        assertFalse(booking.isConfirmed());
        assertFalse(payment.isProcessed());
    }
}
