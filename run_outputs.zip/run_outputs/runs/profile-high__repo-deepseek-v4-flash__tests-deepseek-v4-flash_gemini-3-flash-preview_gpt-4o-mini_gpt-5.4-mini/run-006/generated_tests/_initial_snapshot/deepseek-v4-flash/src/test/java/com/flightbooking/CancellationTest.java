package com.flightbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CancellationTest {

    private Cancellation cancellation = new Cancellation();

    @Test
    void testComputeRefundAmount14Days() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        double refund = cancellation.computeRefundAmount(booking, 14);
        assertEquals(180.0, refund, 0.01); // fee 10%
    }

    @Test
    void testComputeRefundAmount7Days() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        double refund = cancellation.computeRefundAmount(booking, 7);
        assertEquals(150.0, refund, 0.01); // fee 25%
    }

    @Test
    void testComputeRefundAmount3Days() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        double refund = cancellation.computeRefundAmount(booking, 3);
        assertEquals(100.0, refund, 0.01); // fee 50%
    }

    @Test
    void testComputeRefundAmount1Day() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        double refund = cancellation.computeRefundAmount(booking, 1);
        assertEquals(50.0, refund, 0.01); // fee 75%
    }

    @Test
    void testComputeRefundAmount0Days() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        double refund = cancellation.computeRefundAmount(booking, 0);
        assertEquals(0.0, refund, 0.01); // full fee
    }

    @Test
    void testComputeRefundAmountNullBooking() {
        assertEquals(0.0, cancellation.computeRefundAmount(null, 10), 0.01);
    }

    @Test
    void testComputeRefundAmountAlreadyCancelled() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        booking.cancel();
        assertEquals(0.0, cancellation.computeRefundAmount(booking, 10), 0.01);
    }

    @Test
    void testProcessCancellationSuccess() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        assertTrue(cancellation.processCancellation(booking, 10));
        assertTrue(booking.isCancelled());
        assertFalse(payment.isProcessed()); // refunded
        assertEquals(100, passenger.getLoyaltyPoints()); // refund * 0.1 = 150*0.1=15, but integer cast: (int)(150*0.1)=15, not 100. Actually computeRefundAmount returns 150 for 10 days, so refund=150, then (int)(150*0.1)=15. So assert 15.
    }

    @Test
    void testProcessCancellationNullBooking() {
        assertFalse(cancellation.processCancellation(null, 10));
    }

    @Test
    void testProcessCancellationAlreadyCancelled() {
        Flight flight = new Flight("AA100", 150.0, 50);
        Passenger passenger = new Passenger("Jane", "Doe", 25, 0);
        Payment payment = new Payment("CREDIT_CARD", 200.0);
        Booking booking = new Booking(flight, passenger, payment, 200.0);
        booking.cancel();
        assertFalse(cancellation.processCancellation(booking, 10));
    }
}
