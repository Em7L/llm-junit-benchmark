package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;

class EventCatalogTest {

    @Test
    void addAndFindEventByIdWorks() {
        EventCatalog catalog = new EventCatalog();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));

        catalog.addEvent(event);

        assertEquals(event, catalog.findEventById("E1"));
        assertNull(catalog.findEventById("missing"));
    }

    @Test
    void getEventsByTypeReturnsOnlyMatchingEvents() {
        EventCatalog catalog = new EventCatalog();
        Event concert = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));
        Event theater = new Event("E2", "Play", EventType.THEATER, new BigDecimal("60.00"), LocalDate.now().plusDays(12));
        catalog.addEvent(concert);
        catalog.addEvent(theater);

        List<Event> concerts = catalog.getEventsByType(EventType.CONCERT);

        assertEquals(1, concerts.size());
        assertEquals(concert, concerts.get(0));
    }

    @Test
    void getEventsInDateRangeHonorsTypeFilterAndRangeBoundaries() {
        EventCatalog catalog = new EventCatalog();
        LocalDate start = LocalDate.now().plusDays(5);
        LocalDate end = LocalDate.now().plusDays(15);
        Event inRangeConcert = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));
        Event inRangeTheater = new Event("E2", "Play", EventType.THEATER, new BigDecimal("60.00"), LocalDate.now().plusDays(15));
        Event outOfRange = new Event("E3", "Late", EventType.CONCERT, new BigDecimal("70.00"), LocalDate.now().plusDays(20));
        catalog.addEvent(inRangeConcert);
        catalog.addEvent(inRangeTheater);
        catalog.addEvent(outOfRange);

        List<Event> filtered = catalog.getEventsInDateRange(start, end, EventType.CONCERT);

        assertEquals(1, filtered.size());
        assertEquals(inRangeConcert, filtered.get(0));
        assertTrue(catalog.getEventsInDateRange(start, end, null).contains(inRangeTheater));
        assertFalse(catalog.getEventsInDateRange(start, end, EventType.SPORT).contains(inRangeConcert));
    }

    @Test
    void reduceSeatAvailabilityReturnsFalseForMissingEventOrInsufficientSeats() {
        EventCatalog catalog = new EventCatalog();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));
        event.seatAvailability.put(SeatCategory.STANDARD, 2);
        catalog.addEvent(event);

        assertFalse(catalog.reduceSeatAvailability("missing", SeatCategory.STANDARD, 1));
        assertFalse(catalog.reduceSeatAvailability("E1", SeatCategory.STANDARD, 3));
        assertTrue(catalog.reduceSeatAvailability("E1", SeatCategory.STANDARD, 2));
        assertEquals(0, event.seatAvailability.get(SeatCategory.STANDARD));
    }
}
