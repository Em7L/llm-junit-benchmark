package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class PricingAndDiscountTest {

    @Test
    void calculateBasePriceUsesEventTypeAndSeatCategoryMultipliers() {
        PricingEngine engine = new PricingEngine();
        Event concert = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));
        Event sport = new Event("E2", "Sport", EventType.SPORT, new BigDecimal("80.00"), LocalDate.now().plusDays(10));
        Event theater = new Event("E3", "Theater", EventType.THEATER, new BigDecimal("60.00"), LocalDate.now().plusDays(10));

        assertEquals(0, new BigDecimal("150.00").compareTo(engine.calculateBasePrice(concert, SeatCategory.VIP)));
        assertEquals(0, new BigDecimal("80.00").compareTo(engine.calculateBasePrice(sport, SeatCategory.STANDARD)));
        assertEquals(0, new BigDecimal("84.00").compareTo(engine.calculateBasePrice(theater, SeatCategory.PREMIUM)));
        assertEquals(0, new BigDecimal("78.00").compareTo(engine.calculateBasePrice(theater, SeatCategory.BALCONY)));
    }

    @Test
    void applySeasonalSurchargeHandlesNullPastAndWindowThresholds() {
        PricingEngine engine = new PricingEngine();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(30));

        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(event, null));
        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(new Event("E2", "Concert", EventType.CONCERT, new BigDecimal("100.00"), null), LocalDate.now()));
        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(event, LocalDate.now().plusDays(40)));
        assertEquals(0, new BigDecimal("10.00").compareTo(engine.applySeasonalSurcharge(event, LocalDate.now().plusDays(23))));
        assertEquals(0, new BigDecimal("5.00").compareTo(engine.applySeasonalSurcharge(event, LocalDate.now().plusDays(1))));
    }

    @Test
    void calculateServiceFeeAppliesMinimumMaximumAndExtraThresholdCharges() {
        FeeCalculator calculator = new FeeCalculator();

        assertEquals(0, new BigDecimal("5.00").compareTo(calculator.calculateServiceFee(new BigDecimal("100.00"))));
        assertEquals(0, new BigDecimal("20.00").compareTo(calculator.calculateServiceFee(new BigDecimal("1000.00"))));
        assertEquals(0, new BigDecimal("40.00").compareTo(calculator.calculateServiceFee(new BigDecimal("1500.00"))));
        assertEquals(0, new BigDecimal("50.00").compareTo(calculator.calculateServiceFee(new BigDecimal("4000.00"))));
        assertEquals(0, new BigDecimal("50.00").compareTo(calculator.calculateServiceFee(new BigDecimal("6000.00"))));
    }

    @Test
    void calculateServiceFeeAndTaxRejectInvalidAmounts() {
        FeeCalculator calculator = new FeeCalculator();

        assertFalse(false); // intentional placeholder avoided by real exception assertions below
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateServiceFee(null));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateServiceFee(new BigDecimal("0")));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateTax(null, EventType.CONCERT));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateTax(new BigDecimal("-1"), EventType.CONCERT));
    }

    @Test
    void calculateTaxUsesEventTypeRates() {
        FeeCalculator calculator = new FeeCalculator();

        assertEquals(0, new BigDecimal("8.00").compareTo(calculator.calculateTax(new BigDecimal("100.00"), EventType.CONCERT)));
        assertEquals(0, new BigDecimal("6.00").compareTo(calculator.calculateTax(new BigDecimal("100.00"), EventType.SPORT)));
        assertEquals(0, new BigDecimal("10.00").compareTo(calculator.calculateTax(new BigDecimal("100.00"), EventType.THEATER)));
    }

    @Test
    void discountEngineCalculatesEachDiscountAndBestDiscountCorrectly() {
        DiscountRuleEngine engine = new DiscountRuleEngine();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(20));
        Order order = new Order(event, "Alice", 6, SeatCategory.VIP, true, true, true);

        assertTrue(engine.isEligibleForDiscount(order));
        assertEquals(0, new BigDecimal("170.00").compareTo(engine.calculateDiscount(order)));
        assertEquals(0, new BigDecimal("90.00").compareTo(engine.getBestDiscount(order)));
    }

    @Test
    void loyaltyDiscountIsCappedAndEarlyBirdRequiresAtLeastFourteenDays() {
        DiscountRuleEngine engine = new DiscountRuleEngine();
        Event expensive = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("500.00"), LocalDate.now().plusDays(20));
        Event soon = new Event("E2", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));

        Order loyaltyOrder = new Order(expensive, "Bob", 1, SeatCategory.STANDARD, true, false, false);
        Order earlyBirdTooSoon = new Order(soon, "Bob", 1, SeatCategory.STANDARD, false, true, false);

        assertEquals(0, new BigDecimal("20").compareTo(engine.calculateDiscount(loyaltyOrder)));
        assertEquals(BigDecimal.ZERO, engine.calculateDiscount(earlyBirdTooSoon));
    }
}
