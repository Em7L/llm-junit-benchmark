package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class EventTest {

    @Test
    void validEventForFuturePositivePriceIsBookable() {
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(1));

        assertTrue(event.isValidForBooking());
    }

    @Test
    void invalidWhenDateIsTodayOrEarlier() {
        Event todayEvent = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now());
        Event pastEvent = new Event("E2", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().minusDays(1));

        assertFalse(todayEvent.isValidForBooking());
        assertFalse(pastEvent.isValidForBooking());
    }

    @Test
    void hasAvailableSeatsUsesCategorySpecificAvailability() {
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(1));
        event.seatAvailability.put(SeatCategory.VIP, 3);

        assertTrue(event.hasAvailableSeats(SeatCategory.VIP, 3));
        assertFalse(event.hasAvailableSeats(SeatCategory.VIP, 4));
        assertFalse(event.hasAvailableSeats(SeatCategory.PREMIUM, 1));
    }

    @Test
    void reduceSeatsDecrementsAvailabilityAndRejectsInsufficientSeats() {
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(1));
        event.seatAvailability.put(SeatCategory.STANDARD, 5);

        event.reduceSeats(SeatCategory.STANDARD, 2);

        assertTrue(event.hasAvailableSeats(SeatCategory.STANDARD, 3));
        assertFalse(event.hasAvailableSeats(SeatCategory.STANDARD, 4));
        assertThrows(IllegalArgumentException.class, () -> event.reduceSeats(SeatCategory.STANDARD, 4));
    }
}
