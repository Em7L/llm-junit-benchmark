package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;

class TicketFormatterTest {

    private final TicketFormatter ticketFormatter = new TicketFormatter();

    @Test
    void formatsTicketCorrectly() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, false, true, false);
        BigDecimal totalPrice = new BigDecimal("220.00");

        String ticket = ticketFormatter.formatTicket(order, totalPrice);
        assertTrue(ticket.contains("Ticket for Alice"));
        assertTrue(ticket.contains("Event: Concert"));
        assertTrue(ticket.contains("Date: " + event.date));
        assertTrue(ticket.contains("Seat Category: VIP"));
        assertTrue(ticket.contains("Quantity: 2"));
        assertTrue(ticket.contains("Total Price: $220.00"));
    }
}