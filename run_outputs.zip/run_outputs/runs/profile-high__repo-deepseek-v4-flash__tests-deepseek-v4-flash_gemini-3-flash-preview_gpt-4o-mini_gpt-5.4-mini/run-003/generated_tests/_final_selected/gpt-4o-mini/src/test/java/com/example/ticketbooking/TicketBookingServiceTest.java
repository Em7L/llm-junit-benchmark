package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

class TicketBookingServiceTest {
    private final EventCatalog catalog = new EventCatalog();
    private final PricingEngine pricingEngine = new PricingEngine();
    private final DiscountRuleEngine discountRuleEngine = new DiscountRuleEngine();
    private final FeeCalculator feeCalculator = new FeeCalculator();
    private final OrderValidator orderValidator = new OrderValidator();
    private final TicketFormatter ticketFormatter = new TicketFormatter();

    private final TicketBookingService service = new TicketBookingService(catalog, pricingEngine, discountRuleEngine, feeCalculator, orderValidator, ticketFormatter);

    @Test
    void booksValidTicketSuccessfully() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        event.seatAvailability.put(SeatCategory.VIP, 10);
        catalog.addEvent(event);

        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, true, false, false);
        TicketBookingService.BookingResult result = service.bookTicket(order);

        assertTrue(result.isSuccess());
        assertNotNull(result.getTicket());
    }

    @Test
    void failsToBookTicketWhenNotEnoughSeats() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        event.seatAvailability.put(SeatCategory.VIP, 1);
        catalog.addEvent(event);

        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, false, false, false);
        TicketBookingService.BookingResult result = service.bookTicket(order);

        assertFalse(result.isSuccess());
        assertEquals("Could not reserve seats", result.getMessage());
    }

    @Test
    void booksMultipleOrdersSuccessfully() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        event.seatAvailability.put(SeatCategory.VIP, 10);
        catalog.addEvent(event);

        Order order1 = new Order(event, "Alice", 2, SeatCategory.VIP, true, false, false);
        Order order2 = new Order(event, "Bob", 3, SeatCategory.VIP, false, true, false);

        List<TicketBookingService.BookingResult> results = service.processBulkBooking(Arrays.asList(order1, order2));

        assertTrue(results.get(0).isSuccess());
        assertTrue(results.get(1).isSuccess());
    }
}