package com.example.ticketbooking;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class FeeCalculatorTest {

    private final FeeCalculator feeCalculator = new FeeCalculator();

    @Test
    void calculatesServiceFeeMinimum() {
        assertEquals(new BigDecimal("5.00"), feeCalculator.calculateServiceFee(new BigDecimal("100")));
    }

    @Test
    void calculatesServiceFeeCapAtFifty() {
        assertEquals(new BigDecimal("50.00"), feeCalculator.calculateServiceFee(new BigDecimal("3000")));
    }

    @Test
    void calculatesTaxForConcert() {
        assertEquals(new BigDecimal("8.00"), feeCalculator.calculateTax(new BigDecimal("100"), EventType.CONCERT));
    }

    @Test
    void calculatesTotalFeesForConcert() {
        BigDecimal subtotal = new BigDecimal("100");
        BigDecimal totalFees = feeCalculator.calculateTotalFees(subtotal, EventType.CONCERT);
        assertEquals(new BigDecimal("13.00"), totalFees);
    }
}