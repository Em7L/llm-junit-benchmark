package com.example.ticketbooking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import java.time.LocalDate;

class OrderValidatorTest {

    private final OrderValidator orderValidator = new OrderValidator();

    @Test
    void validatesValidOrder() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        event.seatAvailability.put(SeatCategory.VIP, 10);
        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, false, true, false);
        assertFalse(orderValidator.validateOrder(order).hasErrors());
    }

    @Test
    void invalidOrderWhenEventIsNull() {
        Order order = new Order(null, "Alice", 2, SeatCategory.VIP, false, false, false);
        assertTrue(orderValidator.validateOrder(order).hasErrors());
    }

    @Test
    void invalidOrderWhenQuantityIsZero() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        Order order = new Order(event, "Alice", 0, SeatCategory.VIP, false, false, false);
        assertTrue(orderValidator.validateOrder(order).hasErrors());
    }

    @Test
    void invalidOrderWhenNotEnoughSeatsAvailable() {
        Event event = new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        event.seatAvailability.put(SeatCategory.VIP, 1);
        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, false, false, false);
        assertTrue(orderValidator.validateOrder(order).hasErrors());
    }
}