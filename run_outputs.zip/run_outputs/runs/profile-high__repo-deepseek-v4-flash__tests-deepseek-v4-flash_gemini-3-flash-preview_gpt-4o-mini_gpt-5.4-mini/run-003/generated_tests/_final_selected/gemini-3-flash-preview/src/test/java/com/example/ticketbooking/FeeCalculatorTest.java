package com.example.ticketbooking;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class FeeCalculatorTest {
    private final FeeCalculator calculator = new FeeCalculator();

    @Test
    void testServiceFeeThresholds() {
        // Subtotal 100 -> fee 2% = 2. Min fee is 5.
        assertEquals(new BigDecimal("5.00"), calculator.calculateServiceFee(new BigDecimal("100")));
        
        // Subtotal 1500 -> fee 2% = 30. Plus 10 for > 1000 = 40.
        assertEquals(new BigDecimal("40.00"), calculator.calculateServiceFee(new BigDecimal("1500")));
        
        // Subtotal 2500 -> fee 2% = 50. Plus 10 (>1000) plus 10 (>2000) = 70. But 2% fee capped at 50, so 50+10+10=70.
        assertEquals(new BigDecimal("70.00"), calculator.calculateServiceFee(new BigDecimal("2500")));
    }

    @Test
    void testTaxCalculationByEventType() {
        BigDecimal amount = new BigDecimal("100");
        assertEquals(new BigDecimal("8.00"), calculator.calculateTax(amount, EventType.CONCERT));
        assertEquals(new BigDecimal("6.00"), calculator.calculateTax(amount, EventType.SPORT));
        assertEquals(new BigDecimal("10.00"), calculator.calculateTax(amount, EventType.THEATER));
    }

    @Test
    void testInvalidSubtotal() {
        assertThrows(IllegalArgumentException.class, () -> calculator.calculateServiceFee(BigDecimal.ZERO));
    }
}