package com.example.ticketbooking;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {
    private final OrderValidator validator = new OrderValidator();

    @Test
    void testValidateOrderInsufficientSeats() {
        Event event = new Event("E1", "Test", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(10));
        event.seatAvailability.put(SeatCategory.STANDARD, 5);
        
        Order order = new Order(event, "Alice", 10, SeatCategory.STANDARD, false, false, false);
        OrderValidator.ValidationResult result = validator.validateOrder(order);
        
        assertTrue(result.hasErrors());
        assertTrue(result.getErrors().contains("Insufficient seats"));
    }

    @Test
    void testValidateOrderInvalidEvent() {
        Event pastEvent = new Event("E1", "Old", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().minusDays(1));
        Order order = new Order(pastEvent, "Alice", 1, SeatCategory.STANDARD, false, false, false);
        
        assertFalse(validator.isOrderValid(order));
    }
}