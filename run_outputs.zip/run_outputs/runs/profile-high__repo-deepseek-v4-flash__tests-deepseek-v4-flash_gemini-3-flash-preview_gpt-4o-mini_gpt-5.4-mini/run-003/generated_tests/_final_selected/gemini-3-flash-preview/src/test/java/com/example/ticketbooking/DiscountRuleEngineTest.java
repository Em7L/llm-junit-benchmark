package com.example.ticketbooking;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class DiscountRuleEngineTest {
    private final DiscountRuleEngine engine = new DiscountRuleEngine();

    @Test
    void testLoyaltyDiscountCap() {
        Event event = new Event("E1", "Test", EventType.CONCERT, new BigDecimal("500"), LocalDate.now().plusDays(10));
        Order order = new Order(event, "User", 1, SeatCategory.STANDARD, true, false, false);
        // 10% of 500 is 50, but capped at 20
        BigDecimal discount = engine.calculateDiscount(order);
        assertEquals(0, new BigDecimal("20").compareTo(discount));
    }

    @Test
    void testEarlyBirdEligibility() {
        Event eventFar = new Event("E1", "Far", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(15));
        Event eventNear = new Event("E2", "Near", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(5));

        Order orderFar = new Order(eventFar, "User", 1, SeatCategory.STANDARD, false, true, false);
        Order orderNear = new Order(eventNear, "User", 1, SeatCategory.STANDARD, false, true, false);

        assertTrue(engine.calculateDiscount(orderFar).compareTo(BigDecimal.ZERO) > 0);
        assertEquals(0, BigDecimal.ZERO.compareTo(engine.calculateDiscount(orderNear)));
    }

    @Test
    void testGroupDiscountCalculation() {
        Event event = new Event("E1", "Test", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(10));
        // 6 members, extra = 2. Discount = 100*6 * (0.05 * 2) = 600 * 0.10 = 60
        Order order = new Order(event, "User", 6, SeatCategory.STANDARD, false, false, true);
        BigDecimal discount = engine.calculateDiscount(order);
        // Use compareTo to avoid scale issues (60.00 vs 60.000)
        assertEquals(0, new BigDecimal("60").compareTo(discount));
    }
}