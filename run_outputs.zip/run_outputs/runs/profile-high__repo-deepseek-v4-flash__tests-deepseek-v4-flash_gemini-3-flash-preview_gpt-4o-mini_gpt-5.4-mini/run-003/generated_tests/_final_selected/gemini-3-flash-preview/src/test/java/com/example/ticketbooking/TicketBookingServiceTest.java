package com.example.ticketbooking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class TicketBookingServiceTest {
    private TicketBookingService service;
    private EventCatalog catalog;

    @BeforeEach
    void setUp() {
        catalog = new EventCatalog();
        service = new TicketBookingService(
            catalog, 
            new PricingEngine(), 
            new DiscountRuleEngine(), 
            new FeeCalculator(), 
            new OrderValidator(), 
            new TicketFormatter()
        );
    }

    @Test
    void testEndToEndSuccessfulBooking() {
        Event event = new Event("EVT", "Theater Show", EventType.THEATER, new BigDecimal("100"), LocalDate.now().plusDays(20));
        event.seatAvailability.put(SeatCategory.STANDARD, 10);
        catalog.addEvent(event);

        Order order = new Order(event, "John Doe", 2, SeatCategory.STANDARD, false, false, false);
        TicketBookingService.BookingResult result = service.bookTicket(order);

        assertTrue(result.isSuccess());
        assertNotNull(result.getTicket());
        // Seat reduction check
        assertEquals(8, event.seatAvailability.get(SeatCategory.STANDARD));
    }

    @Test
    void testBulkBooking() {
        Event event = new Event("EVT", "Show", EventType.SPORT, new BigDecimal("50"), LocalDate.now().plusDays(10));
        event.seatAvailability.put(SeatCategory.STANDARD, 1);
        catalog.addEvent(event);

        Order order1 = new Order(event, "A", 1, SeatCategory.STANDARD, false, false, false);
        Order order2 = new Order(event, "B", 1, SeatCategory.STANDARD, false, false, false);

        List<TicketBookingService.BookingResult> results = service.processBulkBooking(List.of(order1, order2));

        assertEquals(2, results.size());
        assertTrue(results.get(0).isSuccess());
        assertFalse(results.get(1).isSuccess());
        // The OrderValidator checks seat availability before the logic reaches the manual seat reduction check in service.
        assertEquals("Insufficient seats", results.get(1).getMessage());
    }
}