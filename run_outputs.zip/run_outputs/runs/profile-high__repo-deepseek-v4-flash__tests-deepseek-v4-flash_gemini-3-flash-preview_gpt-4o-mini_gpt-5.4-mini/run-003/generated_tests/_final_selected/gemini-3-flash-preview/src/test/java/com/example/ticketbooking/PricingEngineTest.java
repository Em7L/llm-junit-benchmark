package com.example.ticketbooking;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {
    private final PricingEngine engine = new PricingEngine();

    @Test
    void testConcertPricingMultipliers() {
        Event concert = new Event("C1", "Rock", EventType.CONCERT, new BigDecimal("100"), LocalDate.now());
        assertEquals(new BigDecimal("150.0"), engine.calculateBasePrice(concert, SeatCategory.VIP));
        assertEquals(new BigDecimal("120.0"), engine.calculateBasePrice(concert, SeatCategory.STANDARD));
    }

    @Test
    void testSeasonalSurcharge() {
        Event event = new Event("E1", "Test", EventType.SPORT, new BigDecimal("200"), LocalDate.now().plusDays(5));
        // Within 7 days: 10% of 200 = 20
        BigDecimal surcharge = engine.applySeasonalSurcharge(event, LocalDate.now());
        assertEquals(new BigDecimal("20.00"), surcharge);
        
        Event eventFar = new Event("E1", "Test", EventType.SPORT, new BigDecimal("200"), LocalDate.now().plusDays(40));
        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(eventFar, LocalDate.now()));
    }
}