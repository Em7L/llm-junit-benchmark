package com.example.ticketbooking;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DiscountRuleEngineTest {

    private final DiscountRuleEngine discountRuleEngine = new DiscountRuleEngine();

    @Test
    void calculatesLoyaltyDiscount() {
        Order order = new Order(new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), null), "Alice", 2, SeatCategory.VIP, true, false, false);
        assertEquals(new BigDecimal("20"), discountRuleEngine.calculateDiscount(order));
    }

    @Test
    void calculatesEarlyBirdDiscount() {
        Order order = new Order(new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(15)), "Alice", 2, SeatCategory.VIP, false, true, false);
        assertEquals(new BigDecimal("30"), discountRuleEngine.calculateDiscount(order));
    }

    @Test
    void calculatesGroupBookingDiscount() {
        Order order = new Order(new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), null), "Bob", 5, SeatCategory.STANDARD, false, false, true);
        assertEquals(new BigDecimal("5"), discountRuleEngine.calculateDiscount(order));
    }

    @Test
    void noDiscountForNormalOrder() {
        Order order = new Order(new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("100"), null), "Charlie", 2, SeatCategory.STANDARD, false, false, false);
        assertEquals(BigDecimal.ZERO, discountRuleEngine.calculateDiscount(order));
    }

    @Test
    void maxLoyaltyDiscountCappedAtTwenty() {
        Order order = new Order(new Event("E001", "Concert", EventType.CONCERT, new BigDecimal("300"), null), "Alice", 2, SeatCategory.VIP, true, false, false);
        assertEquals(new BigDecimal("20"), discountRuleEngine.calculateDiscount(order));
    }
}