package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;

class TicketBookingServiceTest {

    private TicketBookingService createService(EventCatalog catalog) {
        return new TicketBookingService(catalog, new PricingEngine(), new DiscountRuleEngine(), new FeeCalculator(), new OrderValidator(), new TicketFormatter());
    }

    @Test
    void bookTicketReturnsValidationFailureForInvalidOrder() {
        EventCatalog catalog = new EventCatalog();
        TicketBookingService service = createService(catalog);
        Order invalid = new Order(null, "Alice", 0, null, false, false, false);

        TicketBookingService.BookingResult result = service.bookTicket(invalid);

        assertFalse(result.isSuccess());
        assertTrue(result.getMessage().contains("Event is null"));
        assertTrue(result.getMessage().contains("Quantity must be positive"));
        assertNull(result.getTicket());
        assertEquals(BigDecimal.ZERO, result.getTotalPrice());
    }

    @Test
    void bookTicketProducesTicketAndReducesSeatAvailabilityForSuccessfulBooking() {
        EventCatalog catalog = new EventCatalog();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(40));
        event.seatAvailability.put(SeatCategory.VIP, 5);
        catalog.addEvent(event);
        TicketBookingService service = createService(catalog);
        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, true, true, false);

        TicketBookingService.BookingResult result = service.bookTicket(order);

        assertTrue(result.isSuccess());
        assertEquals("Booking successful", result.getMessage());
        assertNotNull(result.getTicket());
        assertTrue(result.getTicket().contains("Ticket for Alice"));
        assertTrue(result.getTicket().contains("VIP Lounge access included"));
        assertEquals(3, event.seatAvailability.get(SeatCategory.VIP));
        assertTrue(result.getTotalPrice().compareTo(BigDecimal.ZERO) > 0);
    }

    @Test
    void bookTicketFailsWhenSeatReservationCannotBeCompletedAfterPricing() {
        EventCatalog catalog = new EventCatalog();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(40));
        event.seatAvailability.put(SeatCategory.VIP, 1);
        catalog.addEvent(event);
        TicketBookingService service = createService(catalog);
        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, false, false, false);

        TicketBookingService.BookingResult result = service.bookTicket(order);

        assertFalse(result.isSuccess());
        assertEquals("Could not reserve seats", result.getMessage());
        assertEquals(1, event.seatAvailability.get(SeatCategory.VIP));
        assertEquals(BigDecimal.ZERO, result.getTotalPrice());
        assertNull(result.getTicket());
    }

    @Test
    void processBulkBookingProcessesOrdersIndependently() {
        EventCatalog catalog = new EventCatalog();
        Event concert = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(40));
        concert.seatAvailability.put(SeatCategory.STANDARD, 10);
        Event theater = new Event("E2", "Theater", EventType.THEATER, new BigDecimal("60.00"), LocalDate.now().plusDays(10));
        theater.seatAvailability.put(SeatCategory.BALCONY, 0);
        catalog.addEvent(concert);
        catalog.addEvent(theater);
        TicketBookingService service = createService(catalog);

        List<TicketBookingService.BookingResult> results = service.processBulkBooking(List.of(
                new Order(concert, "Alice", 2, SeatCategory.STANDARD, false, false, false),
                new Order(theater, "Bob", 1, SeatCategory.BALCONY, false, false, false)
        ));

        assertEquals(2, results.size());
        assertTrue(results.get(0).isSuccess());
        assertFalse(results.get(1).isSuccess());
        assertTrue(results.get(1).getMessage().contains("Insufficient seats"));
    }
}
