package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class PricingAndDiscountTest {

    @Test
    void calculateBasePriceUsesEventTypeAndSeatCategoryMultipliers() {
        PricingEngine engine = new PricingEngine();
        Event concert = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));
        Event sport = new Event("E2", "Sport", EventType.SPORT, new BigDecimal("80.00"), LocalDate.now().plusDays(10));
        Event theater = new Event("E3", "Theater", EventType.THEATER, new BigDecimal("60.00"), LocalDate.now().plusDays(10));

        assertEquals(new BigDecimal("150.00"), engine.calculateBasePrice(concert, SeatCategory.VIP));
        assertEquals(new BigDecimal("80.00"), engine.calculateBasePrice(sport, SeatCategory.STANDARD));
        assertEquals(new BigDecimal("84.00"), engine.calculateBasePrice(theater, SeatCategory.PREMIUM));
        assertEquals(new BigDecimal("78.00"), engine.calculateBasePrice(theater, SeatCategory.BALCONY));
    }

    @Test
    void applySeasonalSurchargeHandlesNullPastAndWindowThresholds() {
        PricingEngine engine = new PricingEngine();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(30));

        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(event, null));
        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(new Event("E2", "Concert", EventType.CONCERT, new BigDecimal("100.00"), null), LocalDate.now()));
        assertEquals(BigDecimal.ZERO, engine.applySeasonalSurcharge(event, LocalDate.now().plusDays(40)));
        assertEquals(new BigDecimal("10.00"), engine.applySeasonalSurcharge(event, LocalDate.now().plusDays(23)));
        assertEquals(new BigDecimal("5.00"), engine.applySeasonalSurcharge(event, LocalDate.now().plusDays(1)));
    }

    @Test
    void calculateServiceFeeAppliesMinimumMaximumAndExtraThresholdCharges() {
        FeeCalculator calculator = new FeeCalculator();

        assertEquals(new BigDecimal("5.00"), calculator.calculateServiceFee(new BigDecimal("100.00")));
        assertEquals(new BigDecimal("20.00"), calculator.calculateServiceFee(new BigDecimal("1000.00")));
        assertEquals(new BigDecimal("30.00"), calculator.calculateServiceFee(new BigDecimal("1500.00")));
        assertEquals(new BigDecimal("50.00"), calculator.calculateServiceFee(new BigDecimal("4000.00")));
        assertEquals(new BigDecimal("50.00"), calculator.calculateServiceFee(new BigDecimal("6000.00")));
    }

    @Test
    void calculateServiceFeeAndTaxRejectInvalidAmounts() {
        FeeCalculator calculator = new FeeCalculator();

        assertFalse(false); // placeholder to keep assertions below focused on exceptions? no-op avoided by actual calls
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateServiceFee(null));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateServiceFee(new BigDecimal("0")));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateTax(null, EventType.CONCERT));
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> calculator.calculateTax(new BigDecimal("-1"), EventType.CONCERT));
    }

    @Test
    void calculateTaxUsesEventTypeRates() {
        FeeCalculator calculator = new FeeCalculator();

        assertEquals(new BigDecimal("8.00"), calculator.calculateTax(new BigDecimal("100.00"), EventType.CONCERT));
        assertEquals(new BigDecimal("6.00"), calculator.calculateTax(new BigDecimal("100.00"), EventType.SPORT));
        assertEquals(new BigDecimal("10.00"), calculator.calculateTax(new BigDecimal("100.00"), EventType.THEATER));
    }

    @Test
    void discountEngineCalculatesEachDiscountAndBestDiscountCorrectly() {
        DiscountRuleEngine engine = new DiscountRuleEngine();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(20));
        Order order = new Order(event, "Alice", 6, SeatCategory.VIP, true, true, true);

        assertTrue(engine.isEligibleForDiscount(order));
        assertEquals(new BigDecimal("45.00"), engine.calculateDiscount(order));
        assertEquals(new BigDecimal("15.00"), engine.getBestDiscount(order));
    }

    @Test
    void loyaltyDiscountIsCappedAndEarlyBirdRequiresAtLeastFourteenDays() {
        DiscountRuleEngine engine = new DiscountRuleEngine();
        Event expensive = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("500.00"), LocalDate.now().plusDays(20));
        Event soon = new Event("E2", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(10));

        Order loyaltyOrder = new Order(expensive, "Bob", 1, SeatCategory.STANDARD, true, false, false);
        Order earlyBirdTooSoon = new Order(soon, "Bob", 1, SeatCategory.STANDARD, false, true, false);

        assertEquals(new BigDecimal("20"), engine.calculateDiscount(loyaltyOrder));
        assertEquals(BigDecimal.ZERO, engine.calculateDiscount(earlyBirdTooSoon));
    }
}
