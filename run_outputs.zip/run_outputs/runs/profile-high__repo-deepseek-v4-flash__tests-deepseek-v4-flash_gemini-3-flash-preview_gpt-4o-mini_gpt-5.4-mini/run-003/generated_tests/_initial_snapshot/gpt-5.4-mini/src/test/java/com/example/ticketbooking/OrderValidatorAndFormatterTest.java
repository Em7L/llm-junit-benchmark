package com.example.ticketbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class OrderValidatorAndFormatterTest {

    @Test
    void validateOrderCollectsMultipleErrorsAndNullOrder() {
        OrderValidator validator = new OrderValidator();

        OrderValidator.ValidationResult nullResult = validator.validateOrder(null);
        assertTrue(nullResult.hasErrors());
        assertEquals(1, nullResult.getErrors().size());
        assertEquals("Order is null", nullResult.getErrors().get(0));

        Order invalid = new Order(null, null, 0, null, false, false, false);
        OrderValidator.ValidationResult result = validator.validateOrder(invalid);
        assertTrue(result.hasErrors());
        assertTrue(result.getErrors().contains("Event is null"));
        assertTrue(result.getErrors().contains("Quantity must be positive"));
        assertTrue(result.getErrors().contains("Seat category not specified"));
        assertFalse(validator.isOrderValid(invalid));
    }

    @Test
    void validateOrderDetectsUnavailableEventAndInsufficientSeats() {
        OrderValidator validator = new OrderValidator();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().minusDays(1));
        event.seatAvailability.put(SeatCategory.STANDARD, 1);
        Order order = new Order(event, "Alice", 2, SeatCategory.STANDARD, false, false, false);

        OrderValidator.ValidationResult result = validator.validateOrder(order);

        assertTrue(result.getErrors().contains("Event is not available for booking"));
        assertTrue(result.getErrors().contains("Insufficient seats"));
    }

    @Test
    void formatTicketIncludesDiscountAndVipMessages() {
        TicketFormatter formatter = new TicketFormatter();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.of(2026, 1, 5));
        Order order = new Order(event, "Alice", 2, SeatCategory.VIP, true, true, true);

        String ticket = formatter.formatTicket(order, new BigDecimal("275.5"));

        assertTrue(ticket.contains("Ticket for Alice"));
        assertTrue(ticket.contains("Event: Concert"));
        assertTrue(ticket.contains("Seat Category: VIP"));
        assertTrue(ticket.contains("Quantity: 2"));
        assertTrue(ticket.contains("Total Price: $275.50"));
        assertTrue(ticket.contains("Loyalty discount applied"));
        assertTrue(ticket.contains("Early bird discount applied"));
        assertTrue(ticket.contains("Group booking discount applied"));
        assertTrue(ticket.contains("VIP Lounge access included"));
    }

    @Test
    void formatSummaryUsesCustomerEventQuantityAndTwoDecimalPrice() {
        TicketFormatter formatter = new TicketFormatter();
        Event event = new Event("E1", "Concert", EventType.CONCERT, new BigDecimal("100.00"), LocalDate.now().plusDays(1));
        Order order = new Order(event, "Alice", 3, SeatCategory.STANDARD, false, false, false);

        assertEquals("Alice - Concert x3: $123.46", formatter.formatSummary(order, new BigDecimal("123.456")));
    }
}
