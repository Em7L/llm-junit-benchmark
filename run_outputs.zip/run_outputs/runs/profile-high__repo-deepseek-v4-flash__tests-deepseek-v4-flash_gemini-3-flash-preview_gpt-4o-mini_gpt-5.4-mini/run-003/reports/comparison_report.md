# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-003/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_partially_improved | 1 |
| deepseek-v4-flash | failed | N/A | N/A |
| gemini-3-flash-preview | passed | repair_successful | 1 |
| gpt-4o-mini | passed | repair_partially_improved | 1 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 23 | 6 | 0 | 70.41% | 62.96% | 147 | 81 | 30 | 36 | 55.10% |
| deepseek-v4-flash | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| gemini-3-flash-preview | test_failures | 12 | 2 | 0 | 59.55% | 45.68% | 147 | 63 | 32 | 52 | 42.86% |
| gpt-4o-mini | test_compile_failure | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 23 | 1 | 0 | 82.40% | 75.31% | 147 | 106 | 29 | 12 | 72.11% |
| deepseek-v4-flash | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| gemini-3-flash-preview | passed | 12 | 0 | 0 | 64.42% | 50.00% | 147 | 71 | 31 | 45 | 48.30% |
| gpt-4o-mini | test_failures | 17 | 5 | 0 | 56.93% | 42.59% | 147 | 50 | 41 | 56 | 34.01% |

## Generation Failures
- `deepseek-v4-flash`: 1 validation error for GeneratedTests
  Invalid JSON: expected `,` or `}` at line 26 column 2982 [type=json_invalid, input_value='{\n  "summary": "JUnit 5...0 increments)."\n  ]\n}', input_type=str]
    For further information visit https://errors.pydantic.dev/2.13/v/json_invalid

## Mutant Set Consistency
- Comparable PIT suites: `5`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `147`
- Union mutant IDs: `147`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `147`
- `_final_selected/gpt-4o-mini` mutant IDs: `147`
- `_final_selected/gpt-5.4-mini` mutant IDs: `147`
- `_initial_snapshot/gemini-3-flash-preview` mutant IDs: `147`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `147`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `generation=failed`: The test-generation step did not produce an accepted generated test suite for downstream evaluation.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `maven_status=test_compile_failure`: The generated or existing test sources did not compile during Maven test validation.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.