package com.example.ticketbooking;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Event {
    String id;
    String name;
    EventType type;
    BigDecimal basePrice;
    LocalDate date;
    Map<SeatCategory, Integer> seatAvailability = new HashMap<>();

    public Event(String id, String name, EventType type, BigDecimal basePrice, LocalDate date) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.basePrice = basePrice;
        this.date = date;
    }

    public boolean isValidForBooking() {
        return id != null && !id.isEmpty() && date != null && date.isAfter(LocalDate.now()) && basePrice != null && basePrice.compareTo(BigDecimal.ZERO) > 0;
    }

    public boolean hasAvailableSeats(SeatCategory category, int quantity) {
        int available = seatAvailability.getOrDefault(category, 0);
        return available >= quantity;
    }

    public void reduceSeats(SeatCategory category, int quantity) {
        if (!hasAvailableSeats(category, quantity)) {
            throw new IllegalArgumentException("Not enough seats");
        }
        seatAvailability.put(category, seatAvailability.get(category) - quantity);
    }
}
