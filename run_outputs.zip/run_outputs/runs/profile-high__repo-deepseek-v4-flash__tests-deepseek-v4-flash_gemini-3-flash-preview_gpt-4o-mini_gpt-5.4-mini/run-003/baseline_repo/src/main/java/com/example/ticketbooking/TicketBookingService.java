package com.example.ticketbooking;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TicketBookingService {

    private EventCatalog eventCatalog;
    private PricingEngine pricingEngine;
    private DiscountRuleEngine discountRuleEngine;
    private FeeCalculator feeCalculator;
    private OrderValidator orderValidator;
    private TicketFormatter ticketFormatter;

    public TicketBookingService(EventCatalog eventCatalog, PricingEngine pricingEngine,
                                DiscountRuleEngine discountRuleEngine, FeeCalculator feeCalculator,
                                OrderValidator orderValidator, TicketFormatter ticketFormatter) {
        this.eventCatalog = eventCatalog;
        this.pricingEngine = pricingEngine;
        this.discountRuleEngine = discountRuleEngine;
        this.feeCalculator = feeCalculator;
        this.orderValidator = orderValidator;
        this.ticketFormatter = ticketFormatter;
    }

    public BookingResult bookTicket(Order order) {
        OrderValidator.ValidationResult validation = orderValidator.validateOrder(order);
        if (validation.hasErrors()) {
            return new BookingResult(false, String.join("; ", validation.getErrors()), BigDecimal.ZERO, null);
        }

        BigDecimal basePrice = pricingEngine.calculateBasePrice(order.event, order.seatCategory);
        BigDecimal subtotal = order.computeBaseTotal(basePrice);
        BigDecimal discount = discountRuleEngine.calculateDiscount(order);
        BigDecimal surcharge = pricingEngine.applySeasonalSurcharge(order.event, LocalDate.now());
        BigDecimal afterDiscount = subtotal.subtract(discount).add(surcharge);
        BigDecimal totalFees = feeCalculator.calculateTotalFees(afterDiscount, order.event.type);
        BigDecimal totalPrice = afterDiscount.add(totalFees);

        // Additional pricing rules for complex scenarios
        if (order.event.type == EventType.CONCERT && order.seatCategory == SeatCategory.VIP) {
            totalPrice = totalPrice.add(new BigDecimal("25"));
        }
        if (order.quantity > 10) {
            totalPrice = totalPrice.add(new BigDecimal("15"));
        }
        if (surcharge.compareTo(BigDecimal.ZERO) > 0 && order.event.date.isAfter(LocalDate.now().plusDays(30))) {
            totalPrice = totalPrice.add(new BigDecimal("5"));
        }

        boolean seatReduced = eventCatalog.reduceSeatAvailability(order.event.id, order.seatCategory, order.quantity);
        if (!seatReduced) {
            return new BookingResult(false, "Could not reserve seats", BigDecimal.ZERO, null);
        }

        String ticket = ticketFormatter.formatTicket(order, totalPrice);
        return new BookingResult(true, "Booking successful", totalPrice, ticket);
    }

    public List<BookingResult> processBulkBooking(List<Order> orders) {
        List<BookingResult> results = new ArrayList<>();
        for (Order order : orders) {
            results.add(bookTicket(order));
        }
        return results;
    }

    public static class BookingResult {
        private boolean success;
        private String message;
        private BigDecimal totalPrice;
        private String ticket;

        public BookingResult(boolean success, String message, BigDecimal totalPrice, String ticket) {
            this.success = success;
            this.message = message;
            this.totalPrice = totalPrice;
            this.ticket = ticket;
        }

        public boolean isSuccess() {
            return success;
        }

        public String getMessage() {
            return message;
        }

        public BigDecimal getTotalPrice() {
            return totalPrice;
        }

        public String getTicket() {
            return ticket;
        }
    }
}
