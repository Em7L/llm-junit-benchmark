package com.example.ticketbooking;

public enum EventType {
    CONCERT, SPORT, THEATER
}
