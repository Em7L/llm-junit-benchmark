package com.example.ticketbooking;

public enum SeatCategory {
    STANDARD, PREMIUM, VIP, BALCONY
}
