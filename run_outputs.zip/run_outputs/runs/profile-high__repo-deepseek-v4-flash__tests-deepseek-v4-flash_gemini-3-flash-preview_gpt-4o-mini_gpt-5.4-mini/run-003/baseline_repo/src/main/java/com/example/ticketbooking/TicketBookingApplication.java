package com.example.ticketbooking;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class TicketBookingApplication {
    public static void main(String[] args) {
        // Create catalog and services
        EventCatalog catalog = new EventCatalog();

        Event concert = new Event("E001", "Rock Concert", EventType.CONCERT, new BigDecimal("100"), LocalDate.now().plusDays(30));
        concert.seatAvailability.put(SeatCategory.STANDARD, 200);
        concert.seatAvailability.put(SeatCategory.PREMIUM, 50);
        concert.seatAvailability.put(SeatCategory.VIP, 20);
        catalog.addEvent(concert);

        Event sport = new Event("E002", "Football Match", EventType.SPORT, new BigDecimal("80"), LocalDate.now().plusDays(14));
        sport.seatAvailability.put(SeatCategory.STANDARD, 300);
        sport.seatAvailability.put(SeatCategory.VIP, 30);
        sport.seatAvailability.put(SeatCategory.BALCONY, 100);
        catalog.addEvent(sport);

        Event theater = new Event("E003", "Hamlet", EventType.THEATER, new BigDecimal("60"), LocalDate.now().plusDays(7));
        theater.seatAvailability.put(SeatCategory.STANDARD, 150);
        theater.seatAvailability.put(SeatCategory.PREMIUM, 40);
        theater.seatAvailability.put(SeatCategory.BALCONY, 20);
        catalog.addEvent(theater);

        // Create service instances
        PricingEngine pricingEngine = new PricingEngine();
        DiscountRuleEngine discountRuleEngine = new DiscountRuleEngine();
        FeeCalculator feeCalculator = new FeeCalculator();
        OrderValidator orderValidator = new OrderValidator();
        TicketFormatter ticketFormatter = new TicketFormatter();
        TicketBookingService service = new TicketBookingService(catalog, pricingEngine, discountRuleEngine, feeCalculator, orderValidator, ticketFormatter);

        // Test orders
        Order order1 = new Order(concert, "Alice", 2, SeatCategory.VIP, true, true, false);
        Order order2 = new Order(sport, "Bob", 5, SeatCategory.STANDARD, false, false, true);
        Order order3 = new Order(theater, "Charlie", 1, SeatCategory.BALCONY, false, false, false);

        List<Order> orders = Arrays.asList(order1, order2, order3);
        List<TicketBookingService.BookingResult> results = service.processBulkBooking(orders);

        for (TicketBookingService.BookingResult result : results) {
            System.out.println("Success: " + result.isSuccess());
            System.out.println("Message: " + result.getMessage());
            if (result.isSuccess()) {
                System.out.println("Ticket:\n" + result.getTicket());
            }
            System.out.println("---");
        }
    }
}
