package com.example.ticketbooking;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class PricingEngine {

    public BigDecimal calculateBasePrice(Event event, SeatCategory category) {
        BigDecimal base = event.basePrice;
        BigDecimal multiplier;
        switch (event.type) {
            case CONCERT:
                if (category == SeatCategory.PREMIUM || category == SeatCategory.VIP) {
                    multiplier = new BigDecimal("1.5");
                } else {
                    multiplier = new BigDecimal("1.2");
                }
                break;
            case SPORT:
                if (category == SeatCategory.VIP) {
                    multiplier = new BigDecimal("2.0");
                } else {
                    multiplier = new BigDecimal("1.0");
                }
                break;
            case THEATER:
                if (category == SeatCategory.BALCONY) {
                    multiplier = new BigDecimal("1.3");
                } else if (category == SeatCategory.PREMIUM) {
                    multiplier = new BigDecimal("1.4");
                } else {
                    multiplier = new BigDecimal("1.1");
                }
                break;
            default:
                multiplier = BigDecimal.ONE;
        }
        return base.multiply(multiplier);
    }

    public BigDecimal applySeasonalSurcharge(Event event, LocalDate bookingDate) {
        if (bookingDate == null) {
            return BigDecimal.ZERO;
        }
        if (event.date == null) {
            return BigDecimal.ZERO;
        }
        long daysDifference = ChronoUnit.DAYS.between(bookingDate, event.date);
        if (daysDifference < 0) {
            return BigDecimal.ZERO;
        }
        if (daysDifference <= 7) {
            return event.basePrice.multiply(new BigDecimal("0.10"));
        } else if (daysDifference <= 30) {
            return event.basePrice.multiply(new BigDecimal("0.05"));
        } else {
            return BigDecimal.ZERO;
        }
    }
}
