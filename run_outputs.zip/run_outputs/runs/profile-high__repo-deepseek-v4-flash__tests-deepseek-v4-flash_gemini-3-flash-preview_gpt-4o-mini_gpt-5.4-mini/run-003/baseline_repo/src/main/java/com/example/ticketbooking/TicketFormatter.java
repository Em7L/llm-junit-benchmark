package com.example.ticketbooking;

import java.math.BigDecimal;

public class TicketFormatter {

    public String formatTicket(Order order, BigDecimal totalPrice) {
        StringBuilder sb = new StringBuilder();
        sb.append("Ticket for ").append(order.customerName).append("\n");
        sb.append("Event: ").append(order.event.name).append("\n");
        sb.append("Date: ").append(order.event.date).append("\n");
        sb.append("Seat Category: ").append(order.seatCategory).append("\n");
        sb.append("Quantity: ").append(order.quantity).append("\n");
        sb.append("Total Price: $").append(totalPrice.setScale(2, BigDecimal.ROUND_HALF_UP)).append("\n");
        if (order.isLoyalty) {
            sb.append("Loyalty discount applied\n");
        }
        if (order.isEarlyBird) {
            sb.append("Early bird discount applied\n");
        }
        if (order.isGroupBooking) {
            sb.append("Group booking discount applied\n");
        }
        if (order.seatCategory == SeatCategory.VIP) {
            sb.append("VIP Lounge access included\n");
        }
        return sb.toString();
    }

    public String formatSummary(Order order, BigDecimal totalPrice) {
        return String.format("%s - %s x%d: $%.2f", order.customerName, order.event.name, order.quantity, totalPrice.doubleValue());
    }
}
