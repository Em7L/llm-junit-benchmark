package com.example.ticketbooking;

import java.math.BigDecimal;

public class Order {
    Event event;
    String customerName;
    int quantity;
    SeatCategory seatCategory;
    boolean isLoyalty;
    boolean isEarlyBird;
    boolean isGroupBooking;

    public Order(Event event, String customerName, int quantity, SeatCategory seatCategory, boolean isLoyalty, boolean isEarlyBird, boolean isGroupBooking) {
        this.event = event;
        this.customerName = customerName;
        this.quantity = quantity;
        this.seatCategory = seatCategory;
        this.isLoyalty = isLoyalty;
        this.isEarlyBird = isEarlyBird;
        this.isGroupBooking = isGroupBooking;
    }

    public BigDecimal computeBaseTotal(BigDecimal basePrice) {
        return basePrice.multiply(BigDecimal.valueOf(quantity));
    }
}
