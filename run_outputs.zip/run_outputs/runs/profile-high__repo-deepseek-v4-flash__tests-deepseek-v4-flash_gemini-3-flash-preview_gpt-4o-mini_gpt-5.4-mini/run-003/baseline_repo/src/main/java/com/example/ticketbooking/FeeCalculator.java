package com.example.ticketbooking;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class FeeCalculator {

    public BigDecimal calculateServiceFee(BigDecimal subtotal) {
        if (subtotal == null || subtotal.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Subtotal must be positive");
        }
        BigDecimal fee = subtotal.multiply(new BigDecimal("0.02"));
        if (fee.compareTo(new BigDecimal("5")) < 0) {
            fee = new BigDecimal("5");
        } else if (fee.compareTo(new BigDecimal("50")) > 0) {
            fee = new BigDecimal("50");
        }
        if (subtotal.compareTo(new BigDecimal("1000")) > 0) {
            fee = fee.add(new BigDecimal("10"));
        }
        if (subtotal.compareTo(new BigDecimal("2000")) > 0) {
            fee = fee.add(new BigDecimal("10"));
        }
        return fee.setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal calculateTax(BigDecimal amount, EventType type) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Amount must be non-negative");
        }
        BigDecimal rate;
        switch (type) {
            case CONCERT:
                rate = new BigDecimal("0.08");
                break;
            case SPORT:
                rate = new BigDecimal("0.06");
                break;
            case THEATER:
                rate = new BigDecimal("0.10");
                break;
            default:
                rate = BigDecimal.ZERO;
        }
        return amount.multiply(rate).setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal calculateTotalFees(BigDecimal subtotal, EventType type) {
        BigDecimal serviceFee = calculateServiceFee(subtotal);
        BigDecimal tax = calculateTax(subtotal, type);
        return serviceFee.add(tax).setScale(2, RoundingMode.HALF_UP);
    }
}
