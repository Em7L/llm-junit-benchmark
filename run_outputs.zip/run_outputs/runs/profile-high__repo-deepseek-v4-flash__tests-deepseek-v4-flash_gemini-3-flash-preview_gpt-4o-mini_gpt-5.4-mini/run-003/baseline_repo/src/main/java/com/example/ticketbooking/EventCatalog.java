package com.example.ticketbooking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventCatalog {
    private Map<String, Event> events = new HashMap<>();

    public void addEvent(Event event) {
        events.put(event.id, event);
    }

    public Event findEventById(String id) {
        return events.get(id);
    }

    public List<Event> getEventsByType(EventType type) {
        List<Event> result = new ArrayList<>();
        for (Event e : events.values()) {
            if (e.type == type) {
                result.add(e);
            }
        }
        return result;
    }

    public List<Event> getEventsInDateRange(LocalDate start, LocalDate end, EventType type) {
        List<Event> result = new ArrayList<>();
        for (Event e : events.values()) {
            if (type != null && e.type != type) {
                continue;
            }
            if (e.date != null && !e.date.isBefore(start) && !e.date.isAfter(end)) {
                result.add(e);
            }
        }
        return result;
    }

    public boolean reduceSeatAvailability(String eventId, SeatCategory category, int quantity) {
        Event event = events.get(eventId);
        if (event == null) {
            return false;
        }
        if (!event.hasAvailableSeats(category, quantity)) {
            return false;
        }
        event.reduceSeats(category, quantity);
        return true;
    }
}
