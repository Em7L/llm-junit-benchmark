package com.example.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class OrderValidator {

    public static class ValidationResult {
        private List<String> errors = new ArrayList<>();

        public boolean hasErrors() {
            return !errors.isEmpty();
        }

        public List<String> getErrors() {
            return errors;
        }

        void addError(String error) {
            errors.add(error);
        }
    }

    public ValidationResult validateOrder(Order order) {
        ValidationResult result = new ValidationResult();
        if (order == null) {
            result.addError("Order is null");
            return result;
        }
        if (order.event == null) {
            result.addError("Event is null");
        }
        if (order.quantity <= 0) {
            result.addError("Quantity must be positive");
        }
        if (order.seatCategory == null) {
            result.addError("Seat category not specified");
        }
        if (order.event != null && !order.event.isValidForBooking()) {
            result.addError("Event is not available for booking");
        }
        if (order.event != null && order.seatCategory != null && !order.event.hasAvailableSeats(order.seatCategory, order.quantity)) {
            result.addError("Insufficient seats");
        }
        return result;
    }

    public boolean isOrderValid(Order order) {
        return !validateOrder(order).hasErrors();
    }
}
