package com.example.ticketbooking;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DiscountRuleEngine {

    public BigDecimal calculateDiscount(Order order) {
        BigDecimal totalDiscount = BigDecimal.ZERO;
        // Loyalty discount: 10% off, capped at 20 currency units
        if (order.isLoyalty) {
            BigDecimal loyaltyDiscount = order.computeBaseTotal(order.event.basePrice).multiply(new BigDecimal("0.10"));
            if (loyaltyDiscount.compareTo(new BigDecimal("20")) > 0) {
                loyaltyDiscount = new BigDecimal("20");
            }
            totalDiscount = totalDiscount.add(loyaltyDiscount);
        }
        // Early bird discount: 15% off if booked at least 14 days before event
        if (order.isEarlyBird && order.event.date != null) {
            long daysUntilEvent = ChronoUnit.DAYS.between(LocalDate.now(), order.event.date);
            if (daysUntilEvent >= 14) {
                BigDecimal earlyDiscount = order.computeBaseTotal(order.event.basePrice).multiply(new BigDecimal("0.15"));
                totalDiscount = totalDiscount.add(earlyDiscount);
            }
        }
        // Group booking discount: if quantity >= 4, 5% off for each additional member beyond 4
        if (order.isGroupBooking && order.quantity >= 4) {
            int extraMembers = order.quantity - 4;
            BigDecimal groupDiscount = order.computeBaseTotal(order.event.basePrice).multiply(new BigDecimal("0.05").multiply(BigDecimal.valueOf(extraMembers)));
            totalDiscount = totalDiscount.add(groupDiscount);
        }
        return totalDiscount;
    }

    public BigDecimal getBestDiscount(Order order) {
        BigDecimal total = order.computeBaseTotal(order.event.basePrice);
        BigDecimal max = BigDecimal.ZERO;
        if (order.isLoyalty) {
            BigDecimal loyalty = total.multiply(new BigDecimal("0.10")).min(new BigDecimal("20"));
            max = max.max(loyalty);
        }
        if (order.isEarlyBird && order.event.date != null) {
            long days = ChronoUnit.DAYS.between(LocalDate.now(), order.event.date);
            if (days >= 14) {
                BigDecimal early = total.multiply(new BigDecimal("0.15"));
                max = max.max(early);
            }
        }
        if (order.isGroupBooking && order.quantity >= 4) {
            int extra = order.quantity - 4;
            BigDecimal group = total.multiply(new BigDecimal("0.05").multiply(BigDecimal.valueOf(extra)));
            max = max.max(group);
        }
        return max;
    }

    public boolean isEligibleForDiscount(Order order) {
        return order.isLoyalty || order.isEarlyBird || order.isGroupBooking;
    }
}
