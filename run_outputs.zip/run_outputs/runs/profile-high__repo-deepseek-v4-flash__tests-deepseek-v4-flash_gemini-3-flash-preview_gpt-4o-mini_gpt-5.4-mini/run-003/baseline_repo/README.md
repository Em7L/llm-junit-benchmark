# Ticket Booking System

A ticket booking and pricing system with discount rules and fee calculation. This project demonstrates a modular Java application with orchestration logic.

## Complexity Summary

- Number of classes: 10
- Total public methods: 30
- Methods with 3 or more branches: 5
- Class descriptions:
  - Event: Represents an event with pricing and seat availability.
  - Order: Represents a customer order.
  - EventCatalog: Manages events and provides lookup and availability.
  - PricingEngine: Calculates base price and seasonal surcharges.
  - DiscountRuleEngine: Applies loyalty, early bird, and group discounts.
  - FeeCalculator: Computes service fees and taxes.
  - OrderValidator: Validates order completeness and availability.
  - TicketFormatter: Formats ticket output.
  - TicketBookingService: Orchestrates the booking workflow.
  - TicketBookingApplication: Main entry point for demonstration.
