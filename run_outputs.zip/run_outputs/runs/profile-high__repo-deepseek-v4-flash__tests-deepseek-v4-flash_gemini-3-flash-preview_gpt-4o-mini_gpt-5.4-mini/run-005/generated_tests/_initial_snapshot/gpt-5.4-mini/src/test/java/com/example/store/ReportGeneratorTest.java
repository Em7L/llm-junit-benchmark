package com.example.store;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ReportGeneratorTest {

    private final ReportGenerator generator = new ReportGenerator();

    @Test
    void generateSummaryReturnsMessageForEmptyInput() {
        assertEquals("No orders to report.", generator.generateSummary(null));
        assertEquals("No orders to report.", generator.generateSummary(List.of()));
    }

    @Test
    void generateSummaryFormatsAggregatesCorrectly() {
        Customer customer = new Customer("C1", "Alice", "alice@example.com", Customer.LoyaltyLevel.GOLD);
        Product widget = new Product("P1", "Widget", 10.0, "Tools");
        Product gadget = new Product("P2", "Gadget", 20.0, "Tools");

        Order order1 = new Order("O1", customer, List.of(new LineItem(widget, 2)), 25.00, "CONFIRMED");
        Order order2 = new Order("O2", customer, List.of(new LineItem(gadget, 3)), 55.50, "CONFIRMED");

        String summary = generator.generateSummary(List.of(order1, order2));

        String expected = "Total orders: 2\n" +
                "Total revenue: $80.50\n" +
                "Total items sold: 5\n" +
                "Average order value: $40.25";
        assertEquals(expected, summary);
    }
}
