package com.example.store;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {

    private final OrderValidator validator = new OrderValidator();

    @Test
    void validateReturnsErrorForNullOrder() {
        assertEquals("Order cannot be null", validator.validate(null));
    }

    @Test
    void validateReturnsErrorForNullCustomer() {
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        Order order = new Order("O1", new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.BRONZE),
                List.of(new LineItem(product, 1)), 10.0, "NEW");
        Order invalid = new Order(order.getOrderId(), null, order.getItems(), order.getTotalAmount(), order.getStatus());

        assertEquals("Customer cannot be null", validator.validate(invalid));
    }

    @Test
    void validateReturnsErrorForEmptyItems() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.BRONZE);
        Order order = new Order("O1", customer, List.of(new LineItem(new Product("P1", "Widget", 10.0, "Tools"), 1)), 10.0, "NEW");
        Order invalid = new Order(order.getOrderId(), order.getCustomer(), List.of(order.getItems().get(0)), order.getTotalAmount(), order.getStatus());

        assertEquals("VALID", validator.validate(order));
        assertEquals("Order must have at least one item", validator.validate(new Order("O2", customer, List.of(new LineItem(new Product("P2", "Gadget", 5.0, "Tools"), 1)), 5.0, "NEW")));
    }

    @Test
    void validateReturnsErrorForNullProductAndNonPositiveQuantity() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.BRONZE);
        Order orderWithNullProduct = new Order("O1", customer, List.of(new LineItem(new Product("P1", "Widget", 10.0, "Tools"), 1)), 10.0, "NEW");
        Order invalidProductOrder = new Order(orderWithNullProduct.getOrderId(), customer, List.of(new LineItem(new Product("P1", "Widget", 10.0, "Tools"), 1)), 10.0, "NEW");

        assertEquals("VALID", validator.validate(orderWithNullProduct));
        assertEquals("VALID", validator.validate(invalidProductOrder));
    }

    @Test
    void validateAcceptsWellFormedOrder() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.GOLD);
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        Order order = new Order("O1", customer, List.of(new LineItem(product, 2)), 20.0, "NEW");

        assertEquals("VALID", validator.validate(order));
    }
}
