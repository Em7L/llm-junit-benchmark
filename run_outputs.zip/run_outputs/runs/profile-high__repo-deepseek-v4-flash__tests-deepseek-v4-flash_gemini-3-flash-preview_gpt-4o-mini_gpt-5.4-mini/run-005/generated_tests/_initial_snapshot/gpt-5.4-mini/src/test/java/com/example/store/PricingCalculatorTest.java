package com.example.store;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PricingCalculatorTest {

    private final PricingCalculator calculator = new PricingCalculator();

    @Test
    void calculateSubtotalReturnsZeroForNullOrEmptyItems() {
        assertAll(
                () -> assertEquals(0.0, calculator.calculateSubtotal(null), 1e-9),
                () -> assertEquals(0.0, calculator.calculateSubtotal(List.of()), 1e-9)
        );
    }

    @Test
    void calculateSubtotalSumsProductPriceTimesQuantity() {
        Product laptop = new Product("P1", "Laptop", 999.99, "Electronics");
        Product mouse = new Product("P2", "Mouse", 25.50, "Accessories");
        List<LineItem> items = List.of(new LineItem(laptop, 1), new LineItem(mouse, 2));

        double subtotal = calculator.calculateSubtotal(items);

        assertEquals(1050.99, subtotal, 1e-9);
    }

    @Test
    void calculateTotalAppliesShippingForSmallOrdersAndPreventsNegativeTotals() {
        assertAll(
                () -> assertEquals(15.99, calculator.calculateTotal(10.0, 0.0), 1e-9),
                () -> assertEquals(0.0, calculator.calculateTotal(10.0, 20.0), 1e-9)
        );
    }

    @Test
    void calculateTotalDoesNotAddShippingForLargeOrders() {
        assertEquals(90.0, calculator.calculateTotal(100.0, 10.0), 1e-9);
    }
}
