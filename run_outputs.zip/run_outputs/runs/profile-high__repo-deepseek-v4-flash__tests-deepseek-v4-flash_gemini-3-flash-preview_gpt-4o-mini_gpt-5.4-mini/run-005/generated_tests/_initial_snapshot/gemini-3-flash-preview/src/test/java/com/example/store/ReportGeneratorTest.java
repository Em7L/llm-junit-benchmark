package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ReportGeneratorTest {
    private final ReportGenerator generator = new ReportGenerator();

    @Test
    void generateSummaryWithOrders() {
        Customer c = new Customer("C1", "N", "E", Customer.LoyaltyLevel.BRONZE);
        Product p = new Product("P1", "N", 10.0, "C");
        LineItem item = new LineItem(p, 2);
        Order o1 = new Order("ORD-1", c, List.of(item), 25.0, "OK");
        Order o2 = new Order("ORD-2", c, List.of(item), 75.0, "OK");
        
        String report = generator.generateSummary(List.of(o1, o2));
        
        assertTrue(report.contains("Total orders: 2"));
        assertTrue(report.contains("Total revenue: $100.00"));
        assertTrue(report.contains("Total items sold: 4"));
        assertTrue(report.contains("Average order value: $50.00"));
    }

    @Test
    void generateSummaryHandlesEmptyList() {
        assertEquals("No orders to report.", generator.generateSummary(null));
        assertEquals("No orders to report.", generator.generateSummary(List.of()));
    }
}