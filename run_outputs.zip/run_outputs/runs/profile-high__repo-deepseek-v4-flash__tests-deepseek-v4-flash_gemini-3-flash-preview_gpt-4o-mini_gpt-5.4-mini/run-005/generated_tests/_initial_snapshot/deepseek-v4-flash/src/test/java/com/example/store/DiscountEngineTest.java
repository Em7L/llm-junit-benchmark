package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private DiscountEngine engine = new DiscountEngine();
    private Product laptop = new Product("P001", "Laptop", 1000, "Electronics");
    private Product mouse = new Product("P002", "Mouse", 10, "Accessories");

    @Test
    void testZeroSubtotal() {
        assertEquals(0.0, engine.calculateDiscount(0, null, null), 0.001);
    }

    @Test
    void testNegativeSubtotal() {
        assertEquals(0.0, engine.calculateDiscount(-1, null, null), 0.001);
    }

    @Test
    void testNoDiscountForNullCustomerAndFewItems() {
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        double discount = engine.calculateDiscount(1000, null, items);
        assertEquals(0.0, discount, 0.001);
    }

    @Test
    void testGoldLoyaltyDiscount() {
        Customer gold = new Customer("C1", "Gold", "g@c.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        double discount = engine.calculateDiscount(1000, gold, items);
        assertEquals(100.0, discount, 0.001); // 10%
    }

    @Test
    void testSilverLoyaltyDiscount() {
        Customer silver = new Customer("C2", "Silver", "s@c.com", Customer.LoyaltyLevel.SILVER);
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        double discount = engine.calculateDiscount(1000, silver, items);
        assertEquals(50.0, discount, 0.001); // 5%
    }

    @Test
    void testBronzeLoyaltyDiscount() {
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        double discount = engine.calculateDiscount(1000, bronze, items);
        assertEquals(20.0, discount, 0.001); // 2%
    }

    @Test
    void testQuantityDiscountMoreThan10() {
        List<LineItem> items = List.of(new LineItem(mouse, 11));
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        double discount = engine.calculateDiscount(110, bronze, items);
        // 2% bronze + 5% quantity = 7% of 110 = 7.7
        assertEquals(7.7, discount, 0.001);
    }

    @Test
    void testQuantityDiscountExactly10() {
        List<LineItem> items = List.of(new LineItem(mouse, 10));
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        double discount = engine.calculateDiscount(100, bronze, items);
        // only bronze 2% = 2
        assertEquals(2.0, discount, 0.001);
    }

    @Test
    void testBulkDiscountSubtotalOver200() {
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        double discount = engine.calculateDiscount(250, bronze, items);
        // 2% bronze + 5% bulk = 7% of 250 = 17.5
        assertEquals(17.5, discount, 0.001);
    }

    @Test
    void testDiscountCap() {
        // Make discount exceed subtotal: e.g., subtotal=100, gold=10% -> 10, no other discounts, not exceed; but to test cap, we can create scenario where quantity and bulk add up high?
        // Actually discount percent sum max is 10+5+5=20% so cap only if subtotal is very low? But discount can't exceed subtotal here due to cap. Let's force with a direct calculation: if subtotal=10 and gold 10% -> 1, not exceed. For cap test, we can set subtotal small and add more? Not possible because percent max 20%. But code has if(discount>subtotal) discount=subtotal. We can test with a subtotal that is less than a small discount? Actually discount is always less than subtotal for positive percents less than 100. The cap is safe but we can test with a case where discount would be exactly subtotal? Not needed. We'll test with a small subtotal and gold only: 10*0.1=1, never exceed. But we can test with a scenario where discount is artificially large? Not possible with given discounts. So maybe skip this test or test with a subtotal that is less than a percent? Actually no percent exceeds 100. So cap never triggers normally. We'll still include a test that ensures discount never exceeds subtotal: e.g., use a large quantity? Still max 20%. So subtotal=100, max discount=20, okay. We can test with subtotal=0, discount=0. So no cap testing needed. But we can test that discount is not negative.
        // Add a generic test
        Customer gold = new Customer("C1", "Gold", "g@c.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        double discount = engine.calculateDiscount(10, gold, items);
        assertTrue(discount <= 10);
        assertEquals(1.0, discount, 0.001);
    }

    @Test
    void testNullCustomerNullItems() {
        assertEquals(0.0, engine.calculateDiscount(100, null, null), 0.001);
    }

    @Test
    void testEmptyItems() {
        Customer gold = new Customer("C1", "Gold", "g@c.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of();
        double discount = engine.calculateDiscount(100, gold, items);
        assertEquals(10.0, discount, 0.001); // only loyalty
    }
}