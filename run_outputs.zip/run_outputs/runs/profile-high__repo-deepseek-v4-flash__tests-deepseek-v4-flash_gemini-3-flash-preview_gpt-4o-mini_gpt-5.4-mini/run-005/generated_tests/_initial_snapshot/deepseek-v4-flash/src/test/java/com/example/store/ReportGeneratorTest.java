package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ReportGeneratorTest {

    private ReportGenerator generator = new ReportGenerator();
    private Product laptop = new Product("P001", "Laptop", 1000, "Electronics");
    private Product mouse = new Product("P002", "Mouse", 10, "Accessories");

    @Test
    void testNullOrders() {
        assertEquals("No orders to report.", generator.generateSummary(null));
    }

    @Test
    void testEmptyOrders() {
        assertEquals("No orders to report.", generator.generateSummary(List.of()));
    }

    @Test
    void testSingleOrder() {
        Customer customer = new Customer("C1", "Alice", "a@a.com", Customer.LoyaltyLevel.BRONZE);
        List<LineItem> items = List.of(new LineItem(laptop, 2));
        Order order = new Order("O1", customer, items, 2000, "CONFIRMED");
        String report = generator.generateSummary(List.of(order));
        String expected = "Total orders: 1\nTotal revenue: $2000.00\nTotal items sold: 2\nAverage order value: $2000.00";
        assertEquals(expected, report);
    }

    @Test
    void testMultipleOrders() {
        Customer c1 = new Customer("C1", "Alice", "a@a.com", Customer.LoyaltyLevel.BRONZE);
        Customer c2 = new Customer("C2", "Bob", "b@b.com", Customer.LoyaltyLevel.SILVER);
        Order o1 = new Order("O1", c1, List.of(new LineItem(laptop, 1)), 1000, "CONFIRMED");
        Order o2 = new Order("O2", c2, List.of(new LineItem(mouse, 5)), 50, "CONFIRMED");
        String report = generator.generateSummary(List.of(o1, o2));
        // total orders:2, revenue=1050, items=1+5=6, avg=525
        String expected = "Total orders: 2\nTotal revenue: $1050.00\nTotal items sold: 6\nAverage order value: $525.00";
        assertEquals(expected, report);
    }
}