package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Locale;
import static org.junit.jupiter.api.Assertions.*;

class ReportGeneratorTest {
    private final ReportGenerator generator = new ReportGenerator();

    @Test
    void generateSummaryWithOrders() {
        // Set Locale to US to ensure decimal points and currency symbols match the expected string in the test assertion
        Locale.setDefault(Locale.US);
        Customer c = new Customer("C1", "N", "E", Customer.LoyaltyLevel.BRONZE);
        Product p = new Product("P1", "N", 10.0, "C");
        LineItem item = new LineItem(p, 2);
        Order o1 = new Order("ORD-1", c, List.of(item), 25.0, "OK");
        Order o2 = new Order("ORD-2", c, List.of(item), 75.0, "OK");

        String report = generator.generateSummary(List.of(o1, o2));

        assertTrue(report.contains("Total orders: 2"), "Should contain total orders");
        // Using String.format to match the production code's internal precision logic if needed, 
        // but the failure was likely due to locale or exact string matching.
        assertTrue(report.contains("Total revenue: $100.00"), "Should contain total revenue");
        assertTrue(report.contains("Total items sold: 4"), "Should contain total items sold (2 items per order * 2 orders)");
        assertTrue(report.contains("Average order value: $50.00"), "Should contain average order value");
    }

    @Test
    void generateSummaryHandlesEmptyList() {
        assertEquals("No orders to report.", generator.generateSummary(null));
        assertEquals("No orders to report.", generator.generateSummary(List.of()));
    }
}