package com.example.store;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {
    @Test
    void constructorShouldSetValuesCorrectly() {
        Product p = new Product("P1", "Name", 10.0, "Cat");
        assertEquals("P1", p.getId());
        assertEquals("Name", p.getName());
        assertEquals(10.0, p.getPrice());
        assertEquals("Cat", p.getCategory());
    }

    @Test
    void constructorShouldThrowOnInvalidInput() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Name", 10.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product(" ", "Name", 10.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "", 10.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", -1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 0.0, "Cat"));
    }
}