package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class PricingCalculatorTest {
    private final PricingCalculator calc = new PricingCalculator();

    @Test
    void calculateSubtotalReturnsSum() {
        Product p1 = new Product("1", "A", 10.0, "X");
        Product p2 = new Product("2", "B", 20.0, "X");
        List<LineItem> items = List.of(new LineItem(p1, 2), new LineItem(p2, 1));
        assertEquals(40.0, calc.calculateSubtotal(items));
    }

    @Test
    void calculateTotalIncludesShippingUnder100() {
        // subtotal 50, discount 0 => 50 + 5.99
        assertEquals(55.99, calc.calculateTotal(50.0, 0.0), 0.001);
    }

    @Test
    void calculateTotalExcludesShippingAtOrOver100() {
        assertEquals(100.0, calc.calculateTotal(100.0, 0.0), 0.001);
        assertEquals(200.0, calc.calculateTotal(250.0, 50.0), 0.001);
    }

    @Test
    void calculateTotalFloorsAtZeroButAddsShipping() {
        // subtotal 10, discount 100. subtotal - discount = -90 -> floored to 0.0
        // but since 0 < subtotal < 100 is true for subtotal=10, 5.99 shipping is added.
        // Logic in PricingCalculator: total = Math.max(0, subtotal - discount) + 5.99 (if 0 < subtotal < 100)
        assertEquals(5.99, calc.calculateTotal(10.0, 100.0), 0.001);
    }
}