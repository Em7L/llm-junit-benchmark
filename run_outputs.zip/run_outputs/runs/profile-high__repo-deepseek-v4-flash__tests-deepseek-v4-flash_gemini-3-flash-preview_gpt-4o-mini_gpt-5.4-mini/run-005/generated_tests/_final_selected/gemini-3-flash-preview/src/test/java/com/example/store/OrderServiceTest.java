package com.example.store;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {
    private Inventory inventory;
    private OrderService orderService;
    private Product laptop;
    private Customer alice;

    @BeforeEach
    void setup() {
        inventory = new Inventory();
        laptop = new Product("P1", "Laptop", 1000.0, "Elec");
        inventory.addStock(laptop, 5);
        
        orderService = new OrderService(
            inventory, 
            new DiscountEngine(), 
            new PricingCalculator(), 
            new OrderValidator()
        );
        
        alice = new Customer("C1", "Alice", "a@a.com", Customer.LoyaltyLevel.GOLD);
    }

    @Test
    void createsOrderSuccessfully() {
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        Order order = orderService.createOrder(alice, items);
        
        assertNotNull(order);
        assertTrue(order.getOrderId().startsWith("ORD-"));
        assertEquals("CONFIRMED", order.getStatus());
        // 1000.0 subtotal, Gold discount (10%) + Bulk (5%) = 15% discount (150.0). Total 850.0
        assertEquals(850.0, order.getTotalAmount(), 0.001);
        assertFalse(inventory.isAvailable(laptop, 5));
        assertTrue(inventory.isAvailable(laptop, 4));
    }

    @Test
    void throwsExceptionWhenStockInsufficient() {
        List<LineItem> items = List.of(new LineItem(laptop, 10));
        assertThrows(IllegalStateException.class, () -> orderService.createOrder(alice, items));
    }

    @Test
    void throwsExceptionOnInvalidCustomer() {
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        assertThrows(IllegalArgumentException.class, () -> orderService.createOrder(null, items));
    }
}