package com.example.store;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    @Test
    void addStockAndCheckAvailability() {
        Inventory inv = new Inventory();
        Product p = new Product("P1", "Item", 10.0, "Misc");
        inv.addStock(p, 10);
        
        assertTrue(inv.isAvailable(p, 5));
        assertTrue(inv.isAvailable(p, 10));
        assertFalse(inv.isAvailable(p, 11));
    }

    @Test
    void reserveReducesStock() {
        Inventory inv = new Inventory();
        Product p = new Product("P1", "Item", 10.0, "Misc");
        inv.addStock(p, 10);
        
        boolean success = inv.reserve(p, 4);
        assertTrue(success);
        assertFalse(inv.isAvailable(p, 7));
        assertTrue(inv.isAvailable(p, 6));
    }

    @Test
    void reserveFailsIfInsufficient() {
        Inventory inv = new Inventory();
        Product p = new Product("P1", "Item", 10.0, "Misc");
        inv.addStock(p, 5);
        
        assertFalse(inv.reserve(p, 6));
        assertEquals(true, inv.isAvailable(p, 5));
    }
}