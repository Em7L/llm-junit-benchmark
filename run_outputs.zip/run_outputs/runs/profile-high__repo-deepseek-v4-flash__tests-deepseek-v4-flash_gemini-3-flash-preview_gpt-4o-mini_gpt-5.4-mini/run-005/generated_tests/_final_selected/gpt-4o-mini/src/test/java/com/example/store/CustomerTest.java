package com.example.store;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {
    @Test
    void createsCustomerWithValidData() {
        Customer customer = new Customer("C001", "Alice", "alice@example.com", Customer.LoyaltyLevel.GOLD);
        assertEquals("C001", customer.getId());
        assertEquals("Alice", customer.getName());
        assertEquals("alice@example.com", customer.getEmail());
        assertEquals(Customer.LoyaltyLevel.GOLD, customer.getLoyalty());
    }

    @Test
    void throwsExceptionWhenIdIsBlank() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "Name", "email@example.com", Customer.LoyaltyLevel.SILVER));
    }

    @Test
    void throwsExceptionWhenNameIsBlank() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C002", "", "email@example.com", Customer.LoyaltyLevel.SILVER));
    }
}