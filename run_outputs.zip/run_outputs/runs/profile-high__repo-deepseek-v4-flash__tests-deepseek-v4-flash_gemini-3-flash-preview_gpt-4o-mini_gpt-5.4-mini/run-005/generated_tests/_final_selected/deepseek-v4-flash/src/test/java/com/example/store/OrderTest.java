package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    private Customer customer = new Customer("C001", "Alice", "a@a.com", Customer.LoyaltyLevel.BRONZE);
    private Product product = new Product("P001", "Laptop", 999.99, "Electronics");
    private List<LineItem> items = List.of(new LineItem(product, 1));

    @Test
    void testValidOrder() {
        Order o = new Order("ORD-1", customer, items, 1000.00, "CONFIRMED");
        assertEquals("ORD-1", o.getOrderId());
        assertSame(customer, o.getCustomer());
        assertEquals(items, o.getItems());
        assertEquals(1000.00, o.getTotalAmount(), 0.001);
        assertEquals("CONFIRMED", o.getStatus());
    }

    @Test
    void testNullOrderId() {
        assertThrows(IllegalArgumentException.class, () -> new Order(null, customer, items, 0, ""));
    }

    @Test
    void testBlankOrderId() {
        assertThrows(IllegalArgumentException.class, () -> new Order("  ", customer, items, 0, ""));
    }

    @Test
    void testNullCustomer() {
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", null, items, 0, ""));
    }

    @Test
    void testNullItems() {
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", customer, null, 0, ""));
    }

    @Test
    void testEmptyItems() {
        assertThrows(IllegalArgumentException.class, () -> new Order("O1", customer, List.of(), 0, ""));
    }
}