package com.example.store;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void testValidProduct() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        assertEquals("P001", p.getId());
        assertEquals("Laptop", p.getName());
        assertEquals(999.99, p.getPrice(), 0.001);
        assertEquals("Electronics", p.getCategory());
    }

    @Test
    void testNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Laptop", 999.99, "Electronics"));
    }

    @Test
    void testBlankId() {
        assertThrows(IllegalArgumentException.class, () -> new Product("  ", "Laptop", 999.99, "Electronics"));
    }

    @Test
    void testNullName() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", null, 999.99, "Electronics"));
    }

    @Test
    void testBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "  ", 999.99, "Electronics"));
    }

    @Test
    void testZeroPrice() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "Laptop", 0, "Electronics"));
    }

    @Test
    void testNegativePrice() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "Laptop", -1, "Electronics"));
    }
}