package com.example.store;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void testValidCustomer() {
        Customer c = new Customer("C001", "Alice", "alice@example.com", Customer.LoyaltyLevel.GOLD);
        assertEquals("C001", c.getId());
        assertEquals("Alice", c.getName());
        assertEquals("alice@example.com", c.getEmail());
        assertEquals(Customer.LoyaltyLevel.GOLD, c.getLoyalty());
    }

    @Test
    void testNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(null, "Alice", "alice@example.com", Customer.LoyaltyLevel.BRONZE));
    }

    @Test
    void testBlankId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("  ", "Alice", "alice@example.com", Customer.LoyaltyLevel.BRONZE));
    }

    @Test
    void testNullName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", null, "alice@example.com", Customer.LoyaltyLevel.BRONZE));
    }

    @Test
    void testBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "  ", "alice@example.com", Customer.LoyaltyLevel.BRONZE));
    }
}