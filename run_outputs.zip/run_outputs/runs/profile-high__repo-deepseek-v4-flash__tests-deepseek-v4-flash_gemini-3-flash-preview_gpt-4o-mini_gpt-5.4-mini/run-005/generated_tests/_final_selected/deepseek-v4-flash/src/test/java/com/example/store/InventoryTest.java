package com.example.store;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {

    private Inventory inventory;
    private Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
    private Product mouse = new Product("P002", "Mouse", 25.50, "Accessories");

    @BeforeEach
    void setUp() {
        inventory = new Inventory();
        inventory.addStock(laptop, 10);
        inventory.addStock(mouse, 100);
    }

    @Test
    void testAddStockValid() {
        // already added in setUp, just check availability
        assertTrue(inventory.isAvailable(laptop, 5));
    }

    @Test
    void testAddStockNullProduct() {
        assertThrows(IllegalArgumentException.class, () -> inventory.addStock(null, 1));
    }

    @Test
    void testAddStockNegativeQuantity() {
        assertThrows(IllegalArgumentException.class, () -> inventory.addStock(laptop, -1));
    }

    @Test
    void testAddStockZeroQuantity() {
        assertThrows(IllegalArgumentException.class, () -> inventory.addStock(laptop, 0));
    }

    @Test
    void testIsAvailableSufficient() {
        assertTrue(inventory.isAvailable(laptop, 10));
    }

    @Test
    void testIsAvailableInsufficient() {
        assertFalse(inventory.isAvailable(laptop, 11));
    }

    @Test
    void testIsAvailableProductNotInStock() {
        Product unknown = new Product("P999", "Unknown", 10, "Other");
        assertFalse(inventory.isAvailable(unknown, 1));
    }

    @Test
    void testIsAvailableNullProduct() {
        assertFalse(inventory.isAvailable(null, 1));
    }

    @Test
    void testIsAvailableNegativeQuantity() {
        assertFalse(inventory.isAvailable(laptop, -1));
    }

    @Test
    void testReserveSufficient() {
        assertTrue(inventory.reserve(laptop, 5));
        assertTrue(inventory.isAvailable(laptop, 5)); // remaining 5
    }

    @Test
    void testReserveInsufficient() {
        assertFalse(inventory.reserve(laptop, 11));
        assertTrue(inventory.isAvailable(laptop, 10)); // unchanged
    }

    @Test
    void testReserveProductNotInStock() {
        Product unknown = new Product("P999", "Unknown", 10, "Other");
        assertFalse(inventory.reserve(unknown, 1));
    }

    @Test
    void testReserveNullProduct() {
        assertFalse(inventory.reserve(null, 1));
    }

    @Test
    void testReserveNegativeQuantity() {
        assertFalse(inventory.reserve(laptop, -1));
    }
}