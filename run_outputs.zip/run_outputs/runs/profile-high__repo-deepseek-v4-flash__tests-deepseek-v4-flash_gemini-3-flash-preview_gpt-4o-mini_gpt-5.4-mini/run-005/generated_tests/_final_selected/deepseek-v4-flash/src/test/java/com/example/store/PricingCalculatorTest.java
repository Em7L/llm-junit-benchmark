package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class PricingCalculatorTest {

    private PricingCalculator calculator = new PricingCalculator();
    private Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
    private Product mouse = new Product("P002", "Mouse", 25.50, "Accessories");

    @Test
    void testCalculateSubtotalNullItems() {
        assertEquals(0.0, calculator.calculateSubtotal(null), 0.001);
    }

    @Test
    void testCalculateSubtotalEmptyItems() {
        assertEquals(0.0, calculator.calculateSubtotal(List.of()), 0.001);
    }

    @Test
    void testCalculateSubtotalSingleItem() {
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        assertEquals(999.99, calculator.calculateSubtotal(items), 0.001);
    }

    @Test
    void testCalculateSubtotalMultipleItems() {
        List<LineItem> items = List.of(new LineItem(laptop, 2), new LineItem(mouse, 3));
        double expected = 2 * 999.99 + 3 * 25.50;
        assertEquals(expected, calculator.calculateSubtotal(items), 0.001);
    }

    @Test
    void testCalculateTotalNormal() {
        double total = calculator.calculateTotal(200, 20);
        // total = 180, subtotal 200 >=100, no shipping
        assertEquals(180.0, total, 0.001);
    }

    @Test
    void testCalculateTotalDiscountExceedsSubtotal() {
        double total = calculator.calculateTotal(100, 150);
        // total = -50, but total set to 0, then since subtotal=100 <100? Actually if subtotal>0 and subtotal<100 -> add shipping. Here subtotal=100, not less, so no shipping. So total = 0.0
        assertEquals(0.0, total, 0.001);
    }

    @Test
    void testCalculateTotalShippingAddedWhenSubtotalLessThan100() {
        double total = calculator.calculateTotal(99.99, 0);
        // total = 99.99, subtotal <100, add 5.99 => 105.98
        assertEquals(105.98, total, 0.001);
    }

    @Test
    void testCalculateTotalShippingNotAddedWhenSubtotalExactly100() {
        double total = calculator.calculateTotal(100, 0);
        assertEquals(100.0, total, 0.001);
    }

    @Test
    void testCalculateTotalZeroSubtotal() {
        double total = calculator.calculateTotal(0, 0);
        // subtotal=0, condition subtotal>0 false so no shipping, total=0
        assertEquals(0.0, total, 0.001);
    }

    @Test
    void testCalculateTotalNegativeSubtotal() {
        double total = calculator.calculateTotal(-10, 0);
        // subtotal negative, condition subtotal>0 false, total = -10 - 0 = -10, but total < 0 so set to 0
        assertEquals(0.0, total, 0.001);
    }
}