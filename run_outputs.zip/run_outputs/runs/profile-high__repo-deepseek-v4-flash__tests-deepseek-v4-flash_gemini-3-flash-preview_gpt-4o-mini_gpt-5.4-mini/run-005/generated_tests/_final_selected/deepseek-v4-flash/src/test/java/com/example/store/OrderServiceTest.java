package com.example.store;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    private Inventory inventory;
    private DiscountEngine discountEngine;
    private PricingCalculator pricingCalculator;
    private OrderValidator orderValidator;
    private OrderService orderService;

    private Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
    private Product mouse = new Product("P002", "Mouse", 25.50, "Accessories");
    private Customer goldCustomer = new Customer("C001", "Alice", "a@a.com", Customer.LoyaltyLevel.GOLD);

    @BeforeEach
    void setUp() {
        inventory = new Inventory();
        inventory.addStock(laptop, 10);
        inventory.addStock(mouse, 100);
        discountEngine = new DiscountEngine();
        pricingCalculator = new PricingCalculator();
        orderValidator = new OrderValidator();
        orderService = new OrderService(inventory, discountEngine, pricingCalculator, orderValidator);
    }

    @Test
    void testCreateOrderSuccess() {
        List<LineItem> items = List.of(new LineItem(laptop, 1), new LineItem(mouse, 2));
        Order order = orderService.createOrder(goldCustomer, items);
        assertNotNull(order.getOrderId());
        assertTrue(order.getOrderId().startsWith("ORD-"));
        assertEquals("CONFIRMED", order.getStatus());
        assertSame(goldCustomer, order.getCustomer());
        assertEquals(2, order.getItems().size());
        // Calculate expected total
        double subtotal = 999.99 + 2 * 25.50; // 1050.99
        double discount = discountEngine.calculateDiscount(subtotal, goldCustomer, items); // gold 10% = 105.099, no quantity discount (total qty=3 <=10), no bulk (subtotal=1050.99>200 so 5% bulk? Actually >200 gives 5% bulk? Wait bulk discount only applies if subtotal>200, so 5% bulk but also gold 10%? Yes, code adds loyalty+quantity+bulk. Here quantity<=10 so no quantity, but bulk: subtotal>200, so +5%. So total discount percent = 10%+5%=15% of subtotal = 157.6485. Then total = subtotal - discount = 1050.99 - 157.6485 = 893.3415, but then shipping: subtotal=1050.99 >=100, so no shipping. So expected total = 893.34 approx. But we rely on the actual calculations.
        double expectedTotal = pricingCalculator.calculateTotal(subtotal, discount);
        assertEquals(expectedTotal, order.getTotalAmount(), 0.01);
        // Verify inventory reduced
        assertTrue(inventory.isAvailable(laptop, 9)); // originally 10, reserved 1
        assertTrue(inventory.isAvailable(mouse, 98)); // originally 100, reserved 2
    }

    @Test
    void testCreateOrderNullCustomer() {
        assertThrows(IllegalArgumentException.class, () -> orderService.createOrder(null, List.of(new LineItem(laptop, 1))));
    }

    @Test
    void testCreateOrderNullItems() {
        assertThrows(IllegalArgumentException.class, () -> orderService.createOrder(goldCustomer, null));
    }

    @Test
    void testCreateOrderEmptyItems() {
        assertThrows(IllegalArgumentException.class, () -> orderService.createOrder(goldCustomer, List.of()));
    }

    @Test
    void testCreateOrderInsufficientStock() {
        // Request more than available
        List<LineItem> items = List.of(new LineItem(laptop, 11));
        assertThrows(IllegalStateException.class, () -> orderService.createOrder(goldCustomer, items));
    }

    @Test
    void testCreateOrderProductNotInStock() {
        Product unknown = new Product("P999", "Unknown", 100, "Other");
        List<LineItem> items = List.of(new LineItem(unknown, 1));
        assertThrows(IllegalStateException.class, () -> orderService.createOrder(goldCustomer, items));
    }
}