package com.example.store;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private DiscountEngine engine = new DiscountEngine();
    private Product laptop = new Product("P001", "Laptop", 1000, "Electronics");
    private Product mouse = new Product("P002", "Mouse", 10, "Accessories");
    private Product cheapProduct = new Product("P003", "Cheap", 100, "Other");

    @Test
    void testZeroSubtotal() {
        assertEquals(0.0, engine.calculateDiscount(0, null, null), 0.001);
    }

    @Test
    void testNegativeSubtotal() {
        assertEquals(0.0, engine.calculateDiscount(-1, null, null), 0.001);
    }

    @Test
    void testNoDiscountForNullCustomerAndFewItems() {
        List<LineItem> items = List.of(new LineItem(cheapProduct, 1));
        double discount = engine.calculateDiscount(100, null, items);
        assertEquals(0.0, discount, 0.001);
    }

    @Test
    void testGoldLoyaltyDiscount() {
        Customer gold = new Customer("C1", "Gold", "g@c.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of(new LineItem(cheapProduct, 1));
        double discount = engine.calculateDiscount(100, gold, items);
        assertEquals(10.0, discount, 0.001); // only 10% loyalty
    }

    @Test
    void testSilverLoyaltyDiscount() {
        Customer silver = new Customer("C2", "Silver", "s@c.com", Customer.LoyaltyLevel.SILVER);
        List<LineItem> items = List.of(new LineItem(cheapProduct, 1));
        double discount = engine.calculateDiscount(100, silver, items);
        assertEquals(5.0, discount, 0.001); // only 5% loyalty
    }

    @Test
    void testBronzeLoyaltyDiscount() {
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        List<LineItem> items = List.of(new LineItem(cheapProduct, 1));
        double discount = engine.calculateDiscount(100, bronze, items);
        assertEquals(2.0, discount, 0.001); // only 2% loyalty
    }

    @Test
    void testQuantityDiscountMoreThan10() {
        List<LineItem> items = List.of(new LineItem(mouse, 11));
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        double discount = engine.calculateDiscount(110, bronze, items);
        // 2% bronze + 5% quantity = 7% of 110 = 7.7
        assertEquals(7.7, discount, 0.001);
    }

    @Test
    void testQuantityDiscountExactly10() {
        List<LineItem> items = List.of(new LineItem(mouse, 10));
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        double discount = engine.calculateDiscount(100, bronze, items);
        // only bronze 2% = 2
        assertEquals(2.0, discount, 0.001);
    }

    @Test
    void testBulkDiscountSubtotalOver200() {
        List<LineItem> items = List.of(new LineItem(laptop, 1));
        Customer bronze = new Customer("C3", "Bronze", "b@c.com", Customer.LoyaltyLevel.BRONZE);
        double discount = engine.calculateDiscount(250, bronze, items);
        // 2% bronze + 5% bulk = 7% of 250 = 17.5
        assertEquals(17.5, discount, 0.001);
    }

    @Test
    void testDiscountCap() {
        Customer gold = new Customer("C1", "Gold", "g@c.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of(new LineItem(cheapProduct, 1));
        double discount = engine.calculateDiscount(10, gold, items);
        assertTrue(discount <= 10);
        assertEquals(1.0, discount, 0.001);
    }

    @Test
    void testNullCustomerNullItems() {
        assertEquals(0.0, engine.calculateDiscount(100, null, null), 0.001);
    }

    @Test
    void testEmptyItems() {
        Customer gold = new Customer("C1", "Gold", "g@c.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of();
        double discount = engine.calculateDiscount(100, gold, items);
        assertEquals(10.0, discount, 0.001); // only loyalty
    }
}
