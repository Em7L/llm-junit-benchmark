package com.example.store;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LineItemTest {

    private Product product = new Product("P001", "Laptop", 999.99, "Electronics");

    @Test
    void testValidLineItem() {
        LineItem item = new LineItem(product, 2);
        assertSame(product, item.getProduct());
        assertEquals(2, item.getQuantity());
    }

    @Test
    void testNullProduct() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(null, 1));
    }

    @Test
    void testZeroQuantity() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(product, 0));
    }

    @Test
    void testNegativeQuantity() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(product, -1));
    }
}