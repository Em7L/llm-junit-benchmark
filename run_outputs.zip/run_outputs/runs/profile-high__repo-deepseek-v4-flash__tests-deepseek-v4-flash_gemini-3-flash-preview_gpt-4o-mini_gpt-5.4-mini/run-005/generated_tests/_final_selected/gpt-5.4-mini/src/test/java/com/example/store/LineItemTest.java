package com.example.store;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LineItemTest {

    @Test
    void constructorStoresProductAndQuantity() {
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        LineItem item = new LineItem(product, 3);

        assertAll(
                () -> assertSame(product, item.getProduct()),
                () -> assertEquals(3, item.getQuantity())
        );
    }

    @Test
    void constructorRejectsNullProduct() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new LineItem(null, 1));

        assertEquals("Product must not be null", ex.getMessage());
    }

    @Test
    void constructorRejectsNonPositiveQuantity() {
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new LineItem(product, 0));

        assertEquals("Quantity must be positive", ex.getMessage());
    }
}
