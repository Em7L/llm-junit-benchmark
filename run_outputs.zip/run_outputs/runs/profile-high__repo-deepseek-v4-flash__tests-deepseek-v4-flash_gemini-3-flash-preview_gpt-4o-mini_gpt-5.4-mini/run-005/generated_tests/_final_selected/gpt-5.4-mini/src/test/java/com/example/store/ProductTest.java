package com.example.store;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void constructorStoresAllFields() {
        Product product = new Product("P1", "Widget", 12.5, "Tools");

        assertAll(
                () -> assertEquals("P1", product.getId()),
                () -> assertEquals("Widget", product.getName()),
                () -> assertEquals(12.5, product.getPrice(), 1e-9),
                () -> assertEquals("Tools", product.getCategory())
        );
    }

    @Test
    void constructorRejectsBlankId() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Product("  ", "Widget", 12.5, "Tools"));

        assertEquals("Product id must not be blank", ex.getMessage());
    }

    @Test
    void constructorRejectsBlankName() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Product("P1", "", 12.5, "Tools"));

        assertEquals("Product name must not be blank", ex.getMessage());
    }

    @Test
    void constructorRejectsNonPositivePrice() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Product("P1", "Widget", 0.0, "Tools"));

        assertEquals("Price must be positive", ex.getMessage());
    }
}
