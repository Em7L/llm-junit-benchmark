package com.example.store;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private final DiscountEngine engine = new DiscountEngine();

    @Test
    void calculateDiscountReturnsZeroForNonPositiveSubtotal() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.GOLD);
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        List<LineItem> items = List.of(new LineItem(product, 2));

        assertAll(
                () -> assertEquals(0.0, engine.calculateDiscount(0.0, customer, items), 1e-9),
                () -> assertEquals(0.0, engine.calculateDiscount(-5.0, customer, items), 1e-9)
        );
    }

    @Test
    void calculateDiscountCombinesLoyaltyQuantityAndBulkThresholds() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.GOLD);
        Product product = new Product("P1", "Widget", 50.0, "Tools");
        List<LineItem> items = List.of(new LineItem(product, 5)); // total qty = 5

        double subtotal = 250.0;
        double discount = engine.calculateDiscount(subtotal, customer, items);

        assertEquals(37.5, discount, 1e-9); // 10% + 5% bulk = 15%
    }

    @Test
    void calculateDiscountIncludesQuantityDiscountWhenMoreThanTenItems() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.BRONZE);
        Product product = new Product("P1", "Widget", 20.0, "Tools");
        List<LineItem> items = List.of(new LineItem(product, 11));

        double subtotal = 220.0;
        double discount = engine.calculateDiscount(subtotal, customer, items);

        assertEquals(26.4, discount, 1e-9); // 2% + 5% qty + 5% bulk = 12%
    }

    @Test
    void calculateDiscountCapsDiscountAtSubtotal() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.GOLD);
        Product product = new Product("P1", "Widget", 1.0, "Tools");
        List<LineItem> items = List.of(new LineItem(product, 100));

        double discount = engine.calculateDiscount(1.0, customer, items);

        assertEquals(0.15, discount, 1e-9);
    }

    @Test
    void calculateDiscountHandlesNullCustomerAndNullOrEmptyItems() {
        assertAll(
                () -> assertEquals(0.0, engine.calculateDiscount(100.0, null, null), 1e-9),
                () -> assertEquals(0.0, engine.calculateDiscount(100.0, null, List.of()), 1e-9)
        );
    }
}
