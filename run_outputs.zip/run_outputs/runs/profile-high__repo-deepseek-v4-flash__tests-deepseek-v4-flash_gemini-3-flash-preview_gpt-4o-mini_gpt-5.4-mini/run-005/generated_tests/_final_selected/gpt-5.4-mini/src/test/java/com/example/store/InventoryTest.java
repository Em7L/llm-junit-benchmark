package com.example.store;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {

    @Test
    void addStockAccumulatesAndAvailabilityReflectsStock() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");

        inventory.addStock(product, 5);
        inventory.addStock(product, 2);

        assertAll(
                () -> assertTrue(inventory.isAvailable(product, 7)),
                () -> assertFalse(inventory.isAvailable(product, 8))
        );
    }

    @Test
    void addStockRejectsInvalidArguments() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");

        IllegalArgumentException nullProductEx = assertThrows(IllegalArgumentException.class,
                () -> inventory.addStock(null, 1));
        assertEquals("Invalid product or quantity", nullProductEx.getMessage());

        IllegalArgumentException zeroQtyEx = assertThrows(IllegalArgumentException.class,
                () -> inventory.addStock(product, 0));
        assertEquals("Invalid product or quantity", zeroQtyEx.getMessage());
    }

    @Test
    void isAvailableHandlesInvalidAndMissingStock() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");

        assertAll(
                () -> assertFalse(inventory.isAvailable(null, 1)),
                () -> assertFalse(inventory.isAvailable(product, 0)),
                () -> assertFalse(inventory.isAvailable(product, 1))
        );
    }

    @Test
    void reserveReducesStockOnlyWhenEnoughInventoryExists() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        inventory.addStock(product, 5);

        assertAll(
                () -> assertTrue(inventory.reserve(product, 3)),
                () -> assertFalse(inventory.reserve(product, 3)),
                () -> assertTrue(inventory.isAvailable(product, 2)),
                () -> assertFalse(inventory.isAvailable(product, 3))
        );
    }

    @Test
    void reserveRejectsInvalidArguments() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");

        assertAll(
                () -> assertFalse(inventory.reserve(null, 1)),
                () -> assertFalse(inventory.reserve(product, 0)),
                () -> assertFalse(inventory.reserve(product, 1))
        );
    }
}
