package com.example.store;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    @Test
    void createOrderValidatesReservesInventoryAndCalculatesTotal() {
        Inventory inventory = new Inventory();
        Product laptop = new Product("P1", "Laptop", 100.0, "Electronics");
        Product mouse = new Product("P2", "Mouse", 25.0, "Accessories");
        inventory.addStock(laptop, 2);
        inventory.addStock(mouse, 10);

        OrderService service = new OrderService(inventory, new DiscountEngine(), new PricingCalculator(), new OrderValidator());
        Customer customer = new Customer("C1", "Alice", "alice@example.com", Customer.LoyaltyLevel.GOLD);
        List<LineItem> items = List.of(new LineItem(laptop, 1), new LineItem(mouse, 2));

        Order order = service.createOrder(customer, items);

        assertAll(
                () -> assertEquals("ORD-1", order.getOrderId()),
                () -> assertSame(customer, order.getCustomer()),
                () -> assertEquals("CONFIRMED", order.getStatus()),
                () -> assertEquals(135.0, order.getTotalAmount(), 1e-9),
                () -> assertTrue(inventory.isAvailable(laptop, 1)),
                () -> assertTrue(inventory.isAvailable(mouse, 8)),
                () -> assertFalse(inventory.isAvailable(laptop, 2)),
                () -> assertFalse(inventory.isAvailable(mouse, 9))
        );
    }

    @Test
    void createOrderRejectsNullCustomerAndEmptyItems() {
        OrderService service = new OrderService(new Inventory(), new DiscountEngine(), new PricingCalculator(), new OrderValidator());
        Product product = new Product("P1", "Widget", 10.0, "Tools");

        IllegalArgumentException nullCustomerEx = assertThrows(IllegalArgumentException.class,
                () -> service.createOrder(null, List.of(new LineItem(product, 1))));
        assertEquals("Customer cannot be null", nullCustomerEx.getMessage());

        Customer customer = new Customer("C1", "Alice", "alice@example.com", Customer.LoyaltyLevel.BRONZE);
        IllegalArgumentException emptyItemsEx = assertThrows(IllegalArgumentException.class,
                () -> service.createOrder(customer, List.of()));
        assertEquals("Items cannot be null or empty", emptyItemsEx.getMessage());
    }

    @Test
    void createOrderRejectsInsufficientStockBeforeReservation() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        inventory.addStock(product, 1);

        OrderService service = new OrderService(inventory, new DiscountEngine(), new PricingCalculator(), new OrderValidator());
        Customer customer = new Customer("C1", "Alice", "alice@example.com", Customer.LoyaltyLevel.BRONZE);

        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> service.createOrder(customer, List.of(new LineItem(product, 2))));

        assertEquals("Insufficient stock for product: Widget", ex.getMessage());
        assertTrue(inventory.isAvailable(product, 1));
    }

    @Test
    void createOrderRejectsInvalidOrderThroughValidator() {
        Inventory inventory = new Inventory();
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        inventory.addStock(product, 5);

        OrderValidator validator = new OrderValidator() {
            @Override
            public String validate(Order order) {
                return "forced invalid";
            }
        };

        OrderService service = new OrderService(inventory, new DiscountEngine(), new PricingCalculator(), validator);
        Customer customer = new Customer("C1", "Alice", "alice@example.com", Customer.LoyaltyLevel.BRONZE);

        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> service.createOrder(customer, List.of(new LineItem(product, 1))));

        assertEquals("Validation failed: forced invalid", ex.getMessage());
        assertTrue(inventory.isAvailable(product, 5));
    }
}
