package com.example.store;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorStoresAllFields() {
        Customer customer = new Customer("C1", "Alice", "alice@example.com", Customer.LoyaltyLevel.GOLD);

        assertAll(
                () -> assertEquals("C1", customer.getId()),
                () -> assertEquals("Alice", customer.getName()),
                () -> assertEquals("alice@example.com", customer.getEmail()),
                () -> assertEquals(Customer.LoyaltyLevel.GOLD, customer.getLoyalty())
        );
    }

    @Test
    void constructorRejectsBlankId() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Customer("", "Alice", "alice@example.com", Customer.LoyaltyLevel.SILVER));

        assertEquals("Customer id must not be blank", ex.getMessage());
    }

    @Test
    void constructorRejectsBlankName() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Customer("C1", " ", "alice@example.com", Customer.LoyaltyLevel.SILVER));

        assertEquals("Customer name must not be blank", ex.getMessage());
    }

    @Test
    void constructorAllowsNullLoyalty() {
        Customer customer = new Customer("C1", "Alice", "alice@example.com", null);

        assertNull(customer.getLoyalty());
    }
}
