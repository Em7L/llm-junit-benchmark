package com.example.store;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {

    private final OrderValidator validator = new OrderValidator();

    @Test
    void validateReturnsErrorForNullOrder() {
        assertEquals("Order cannot be null", validator.validate(null));
    }

    @Test
    void orderConstructorRejectsNullCustomer() {
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        List<LineItem> items = List.of(new LineItem(product, 1));

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Order("O1", null, items, 10.0, "NEW"));

        assertEquals("Customer must not be null", ex.getMessage());
    }

    @Test
    void orderConstructorRejectsEmptyItems() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.BRONZE);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new Order("O1", customer, List.of(), 0.0, "NEW"));

        assertEquals("Items must not be null or empty", ex.getMessage());
    }

    @Test
    void lineItemConstructorRejectsInvalidArguments() {
        Product product = new Product("P1", "Widget", 10.0, "Tools");

        assertAll(
                () -> {
                    IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                            () -> new LineItem(null, 1));
                    assertEquals("Product must not be null", ex.getMessage());
                },
                () -> {
                    IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                            () -> new LineItem(product, 0));
                    assertEquals("Quantity must be positive", ex.getMessage());
                }
        );
    }

    @Test
    void validateAcceptsWellFormedOrder() {
        Customer customer = new Customer("C1", "Alice", "a@b.com", Customer.LoyaltyLevel.GOLD);
        Product product = new Product("P1", "Widget", 10.0, "Tools");
        Order order = new Order("O1", customer, List.of(new LineItem(product, 2)), 20.0, "NEW");

        assertEquals("VALID", validator.validate(order));
    }
}
