# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-005/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_partially_improved | 1 |
| deepseek-v4-flash | passed | repair_successful | 1 |
| gemini-3-flash-preview | passed | repair_successful | 1 |
| gpt-4o-mini | passed | repair_not_needed | 0 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 36 | 6 | 1 | 64.76% | 71.67% | 122 | 85 | 13 | 24 | 69.67% |
| deepseek-v4-flash | test_failures | 75 | 6 | 0 | 72.86% | 87.50% | 122 | 95 | 10 | 17 | 77.87% |
| gemini-3-flash-preview | test_failures | 18 | 2 | 0 | 65.24% | 64.17% | 122 | 86 | 13 | 23 | 70.49% |
| gpt-4o-mini | passed | 3 | 0 | 0 | 7.62% | 5.00% | 122 | 8 | 0 | 114 | 6.56% |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 36 | 1 | 0 | 72.86% | 80.83% | 122 | 94 | 11 | 17 | 77.05% |
| deepseek-v4-flash | passed | 75 | 0 | 0 | 79.05% | 92.50% | 122 | 99 | 10 | 13 | 81.15% |
| gemini-3-flash-preview | passed | 18 | 0 | 0 | 70.95% | 69.17% | 122 | 90 | 13 | 19 | 73.77% |
| gpt-4o-mini | passed | 3 | 0 | 0 | 7.62% | 5.00% | 122 | 8 | 0 | 114 | 6.56% |

## Mutant Set Consistency
- Comparable PIT suites: `7`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `122`
- Union mutant IDs: `122`
- `_final_selected/deepseek-v4-flash` mutant IDs: `122`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `122`
- `_final_selected/gpt-4o-mini` mutant IDs: `122`
- `_final_selected/gpt-5.4-mini` mutant IDs: `122`
- `_initial_snapshot/deepseek-v4-flash` mutant IDs: `122`
- `_initial_snapshot/gemini-3-flash-preview` mutant IDs: `122`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `122`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `repair_not_needed`: The initial generated test suite already passed verification, so no repair attempt was needed.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.