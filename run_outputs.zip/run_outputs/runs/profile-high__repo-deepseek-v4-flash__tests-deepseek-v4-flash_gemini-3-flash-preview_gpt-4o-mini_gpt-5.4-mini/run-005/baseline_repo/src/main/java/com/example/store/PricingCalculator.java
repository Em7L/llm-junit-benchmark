package com.example.store;

import java.util.List;

public class PricingCalculator {

    public double calculateSubtotal(List<LineItem> items) {
        if (items == null || items.isEmpty()) {
            return 0.0;
        }
        double subtotal = 0.0;
        for (LineItem item : items) {
            subtotal += item.getProduct().getPrice() * item.getQuantity();
        }
        return subtotal;
    }

    public double calculateTotal(double subtotal, double discount) {
        double total = subtotal - discount;
        if (total < 0) total = 0.0;
        if (subtotal > 0 && subtotal < 100) {
            total += 5.99; // standard shipping
        }
        return total;
    }
}