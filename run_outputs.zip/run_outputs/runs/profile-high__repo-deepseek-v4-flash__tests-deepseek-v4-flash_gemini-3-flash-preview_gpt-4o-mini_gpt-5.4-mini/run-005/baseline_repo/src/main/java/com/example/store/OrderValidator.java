package com.example.store;

public class OrderValidator {

    public String validate(Order order) {
        if (order == null) {
            return "Order cannot be null";
        }
        if (order.getCustomer() == null) {
            return "Customer cannot be null";
        }
        if (order.getItems() == null || order.getItems().isEmpty()) {
            return "Order must have at least one item";
        }
        for (LineItem item : order.getItems()) {
            if (item.getProduct() == null) {
                return "Product cannot be null";
            }
            if (item.getQuantity() <= 0) {
                return "Quantity must be positive";
            }
        }
        return "VALID";
    }
}