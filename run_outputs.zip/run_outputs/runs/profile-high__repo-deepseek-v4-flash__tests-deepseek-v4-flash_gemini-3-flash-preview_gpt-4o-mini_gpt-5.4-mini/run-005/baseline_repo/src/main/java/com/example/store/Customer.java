package com.example.store;

public class Customer {
    private final String id;
    private final String name;
    private final String email;
    private final LoyaltyLevel loyalty;

    public enum LoyaltyLevel {
        BRONZE, SILVER, GOLD
    }

    public Customer(String id, String name, String email, LoyaltyLevel loyalty) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Customer id must not be blank");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Customer name must not be blank");
        }
        this.id = id;
        this.name = name;
        this.email = email;
        this.loyalty = loyalty;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public LoyaltyLevel getLoyalty() { return loyalty; }
}