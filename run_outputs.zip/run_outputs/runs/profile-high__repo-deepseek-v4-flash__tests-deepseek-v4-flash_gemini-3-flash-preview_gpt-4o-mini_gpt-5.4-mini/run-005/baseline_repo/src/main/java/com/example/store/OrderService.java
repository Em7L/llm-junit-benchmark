package com.example.store;

import java.util.List;

public class OrderService {
    private final Inventory inventory;
    private final DiscountEngine discountEngine;
    private final PricingCalculator pricingCalculator;
    private final OrderValidator orderValidator;
    private int nextOrderId = 1;

    public OrderService(Inventory inventory, DiscountEngine discountEngine,
                        PricingCalculator pricingCalculator, OrderValidator orderValidator) {
        this.inventory = inventory;
        this.discountEngine = discountEngine;
        this.pricingCalculator = pricingCalculator;
        this.orderValidator = orderValidator;
    }

    public Order createOrder(Customer customer, List<LineItem> items) {
        if (customer == null) {
            throw new IllegalArgumentException("Customer cannot be null");
        }
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Items cannot be null or empty");
        }

        // Validate items via a temporary order
        Order tempOrder = new Order("temp", customer, items, 0.0, "TEMP");
        String validationResult = orderValidator.validate(tempOrder);
        if (!"VALID".equals(validationResult)) {
            throw new IllegalStateException("Validation failed: " + validationResult);
        }

        // Check and reserve inventory
        for (LineItem item : items) {
            if (!inventory.isAvailable(item.getProduct(), item.getQuantity())) {
                throw new IllegalStateException("Insufficient stock for product: " + item.getProduct().getName());
            }
        }
        for (LineItem item : items) {
            boolean reserved = inventory.reserve(item.getProduct(), item.getQuantity());
            if (!reserved) {
                throw new IllegalStateException("Failed to reserve product: " + item.getProduct().getName());
            }
        }

        double subtotal = pricingCalculator.calculateSubtotal(items);
        double discount = discountEngine.calculateDiscount(subtotal, customer, items);
        double total = pricingCalculator.calculateTotal(subtotal, discount);

        String orderId = "ORD-" + nextOrderId++;
        return new Order(orderId, customer, items, total, "CONFIRMED");
    }
}