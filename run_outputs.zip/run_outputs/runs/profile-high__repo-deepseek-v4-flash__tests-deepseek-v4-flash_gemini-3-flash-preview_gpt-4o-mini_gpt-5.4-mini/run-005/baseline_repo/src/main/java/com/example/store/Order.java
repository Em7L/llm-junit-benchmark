package com.example.store;

import java.util.List;

public class Order {
    private final String orderId;
    private final Customer customer;
    private final List<LineItem> items;
    private final double totalAmount;
    private final String status;

    public Order(String orderId, Customer customer, List<LineItem> items, double totalAmount, String status) {
        if (orderId == null || orderId.isBlank()) {
            throw new IllegalArgumentException("Order id must not be blank");
        }
        if (customer == null) {
            throw new IllegalArgumentException("Customer must not be null");
        }
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Items must not be null or empty");
        }
        this.orderId = orderId;
        this.customer = customer;
        this.items = items;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    public String getOrderId() { return orderId; }
    public Customer getCustomer() { return customer; }
    public List<LineItem> getItems() { return items; }
    public double getTotalAmount() { return totalAmount; }
    public String getStatus() { return status; }
}