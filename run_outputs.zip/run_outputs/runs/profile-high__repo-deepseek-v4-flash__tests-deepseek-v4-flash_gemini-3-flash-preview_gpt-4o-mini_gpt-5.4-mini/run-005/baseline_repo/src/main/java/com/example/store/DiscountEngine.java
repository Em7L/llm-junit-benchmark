package com.example.store;

import java.util.List;

public class DiscountEngine {

    public double calculateDiscount(double subtotal, Customer customer, List<LineItem> items) {
        if (subtotal <= 0) {
            return 0.0;
        }
        double loyaltyDiscount = loyaltyDiscount(customer);
        double quantityDiscount = quantityDiscount(items);
        double bulkDiscount = bulkDiscount(subtotal);
        double totalDiscountPercent = loyaltyDiscount + quantityDiscount + bulkDiscount;
        double discount = subtotal * totalDiscountPercent;
        if (discount > subtotal) {
            discount = subtotal;
        }
        return discount;
    }

    private double loyaltyDiscount(Customer customer) {
        if (customer == null) return 0.0;
        return switch (customer.getLoyalty()) {
            case GOLD -> 0.10;
            case SILVER -> 0.05;
            case BRONZE -> 0.02;
            default -> 0.0;
        };
    }

    private double quantityDiscount(List<LineItem> items) {
        if (items == null || items.isEmpty()) return 0.0;
        int totalQty = items.stream().mapToInt(LineItem::getQuantity).sum();
        if (totalQty > 10) {
            return 0.05;
        }
        return 0.0;
    }

    private double bulkDiscount(double subtotal) {
        if (subtotal > 200) {
            return 0.05;
        }
        return 0.0;
    }
}