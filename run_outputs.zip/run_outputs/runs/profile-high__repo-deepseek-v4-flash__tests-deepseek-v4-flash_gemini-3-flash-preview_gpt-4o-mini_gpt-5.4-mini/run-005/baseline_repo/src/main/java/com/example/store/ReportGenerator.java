package com.example.store;

import java.util.List;

public class ReportGenerator {

    public String generateSummary(List<Order> orders) {
        if (orders == null || orders.isEmpty()) {
            return "No orders to report.";
        }
        int totalOrders = orders.size();
        double totalRevenue = 0.0;
        int totalItems = 0;
        for (Order order : orders) {
            totalRevenue += order.getTotalAmount();
            for (LineItem item : order.getItems()) {
                totalItems += item.getQuantity();
            }
        }
        double averageOrderValue = totalRevenue / totalOrders;
        return String.format("Total orders: %d\nTotal revenue: $%.2f\nTotal items sold: %d\nAverage order value: $%.2f",
                totalOrders, totalRevenue, totalItems, averageOrderValue);
    }
}