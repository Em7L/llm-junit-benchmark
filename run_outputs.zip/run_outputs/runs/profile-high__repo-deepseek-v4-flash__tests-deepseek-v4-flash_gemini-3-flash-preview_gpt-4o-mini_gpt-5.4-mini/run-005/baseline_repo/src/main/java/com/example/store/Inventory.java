package com.example.store;

import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private final Map<String, Integer> stock = new HashMap<>();

    public void addStock(Product product, int quantity) {
        if (product == null || quantity <= 0) {
            throw new IllegalArgumentException("Invalid product or quantity");
        }
        stock.merge(product.getId(), quantity, Integer::sum);
    }

    public boolean isAvailable(Product product, int quantity) {
        if (product == null || quantity <= 0) {
            return false;
        }
        Integer available = stock.get(product.getId());
        return available != null && available >= quantity;
    }

    public boolean reserve(Product product, int quantity) {
        if (product == null || quantity <= 0) {
            return false;
        }
        String id = product.getId();
        Integer available = stock.get(id);
        if (available == null || available < quantity) {
            return false;
        }
        stock.put(id, available - quantity);
        return true;
    }
}