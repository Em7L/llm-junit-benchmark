package com.example.store;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Setup products
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        Product mouse = new Product("P002", "Mouse", 25.50, "Accessories");
        Product keyboard = new Product("P003", "Keyboard", 79.99, "Accessories");
        Product monitor = new Product("P004", "Monitor", 299.50, "Electronics");

        // Setup customers
        Customer alice = new Customer("C001", "Alice", "alice@example.com", Customer.LoyaltyLevel.GOLD);
        Customer bob = new Customer("C002", "Bob", "bob@example.com", Customer.LoyaltyLevel.SILVER);

        // Setup inventory
        Inventory inventory = new Inventory();
        inventory.addStock(laptop, 10);
        inventory.addStock(mouse, 100);
        inventory.addStock(keyboard, 50);
        inventory.addStock(monitor, 5);

        // Setup services
        DiscountEngine discountEngine = new DiscountEngine();
        PricingCalculator pricingCalculator = new PricingCalculator();
        OrderValidator orderValidator = new OrderValidator();
        OrderService orderService = new OrderService(inventory, discountEngine, pricingCalculator, orderValidator);
        ReportGenerator reportGenerator = new ReportGenerator();

        // Create orders
        List<LineItem> items1 = new ArrayList<>();
        items1.add(new LineItem(laptop, 1));
        items1.add(new LineItem(mouse, 2));
        Order order1 = orderService.createOrder(alice, items1);
        System.out.println("Order 1: " + order1.getOrderId() + " total: $" + order1.getTotalAmount());

        List<LineItem> items2 = new ArrayList<>();
        items2.add(new LineItem(keyboard, 3));
        items2.add(new LineItem(monitor, 1));
        Order order2 = orderService.createOrder(bob, items2);
        System.out.println("Order 2: " + order2.getOrderId() + " total: $" + order2.getTotalAmount());

        List<LineItem> items3 = new ArrayList<>();
        items3.add(new LineItem(mouse, 15));
        Order order3 = orderService.createOrder(alice, items3);
        System.out.println("Order 3: " + order3.getOrderId() + " total: $" + order3.getTotalAmount());

        // Generate report
        List<Order> orders = List.of(order1, order2, order3);
        String report = reportGenerator.generateSummary(orders);
        System.out.println("\nOrder Summary Report:");
        System.out.println(report);
    }
}