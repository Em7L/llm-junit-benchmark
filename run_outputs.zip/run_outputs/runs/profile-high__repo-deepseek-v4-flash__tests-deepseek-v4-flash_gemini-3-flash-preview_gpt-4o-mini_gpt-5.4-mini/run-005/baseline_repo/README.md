# Order Management System

A self-contained order management system demonstrating high-complexity Java design patterns. Includes inventory management, pricing with discounts, order validation, and reporting.

## Complexity Summary
- Number of classes: 10
- Total public methods: 23
- Methods with >= 3 branches: 7
- Class descriptions:
  - Product: Represents a product with id, name, price, category.
  - Customer: Represents a customer with loyalty level.
  - LineItem: Links a product and quantity.
  - Order: Represents a customer order with items and total.
  - Inventory: Manages stock levels with availability checks.
  - DiscountEngine: Calculates discounts based on loyalty and quantity.
  - OrderValidator: Validates order integrity.
  - PricingCalculator: Computes subtotals, discounts, and totals.
  - OrderService: Orchestrates order creation across components.
  - ReportGenerator: Aggregates order summaries.