package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CartTests {
    private Cart cart;
    private Product product;

    @BeforeEach
    void setUp() {
        cart = new Cart();
        product = new Product("P001", "Laptop", 999.99, "Electronics");
    }

    @Test
    void testAddItemIncreasesItemCount() {
        cart.addItem(product, 1);
        assertEquals(1, cart.getItemCount());
        assertEquals(1, cart.getTotalQuantity());
    }

    @Test
    void testAddSameItemIncreasesQuantity() {
        cart.addItem(product, 1);
        cart.addItem(product, 2);
        assertEquals(1, cart.getItemCount());
        assertEquals(3, cart.getTotalQuantity());
    }

    @Test
    void testRemoveItemDecreasesItemCount() {
        cart.addItem(product, 1);
        cart.removeItem(product);
        assertEquals(0, cart.getItemCount());
    }

    @Test
    void testGetItemsReturnsCorrectItems() {
        cart.addItem(product, 1);
        assertFalse(cart.getItems().isEmpty());
        assertEquals(product, cart.getItems().get(0).getProduct());
    }

    @Test
    void testClearRemovesAllItems() {
        cart.addItem(product, 1);
        cart.clear();
        assertTrue(cart.isEmpty());
    }

    @Test
    void testAddItemWithNonPositiveQuantityThrowsException() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            cart.addItem(product, 0);
        });
        assertEquals("Quantity must be positive", exception.getMessage());
    }
}
