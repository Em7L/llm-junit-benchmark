package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

class ReceiptFormatterAndOrderTest {

    @Test
    void formatReceiptHandlesNullEmptyAndPopulatedOrders() {
        ReceiptFormatter formatter = new ReceiptFormatter();

        assertEquals("No order to display.", formatter.formatReceipt(null));
        assertEquals("No order.", formatter.formatSummary(null));

        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        CartItem item = new CartItem(laptop, 1);
        Order emptyOrder = new Order("Bob", List.of(), 0.0, 0.0, 0.0);
        String emptyReceipt = formatter.formatReceipt(emptyOrder);
        assertTrue(emptyReceipt.contains("Customer: Bob"));
        assertTrue(emptyReceipt.contains("(empty)"));
        assertTrue(emptyReceipt.contains("Subtotal: $0"));
        assertTrue(emptyReceipt.contains("Discount: -$0"));
        assertTrue(emptyReceipt.contains("Total: $0"));

        Order populated = new Order("Alice", List.of(item), 999.99, 99.99, 972.00);
        String receipt = formatter.formatReceipt(populated);
        assertTrue(receipt.startsWith("========== RECEIPT =========="));
        assertTrue(receipt.contains("Customer: Alice"));
        assertTrue(receipt.contains("Laptop x1"));
        assertTrue(receipt.contains("Subtotal: $999"));
        assertTrue(receipt.contains("Discount: -$99"));
        assertTrue(receipt.contains("Total: $972"));
        assertTrue(formatter.formatSummary(populated).contains(populated.getOrderId()));
        assertTrue(formatter.formatSummary(populated).contains("1 items"));
        assertTrue(formatter.formatSummary(populated).contains("$972"));
    }

    @Test
    void orderCreatesImmutableSnapshotAndGeneratesReadableToString() {
        Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        CartItem item = new CartItem(mouse, 2);
        Order order = new Order("Charlie", List.of(item), 59.98, 5.98, 58.80);

        assertNotNull(order.getOrderId());
        assertEquals("Charlie", order.getCustomerName());
        assertEquals(1, order.getItems().size());
        assertEquals(59.98, order.getSubtotal(), 0.0001);
        assertEquals(5.98, order.getDiscount(), 0.0001);
        assertEquals(58.80, order.getFinalTotal(), 0.0001);

        item.setQuantity(5);
        assertEquals(5, order.getItems().get(0).getQuantity());

        String text = order.toString();
        assertTrue(text.contains(order.getOrderId()));
        assertTrue(text.contains("Charlie"));
        assertTrue(text.contains("items=1"));
        assertTrue(text.contains("subtotal=59.98"));
        assertFalse(text.contains("items=2"));
    }
}
