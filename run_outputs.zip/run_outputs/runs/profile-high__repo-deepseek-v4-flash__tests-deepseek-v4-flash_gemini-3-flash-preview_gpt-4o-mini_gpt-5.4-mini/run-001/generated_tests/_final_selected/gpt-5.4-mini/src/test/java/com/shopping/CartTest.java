package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

class CartTest {

    private final Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
    private final Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");

    @Test
    void addItemMergesQuantitiesForSameProductAndRejectsInvalidQuantity() {
        Cart cart = new Cart();

        assertThrows(IllegalArgumentException.class, () -> cart.addItem(laptop, 0));
        assertThrows(IllegalArgumentException.class, () -> cart.addItem(laptop, -1));

        cart.addItem(laptop, 1);
        cart.addItem(new Product("P001", "Different Name", 100.0, "Accessories"), 2);

        assertEquals(1, cart.getItemCount());
        assertEquals(3, cart.getTotalQuantity());
        assertEquals(1, cart.getItems().size());
        assertEquals(3, cart.getItems().get(0).getQuantity());
    }

    @Test
    void removeClearAndGetItemsBehaveAsExpected() {
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);

        List<CartItem> snapshot = cart.getItems();
        assertEquals(2, snapshot.size());
        assertNotSame(snapshot, cart.getItems());

        cart.removeItem(laptop);
        assertEquals(1, cart.getItemCount());
        assertEquals(2, cart.getTotalQuantity());

        cart.clear();
        assertTrue(cart.isEmpty());
        assertEquals(0, cart.getItemCount());
        assertEquals(0, cart.getTotalQuantity());
        assertEquals("Cart is empty", cart.toString());
    }

    @Test
    void toStringListsItemsWhenCartHasContents() {
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);

        String text = cart.toString();
        assertTrue(text.startsWith("Cart contents:"));
        assertTrue(text.contains("Laptop x 1"));
        assertTrue(text.contains("Mouse x 2"));
        assertFalse(text.contains("Cart is empty"));
    }
}
