package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class CartItemTest {

    private final Product product = new Product("P002", "Mouse", 29.99, "Accessories");

    @Test
    void constructorAndSettersValidateInputs() {
        assertThrows(IllegalArgumentException.class, () -> new CartItem(null, 1));
        assertThrows(IllegalArgumentException.class, () -> new CartItem(product, 0));
        assertThrows(IllegalArgumentException.class, () -> new CartItem(product, -1));

        CartItem item = new CartItem(product, 1);
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(-3));
        assertThrows(IllegalArgumentException.class, () -> item.incrementQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.incrementQuantity(-2));
    }

    @Test
    void subtotalReflectsQuantityAndPriceChangesViaQuantityUpdates() {
        CartItem item = new CartItem(product, 2);
        assertEquals(59.98, item.getSubtotal(), 0.0001);

        item.incrementQuantity(3);
        assertEquals(5, item.getQuantity());
        assertEquals(149.95, item.getSubtotal(), 0.0001);

        item.setQuantity(1);
        assertEquals(29.99, item.getSubtotal(), 0.0001);
    }

    @Test
    void toStringFormatsNameAndQuantity() {
        CartItem item = new CartItem(product, 4);
        assertEquals("Mouse x 4", item.toString());
    }
}
