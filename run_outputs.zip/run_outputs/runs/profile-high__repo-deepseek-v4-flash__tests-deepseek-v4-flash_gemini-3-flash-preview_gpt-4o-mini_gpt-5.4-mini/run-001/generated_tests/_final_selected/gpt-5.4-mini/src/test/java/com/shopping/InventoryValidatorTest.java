package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class InventoryValidatorTest {

    @Test
    void hasStockChecksNullMissingInvalidAndSufficientQuantities() {
        InventoryValidator validator = new InventoryValidator();
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        Product unavailable = new Product("P004", "Monitor", 299.99, "Electronics");
        Product unknown = new Product("PX", "Unknown", 10.0, "Other");

        assertFalse(validator.hasStock(null, 1));
        assertFalse(validator.hasStock(laptop, 0));
        assertFalse(validator.hasStock(laptop, -1));
        assertTrue(validator.hasStock(laptop, 10));
        assertFalse(validator.hasStock(laptop, 11));
        assertFalse(validator.hasStock(unavailable, 1));
        assertFalse(validator.hasStock(unknown, 1));
    }

    @Test
    void checkAvailabilityAndReduceStockFollowCartContents() {
        InventoryValidator validator = new InventoryValidator();
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");

        assertFalse(validator.checkAvailability(null));
        assertFalse(validator.checkAvailability(new Cart()));

        Cart cart = new Cart();
        cart.addItem(laptop, 2);
        cart.addItem(mouse, 5);
        assertTrue(validator.checkAvailability(cart));

        validator.reduceStock(cart);
        assertEquals(8, validator.getStockLevel(laptop));
        assertEquals(0, validator.getStockLevel(mouse));

        Cart tooLarge = new Cart();
        tooLarge.addItem(mouse, 1);
        assertFalse(validator.checkAvailability(tooLarge));
    }
}
