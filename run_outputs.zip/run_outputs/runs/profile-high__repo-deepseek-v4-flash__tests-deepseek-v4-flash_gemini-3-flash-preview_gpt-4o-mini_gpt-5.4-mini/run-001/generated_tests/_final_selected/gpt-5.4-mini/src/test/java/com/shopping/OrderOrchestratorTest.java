package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.Test;

class OrderOrchestratorTest {

    @Test
    void placeOrderReturnsNullWhenInventoryIsInsufficient() {
        OrderOrchestrator orchestrator = new OrderOrchestrator();
        Cart cart = new Cart();
        cart.addItem(new Product("P004", "Monitor", 299.99, "Electronics"), 1);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream original = System.out;
        System.setOut(new PrintStream(out));
        try {
            Order order = orchestrator.placeOrder("Alice", cart, "VIP", "SAVE20");
            assertNull(order);
        } finally {
            System.setOut(original);
        }

        assertTrue(out.toString().contains("Inventory validation failed."));
    }

    @Test
    void placeOrderCalculatesDiscountsFinalTotalAndReducesStock() {
        OrderOrchestrator orchestrator = new OrderOrchestrator();
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintStream original = System.out;
        System.setOut(new PrintStream(out));
        Order order;
        try {
            order = orchestrator.placeOrder("Alice", cart, "VIP", "SAVE20");
        } finally {
            System.setOut(original);
        }

        assertNotNull(order);
        assertEquals("Alice", order.getCustomerName());
        assertEquals(1059.97, order.getSubtotal(), 0.0001);
        assertEquals(415.50824, order.getDiscount(), 0.0001);
        assertEquals(696.02, order.getFinalTotal(), 0.01);
        assertEquals(1, order.getItems().get(0).getQuantity());
        assertEquals(2, order.getItems().get(1).getQuantity());
        assertTrue(out.toString().contains("========== RECEIPT =========="));
        assertTrue(out.toString().contains("Customer: Alice"));
        assertEquals(9, new InventoryValidator().getStockLevel(laptop));
        assertEquals(3, new InventoryValidator().getStockLevel(mouse));
    }

    @Test
    void placeOrderUsesCurrentCartSnapshotAndDoesNotFailOnValidRegularCustomer() {
        OrderOrchestrator orchestrator = new OrderOrchestrator();
        Product keyboard = new Product("P003", "Keyboard", 89.99, "Accessories");
        Cart cart = new Cart();
        cart.addItem(keyboard, 2);

        Order order = orchestrator.placeOrder("Bob", cart, "Regular", null);
        assertNotNull(order);
        assertEquals(179.98, order.getSubtotal(), 0.0001);
        assertEquals(0.0, order.getDiscount(), 0.0001);
        assertEquals(194.38, order.getFinalTotal(), 0.01);
        assertFalse(cart.isEmpty());
    }
}
