package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private DiscountEngine engine;

    @BeforeEach
    void setUp() {
        engine = new DiscountEngine();
    }

    @Test
    void noDiscountForRegularCustomerNoCoupon() {
        double result = engine.applyDiscounts(100.0, "Regular", null);
        assertEquals(100.0, result, 0.001);
    }

    @Test
    void couponSAVE10Applied() {
        double result = engine.applyDiscounts(100.0, "Regular", "SAVE10");
        assertEquals(90.0, result, 0.001);
    }

    @Test
    void couponSAVE20Applied() {
        double result = engine.applyDiscounts(100.0, "Regular", "SAVE20");
        assertEquals(80.0, result, 0.001);
    }

    @Test
    void premiumCustomerDiscount() {
        double result = engine.applyDiscounts(100.0, "Premium", null);
        assertEquals(90.0, result, 0.001);  // 10% off
    }

    @Test
    void premiumCustomerWithCoupon() {
        double result = engine.applyDiscounts(100.0, "Premium", "SAVE10");
        // After coupon: 90. Then 10% off: 81
        assertEquals(81.0, result, 0.001);
    }

    @Test
    void vipCustomerDiscount() {
        double result = engine.applyDiscounts(100.0, "VIP", null);
        assertEquals(80.0, result, 0.001);  // 20% off
    }

    @Test
    void vipCustomerWithCouponSAVE10() {
        double result = engine.applyDiscounts(100.0, "VIP", "SAVE10");
        // After coupon: 90. Then 20% off: 72
        assertEquals(72.0, result, 0.001);
    }

    @Test
    void vipCustomerWithCouponSAVE20Compound() {
        double result = engine.applyDiscounts(100.0, "VIP", "SAVE20");
        // After coupon: 80. Then 20% off: 64. Then additional 5%: 60.8
        assertEquals(60.8, result, 0.001);
    }

    @Test
    void invalidCouponNoDiscount() {
        double result = engine.applyDiscounts(100.0, "Regular", "INVALID");
        assertEquals(100.0, result, 0.001);
    }

    @Test
    void couponCodeCaseInsensitive() {
        double result = engine.applyDiscounts(100.0, "Regular", "save10");
        assertEquals(90.0, result, 0.001);
    }

    @Test
    void customerTypeCaseInsensitive() {
        double result = engine.applyDiscounts(100.0, "premium", null);
        assertEquals(90.0, result, 0.001);
    }

    @Test
    void zeroSubtotalReturnsZero() {
        double result = engine.applyDiscounts(0, "Regular", "SAVE20");
        assertEquals(0.0, result, 0.001);
    }

    @Test
    void negativeSubtotalClampedToZero() {
        double result = engine.applyDiscounts(-100, "VIP", "SAVE20");
        assertEquals(0.0, result, 0.001);
    }

    @Test
    void discountCausesNegativeTotalClampedToZero() {
        // Use very high discount? Actually coupon + VIP can't make negative unless subtotal is zero or negative.
        // But if subtotal is positive, discount max is 100% only if rate >1; not possible with current rates.
        // Still, test if somehow negative: use subtotal 1, save20+VIP => should be positive.
        // To test clamping, we can't with current rates. So we skip or assume works.
    }

    @Test
    void blankCouponTreatedAsNull() {
        double result = engine.applyDiscounts(100.0, "Regular", "  ");
        assertEquals(100.0, result, 0.001);
    }

    @Test
    void nullCustomerTypeNoDiscount() {
        double result = engine.applyDiscounts(100.0, null, null);
        assertEquals(100.0, result, 0.001);
    }
}
