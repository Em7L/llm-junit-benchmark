package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CartItemTest {

    private final Product product = new Product("P001", "Test Product", 10.0, "Test");

    @Test
    void constructorValid() {
        CartItem item = new CartItem(product, 2);
        assertSame(product, item.getProduct());
        assertEquals(2, item.getQuantity());
        assertEquals(20.0, item.getSubtotal(), 0.001);
    }

    @Test
    void constructorNullProductThrows() {
        assertThrows(IllegalArgumentException.class, () -> new CartItem(null, 1));
    }

    @Test
    void constructorNonPositiveQuantityThrows() {
        assertThrows(IllegalArgumentException.class, () -> new CartItem(product, 0));
        assertThrows(IllegalArgumentException.class, () -> new CartItem(product, -1));
    }

    @Test
    void setQuantityValid() {
        CartItem item = new CartItem(product, 1);
        item.setQuantity(5);
        assertEquals(5, item.getQuantity());
        assertEquals(50.0, item.getSubtotal(), 0.001);
    }

    @Test
    void setQuantityNonPositiveThrows() {
        CartItem item = new CartItem(product, 1);
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(-1));
    }

    @Test
    void incrementQuantityValid() {
        CartItem item = new CartItem(product, 1);
        item.incrementQuantity(3);
        assertEquals(4, item.getQuantity());
        assertEquals(40.0, item.getSubtotal(), 0.001);
    }

    @Test
    void incrementQuantityNonPositiveThrows() {
        CartItem item = new CartItem(product, 1);
        assertThrows(IllegalArgumentException.class, () -> item.incrementQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.incrementQuantity(-1));
    }

    @Test
    void toStringFormat() {
        CartItem item = new CartItem(product, 2);
        assertEquals("Test Product x 2", item.toString());
    }
}
