package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class OrderTest {

    @Test
    void constructorInitializesFields() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        CartItem item = new CartItem(p, 1);
        List<CartItem> items = List.of(item);
        Order order = new Order("Alice", items, 999.99, 100.0, 899.99);
        assertNotNull(order.getOrderId());
        assertEquals("Alice", order.getCustomerName());
        assertEquals(items, order.getItems());
        assertEquals(999.99, order.getSubtotal(), 0.001);
        assertEquals(100.0, order.getDiscount(), 0.001);
        assertEquals(899.99, order.getFinalTotal(), 0.001);
    }

    @Test
    void orderIdUnique() {
        Order order1 = new Order("Alice", List.of(), 0,0,0);
        Order order2 = new Order("Bob", List.of(), 0,0,0);
        assertNotEquals(order1.getOrderId(), order2.getOrderId());
    }

    @Test
    void getItemsReturnsUnmodifiableList() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        CartItem item = new CartItem(p, 1);
        Order order = new Order("Alice", List.of(item), 999.99, 0, 999.99);
        assertThrows(UnsupportedOperationException.class, () -> order.getItems().add(item));
    }

    @Test
    void toStringContainsFields() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        CartItem item = new CartItem(p, 1);
        Order order = new Order("Alice", List.of(item), 999.99, 100.0, 899.99);
        String s = order.toString();
        assertTrue(s.contains("Alice"));
        assertTrue(s.contains("999"));
        assertTrue(s.contains("99"));
        assertTrue(s.contains("100"));
        assertTrue(s.contains("00"));
        assertTrue(s.contains("899"));
    }
}
