package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class CartTest {

    private Cart cart;
    private Product laptop;
    private Product mouse;

    @BeforeEach
    void setUp() {
        cart = new Cart();
        laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        mouse = new Product("P002", "Mouse", 29.99, "Accessories");
    }

    @Test
    void newCartIsEmpty() {
        assertTrue(cart.isEmpty());
        assertEquals(0, cart.getItemCount());
        assertEquals(0, cart.getTotalQuantity());
    }

    @Test
    void addItemNewProduct() {
        cart.addItem(laptop, 1);
        assertFalse(cart.isEmpty());
        assertEquals(1, cart.getItemCount());
        assertEquals(1, cart.getTotalQuantity());
    }

    @Test
    void addItemExistingProductIncrementsQuantity() {
        cart.addItem(laptop, 2);
        cart.addItem(laptop, 3);
        assertEquals(1, cart.getItemCount());
        assertEquals(5, cart.getTotalQuantity());
    }

    @Test
    void addItemNonPositiveQuantityThrows() {
        assertThrows(IllegalArgumentException.class, () -> cart.addItem(laptop, 0));
        assertThrows(IllegalArgumentException.class, () -> cart.addItem(laptop, -1));
    }

    @Test
    void removeItemExisting() {
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        assertEquals(2, cart.getItemCount());
        cart.removeItem(laptop);
        assertEquals(1, cart.getItemCount());
        assertEquals(2, cart.getTotalQuantity());
        assertFalse(cart.getItems().contains(laptop));
    }

    @Test
    void removeItemNonExistingDoesNothing() {
        cart.addItem(laptop, 1);
        cart.removeItem(mouse);
        assertEquals(1, cart.getItemCount());
        CartItem item = cart.getItems().get(0);
        assertEquals(laptop, item.getProduct());
        assertEquals(1, item.getQuantity());
    }

    @Test
    void getItemsReturnsCopy() {
        cart.addItem(laptop, 1);
        List<CartItem> items = cart.getItems();
        items.clear();
        assertFalse(cart.isEmpty());
    }

    @Test
    void clearEmptiesCart() {
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        cart.clear();
        assertTrue(cart.isEmpty());
        assertEquals(0, cart.getItemCount());
        assertEquals(0, cart.getTotalQuantity());
    }

    @Test
    void toStringEmptyCart() {
        assertEquals("Cart is empty", cart.toString());
    }

    @Test
    void toStringNonEmpty() {
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        String s = cart.toString();
        assertTrue(s.contains("Laptop"));
        assertTrue(s.contains("Mouse"));
        assertTrue(s.contains("x 1"));
        assertTrue(s.contains("x 2"));
    }
}
