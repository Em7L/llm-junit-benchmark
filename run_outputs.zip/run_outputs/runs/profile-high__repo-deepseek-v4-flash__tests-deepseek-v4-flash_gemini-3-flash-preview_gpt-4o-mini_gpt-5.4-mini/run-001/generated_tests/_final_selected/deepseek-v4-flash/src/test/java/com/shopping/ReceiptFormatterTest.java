package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class ReceiptFormatterTest {

    private final ReceiptFormatter formatter = new ReceiptFormatter();

    @Test
    void formatReceiptNullOrder() {
        assertEquals("No order to display.", formatter.formatReceipt(null));
    }

    @Test
    void formatReceiptEmptyItems() {
        Order order = new Order("Alice", List.of(), 0.0, 0.0, 0.0);
        String receipt = formatter.formatReceipt(order);
        assertTrue(receipt.contains("(empty)"));
        assertTrue(receipt.contains("$0"));
    }

    @Test
    void formatReceiptTypicalOrder() {
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        CartItem item1 = new CartItem(laptop, 1);
        CartItem item2 = new CartItem(mouse, 2);
        Order order = new Order("Alice", List.of(item1, item2), 1059.97, 100.0, 959.97);
        String receipt = formatter.formatReceipt(order);
        assertTrue(receipt.contains("Laptop"));
        assertTrue(receipt.contains("Mouse"));
        assertTrue(receipt.contains("Alice"));
        assertTrue(receipt.contains("1059"));
        assertTrue(receipt.contains("100"));
        assertTrue(receipt.contains("959"));
        assertTrue(receipt.startsWith("========== RECEIPT =========="));
        assertTrue(receipt.endsWith("=============================="));
    }

    @Test
    void formatSummaryNullOrder() {
        assertEquals("No order.", formatter.formatSummary(null));
    }

    @Test
    void formatSummaryTypical() {
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        CartItem item = new CartItem(laptop, 1);
        Order order = new Order("Alice", List.of(item), 999.99, 0.0, 999.99);
        String summary = formatter.formatSummary(order);
        assertTrue(summary.contains(order.getOrderId()));
        assertTrue(summary.contains("1 items"));
        assertTrue(summary.contains("999"));
        assertTrue(summary.contains("99"));
    }

    @Test
    void formatSummaryEmptyItems() {
        Order order = new Order("Bob", List.of(), 0.0, 0.0, 0.0);
        String summary = formatter.formatSummary(order);
        assertTrue(summary.contains("0 items"));
    }
}
