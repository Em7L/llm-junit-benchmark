package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderOrchestratorTest {

    private OrderOrchestrator orchestrator;
    private Product laptop;
    private Product mouse;
    private Product monitor;
    private Cart validCart;

    @BeforeEach
    void setUp() {
        orchestrator = new OrderOrchestrator();
        laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        monitor = new Product("P004", "Monitor", 299.99, "Electronics");
        validCart = new Cart();
        validCart.addItem(laptop, 1);
        validCart.addItem(mouse, 2);
    }

    @Test
    void placeOrderSuccess() {
        Order order = orchestrator.placeOrder("Alice", validCart, "Regular", null);
        assertNotNull(order);
        assertEquals("Alice", order.getCustomerName());
        assertEquals(2, order.getItems().size());
        double expectedSubtotal = 999.99 + 2*29.99; // 1059.97
        assertEquals(expectedSubtotal, order.getSubtotal(), 0.001);
        assertEquals(0.0, order.getDiscount(), 0.001); // Regular, no coupon
        double expectedFinal = expectedSubtotal + expectedSubtotal*0.08; // 1144.7676
        assertEquals(expectedFinal, order.getFinalTotal(), 0.01);
    }

    @Test
    void placeOrderWithDiscount() {
        Order order = orchestrator.placeOrder("Bob", validCart, "VIP", "SAVE20");
        assertNotNull(order);
        // subtotal = 1059.97
        // coupon 20%: afterCoupon = 847.976
        // VIP 20%: 678.3808
        // additional 5% for SAVE20+VIP: 644.46176
        // discount = 1059.97 - 644.46176 = 415.50824
        // total = 644.46176, tax = 51.5569408, final = 696.0187008
        assertEquals(1059.97, order.getSubtotal(), 0.01);
        assertTrue(order.getDiscount() > 0);
        assertTrue(order.getFinalTotal() < order.getSubtotal());
    }

    @Test
    void placeOrderInsufficientStockReturnsNull() {
        Cart cart = new Cart();
        cart.addItem(laptop, 100); // not enough stock
        Order order = orchestrator.placeOrder("Charlie", cart, "Regular", null);
        assertNull(order);
    }

    @Test
    void placeOrderEmptyCartReturnsNull() {
        Cart emptyCart = new Cart();
        Order order = orchestrator.placeOrder("Dave", emptyCart, "Regular", null);
        assertNull(order);
    }

    @Test
    void placeOrderWithMonitorOutOfStock() {
        Cart cart = new Cart();
        cart.addItem(monitor, 1); // P004 has 0 stock
        Order order = orchestrator.placeOrder("Eve", cart, "Regular", null);
        assertNull(order);
    }

    @Test
    void placeOrderReducesStock() {
        orchestrator.placeOrder("Alice", validCart, "Regular", null);
        // After order, stock should be reduced
        // Use a new orchestrator? No, we can access via private? We'll use printStockStatus? Not available.
        // Instead, we can use InventoryValidator directly? Not from orchestrator.
        // To test stock reduction, we would need to expose getInventory? But we shouldn't modify production.
        // We'll skip detailed stock check, but the success of placeOrder implies stock was reduced (no exception).
        // However, we can create a second order that would fail if stock not reduced.
        Cart secondCart = new Cart();
        secondCart.addItem(laptop, 9); // after first order, laptop stock becomes 9.
        // Actually initial stock 10, first order used 1 laptop, so 9 left.
        // So this should succeed.
        Order secondOrder = orchestrator.placeOrder("Bob", secondCart, "Regular", null);
        assertNotNull(secondOrder);
        // Now try to order 1 more laptop, should fail
        Cart thirdCart = new Cart();
        thirdCart.addItem(laptop, 1);
        Order thirdOrder = orchestrator.placeOrder("Charlie", thirdCart, "Regular", null);
        assertNull(thirdOrder);
    }

    @Test
    void placeOrderWithNullCustomerName() {
        // Customer name can be null? Order constructor accepts it (no validation).
        // Not specified, but should not throw.
        Order order = orchestrator.placeOrder(null, validCart, "Regular", null);
        assertNotNull(order);
        assertNull(order.getCustomerName());
    }

    @Test
    void placeOrderWithInvalidCoupon() {
        Order order = orchestrator.placeOrder("Alice", validCart, "Regular", "INVALID");
        assertNotNull(order);
        assertEquals(0.0, order.getDiscount(), 0.001);
    }
}
