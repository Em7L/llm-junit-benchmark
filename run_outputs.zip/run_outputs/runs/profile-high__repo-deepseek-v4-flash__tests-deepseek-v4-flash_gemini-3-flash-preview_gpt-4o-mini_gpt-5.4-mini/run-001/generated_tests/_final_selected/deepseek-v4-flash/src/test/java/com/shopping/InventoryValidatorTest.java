package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryValidatorTest {

    private InventoryValidator inventory;
    private Product laptop;
    private Product mouse;
    private Product monitor;

    @BeforeEach
    void setUp() {
        inventory = new InventoryValidator();
        laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        monitor = new Product("P004", "Monitor", 299.99, "Electronics");
    }

    @Test
    void hasStockValid() {
        assertTrue(inventory.hasStock(laptop, 10));
        assertTrue(inventory.hasStock(mouse, 5));
    }

    @Test
    void hasStockInsufficient() {
        assertFalse(inventory.hasStock(laptop, 11));
    }

    @Test
    void hasStockZeroQuantityReturnsFalse() {
        assertFalse(inventory.hasStock(laptop, 0));
    }

    @Test
    void hasStockNegativeQuantityReturnsFalse() {
        assertFalse(inventory.hasStock(laptop, -1));
    }

    @Test
    void hasStockNullProductReturnsFalse() {
        assertFalse(inventory.hasStock(null, 1));
    }

    @Test
    void hasStockUnknownProductReturnsFalse() {
        Product unknown = new Product("UNKNOWN", "Unknown", 10, "Test");
        assertFalse(inventory.hasStock(unknown, 1));
    }

    @Test
    void checkAvailabilityValidCart() {
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        assertTrue(inventory.checkAvailability(cart));
    }

    @Test
    void checkAvailabilityInsufficientStock() {
        Cart cart = new Cart();
        cart.addItem(laptop, 11); // only 10 available
        assertFalse(inventory.checkAvailability(cart));
    }

    @Test
    void checkAvailabilityEmptyCartReturnsFalse() {
        Cart cart = new Cart();
        assertFalse(inventory.checkAvailability(cart));
    }

    @Test
    void checkAvailabilityNullCartReturnsFalse() {
        assertFalse(inventory.checkAvailability(null));
    }

    @Test
    void reduceStockReducesQuantity() {
        Cart cart = new Cart();
        cart.addItem(laptop, 3);
        inventory.reduceStock(cart);
        assertEquals(7, inventory.getStockLevel(laptop));
    }

    @Test
    void reduceStockMultipleItems() {
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        inventory.reduceStock(cart);
        assertEquals(9, inventory.getStockLevel(laptop));
        assertEquals(3, inventory.getStockLevel(mouse));
    }

    @Test
    void reduceStockEmptyCartDoesNothing() {
        Cart cart = new Cart();
        inventory.reduceStock(cart);
        assertEquals(10, inventory.getStockLevel(laptop)); // unchanged
    }

    @Test
    void reduceStockNullCartDoesNothing() {
        inventory.reduceStock(null);
        assertEquals(10, inventory.getStockLevel(laptop));
    }

    @Test
    void getStockLevelForProduct() {
        assertEquals(10, inventory.getStockLevel(laptop));
        assertEquals(5, inventory.getStockLevel(mouse));
        assertEquals(0, inventory.getStockLevel(monitor)); // P004 has 0
    }

    @Test
    void getStockLevelUnknownProductReturnsDefaultZero() {
        Product unknown = new Product("X", "X", 1, "Test");
        assertEquals(0, inventory.getStockLevel(unknown));
    }
}
