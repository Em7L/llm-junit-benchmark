package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void constructorValid() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        assertNotNull(p);
        assertEquals("P001", p.getId());
        assertEquals("Laptop", p.getName());
        assertEquals(999.99, p.getPrice(), 0.001);
        assertEquals("Electronics", p.getCategory());
    }

    @Test
    void constructorNullIdThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Name", 10, "Cat"));
    }

    @Test
    void constructorBlankIdThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product("", "Name", 10, "Cat"));
    }

    @Test
    void constructorNullNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", null, 10, "Cat"));
    }

    @Test
    void constructorBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "", 10, "Cat"));
    }

    @Test
    void constructorNonPositivePriceThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "Name", 0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "Name", -1, "Cat"));
    }

    @Test
    void constructorNullCategoryThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "Name", 10, null));
    }

    @Test
    void constructorBlankCategoryThrows() {
        assertThrows(IllegalArgumentException.class, () -> new Product("P001", "Name", 10, ""));
    }

    @Test
    void equalsBasedOnId() {
        Product p1 = new Product("P001", "Laptop", 999.99, "Electronics");
        Product p2 = new Product("P001", "Laptop", 999.99, "Electronics");
        Product p3 = new Product("P002", "Mouse", 29.99, "Accessories");
        assertEquals(p1, p2);
        assertNotEquals(p1, p3);
        assertNotEquals(p1, null);
        assertNotEquals(p1, "string");
    }

    @Test
    void hashCodeConsistent() {
        Product p1 = new Product("P001", "Laptop", 999.99, "Electronics");
        Product p2 = new Product("P001", "Laptop", 999.99, "Electronics");
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    void isEligibleForDiscountElectronicsReturnsFalse() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        assertFalse(p.isEligibleForDiscount());
    }

    @Test
    void isEligibleForDiscountNonElectronicsReturnsTrue() {
        Product p = new Product("P002", "Mouse", 29.99, "Accessories");
        assertTrue(p.isEligibleForDiscount());
    }

    @Test
    void toStringContainsIdAndName() {
        Product p = new Product("P001", "Laptop", 999.99, "Electronics");
        String s = p.toString();
        assertTrue(s.contains("P001"));
        assertTrue(s.contains("Laptop"));
    }
}
