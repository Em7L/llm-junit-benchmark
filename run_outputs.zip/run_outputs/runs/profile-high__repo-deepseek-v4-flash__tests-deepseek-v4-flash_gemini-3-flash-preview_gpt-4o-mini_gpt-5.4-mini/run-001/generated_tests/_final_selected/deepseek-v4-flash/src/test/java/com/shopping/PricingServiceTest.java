package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PricingServiceTest {

    private PricingService pricing;
    private Product laptop;
    private Product mouse;

    @BeforeEach
    void setUp() {
        pricing = new PricingService();
        laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        mouse = new Product("P002", "Mouse", 29.99, "Accessories");
    }

    @Test
    void calculateSubtotalEmptyCart() {
        Cart cart = new Cart();
        assertEquals(0.0, pricing.calculateSubtotal(cart), 0.001);
    }

    @Test
    void calculateSubtotalNullCartReturnsZero() {
        assertEquals(0.0, pricing.calculateSubtotal(null), 0.001);
    }

    @Test
    void calculateSubtotalSingleItem() {
        Cart cart = new Cart();
        cart.addItem(laptop, 2);
        assertEquals(1999.98, pricing.calculateSubtotal(cart), 0.001);
    }

    @Test
    void calculateSubtotalMultipleItems() {
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 3);
        double expected = 999.99 + 3*29.99;
        assertEquals(expected, pricing.calculateSubtotal(cart), 0.001);
    }

    @Test
    void calculateTotalNoDiscount() {
        assertEquals(100.0, pricing.calculateTotal(100.0, 0.0), 0.001);
    }

    @Test
    void calculateTotalWithDiscount() {
        assertEquals(80.0, pricing.calculateTotal(100.0, 20.0), 0.001);
    }

    @Test
    void calculateTotalDiscountGreaterThanSubtotalClampedToZero() {
        assertEquals(0.0, pricing.calculateTotal(100.0, 150.0), 0.001);
    }

    @Test
    void calculateTax() {
        assertEquals(8.0, pricing.calculateTax(100.0), 0.001);
    }

    @Test
    void calculateTaxZero() {
        assertEquals(0.0, pricing.calculateTax(0.0), 0.001);
    }

    @Test
    void computeFinalAmountNoDiscount() {
        double result = pricing.computeFinalAmount(100.0, 0.0);
        // total=100, tax=8 => 108
        assertEquals(108.0, result, 0.001);
    }

    @Test
    void computeFinalAmountWithDiscount() {
        double result = pricing.computeFinalAmount(100.0, 20.0);
        // total=80, tax=6.4 => 86.4
        assertEquals(86.4, result, 0.001);
    }

    @Test
    void computeFinalAmountDiscountExceedsSubtotal() {
        double result = pricing.computeFinalAmount(100.0, 200.0);
        // total=0, tax=0 => 0
        assertEquals(0.0, result, 0.001);
    }
}
