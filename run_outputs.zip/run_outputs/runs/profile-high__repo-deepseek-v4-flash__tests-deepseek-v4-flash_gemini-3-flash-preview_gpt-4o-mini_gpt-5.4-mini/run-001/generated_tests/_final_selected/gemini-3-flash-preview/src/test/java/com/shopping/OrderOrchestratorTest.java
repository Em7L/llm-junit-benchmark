package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderOrchestratorTest {
    @Test
    void placeOrderFullFlowSuccess() {
        OrderOrchestrator orchestrator = new OrderOrchestrator();
        Cart cart = new Cart();
        Product mouse = new Product("P002", "Mouse", 25.0, "Accessories");
        cart.addItem(mouse, 2); // Subtotal 50.0

        // Regular customer, no coupon
        // Subtotal: 50.0
        // Discount: 0.0
        // Total before tax: 50.0
        // Tax (8%): 4.0
        // Final: 54.0
        Order order = orchestrator.placeOrder("John", cart, "Regular", null);

        assertNotNull(order);
        assertEquals(50.0, order.getSubtotal());
        assertEquals(0.0, order.getDiscount());
        assertEquals(54.0, order.getFinalTotal(), 0.001);
        assertEquals("John", order.getCustomerName());
    }

    @Test
    void placeOrderFailsWhenOutOfStock() {
        OrderOrchestrator orchestrator = new OrderOrchestrator();
        Cart cart = new Cart();
        Product laptop = new Product("P001", "Laptop", 1000.0, "Electronics");
        cart.addItem(laptop, 50); // Only 10 in stock

        Order order = orchestrator.placeOrder("John", cart, "Regular", null);
        assertNull(order);
    }

    @Test
    void placeOrderWithVipAndCoupon() {
        OrderOrchestrator orchestrator = new OrderOrchestrator();
        Cart cart = new Cart();
        Product mouse = new Product("P002", "Mouse", 100.0, "Accessories");
        cart.addItem(mouse, 1);

        // Subtotal: 100.0
        // After SAVE20: 80.0
        // After VIP: 64.0
        // After Bonus: 60.8
        // Discount: 100 - 60.8 = 39.2
        // Tax: 60.8 * 0.08 = 4.864
        // Final: 65.664
        Order order = orchestrator.placeOrder("Alice", cart, "VIP", "SAVE20");

        assertNotNull(order);
        assertEquals(39.2, order.getDiscount(), 0.001);
        assertEquals(65.664, order.getFinalTotal(), 0.001);
    }
}