package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryValidatorTest {
    private InventoryValidator validator;
    private Product p1;
    private Product p4;

    @BeforeEach
    void setUp() {
        validator = new InventoryValidator();
        p1 = new Product("P001", "Laptop", 999.99, "Electronics");
        p4 = new Product("P004", "Monitor", 299.99, "Electronics");
    }

    @Test
    void checksStockCorrectly() {
        assertTrue(validator.hasStock(p1, 5));
        assertTrue(validator.hasStock(p1, 10));
        assertFalse(validator.hasStock(p1, 11));
        assertFalse(validator.hasStock(p4, 1)); // P004 starts at 0
    }

    @Test
    void checkAvailabilityForCart() {
        Cart cart = new Cart();
        cart.addItem(p1, 2);
        assertTrue(validator.checkAvailability(cart));

        cart.addItem(p4, 1);
        assertFalse(validator.checkAvailability(cart));
    }

    @Test
    void reducesStockLevels() {
        Cart cart = new Cart();
        cart.addItem(p1, 3);
        validator.reduceStock(cart);
        assertEquals(7, validator.getStockLevel(p1));
    }
}