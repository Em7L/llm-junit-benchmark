package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {
    @Test
    void constructorValidatesInputs() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Name", 10.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("ID", " ", 10.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("ID", "Name", -1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("ID", "Name", 10.0, ""));
    }

    @Test
    void eligibilityForDiscountDependsOnCategory() {
        Product electronics = new Product("P1", "Laptop", 1000.0, "Electronics");
        Product books = new Product("P2", "Novel", 20.0, "Books");
        assertFalse(electronics.isEligibleForDiscount());
        assertTrue(books.isEligibleForDiscount());
    }

    @Test
    void equalsAndHashCodeBasedOnId() {
        Product p1 = new Product("P1", "Name1", 10.0, "Cat");
        Product p2 = new Product("P1", "Name2", 20.0, "Other");
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
    }
}