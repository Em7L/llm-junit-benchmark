package com.shopping;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CartTest {
    private Cart cart;
    private Product product;

    @BeforeEach
    void setUp() {
        cart = new Cart();
        product = new Product("P1", "Item", 10.0, "Goods");
    }

    @Test
    void addsAndIncrementsItems() {
        cart.addItem(product, 2);
        assertEquals(1, cart.getItemCount());
        assertEquals(2, cart.getTotalQuantity());

        cart.addItem(product, 3);
        assertEquals(1, cart.getItemCount());
        assertEquals(5, cart.getTotalQuantity());
    }

    @Test
    void rejectsInvalidQuantity() {
        assertThrows(IllegalArgumentException.class, () -> cart.addItem(product, 0));
        assertThrows(IllegalArgumentException.class, () -> cart.addItem(product, -1));
    }

    @Test
    void removesAndClearsItems() {
        cart.addItem(product, 1);
        assertFalse(cart.isEmpty());
        cart.removeItem(product);
        assertTrue(cart.isEmpty());

        cart.addItem(product, 5);
        cart.clear();
        assertEquals(0, cart.getItemCount());
    }
}