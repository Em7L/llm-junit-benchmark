package com.shopping;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {
    private final DiscountEngine engine = new DiscountEngine();

    @Test
    void applyDiscountsBoundaryCases() {
        assertEquals(0.0, engine.applyDiscounts(0, "VIP", "SAVE20"));
        assertEquals(0.0, engine.applyDiscounts(-10, "Regular", null));
    }

    @Test
    void applyCouponDiscounts() {
        // 100 - 10%
        assertEquals(90.0, engine.applyDiscounts(100.0, "Regular", "SAVE10"), 0.001);
        // 100 - 20%
        assertEquals(80.0, engine.applyDiscounts(100.0, "Regular", "SAVE20"), 0.001);
        // Invalid coupon
        assertEquals(100.0, engine.applyDiscounts(100.0, "Regular", "INVALID"), 0.001);
    }

    @Test
    void applyCustomerTypeDiscounts() {
        // Premium 10%
        assertEquals(90.0, engine.applyDiscounts(100.0, "Premium", null), 0.001);
        // VIP 20%
        assertEquals(80.0, engine.applyDiscounts(100.0, "VIP", null), 0.001);
    }

    @Test
    void applyCompoundVipDiscount() {
        // VIP (20%) + SAVE20 (20%) + Bonus (5% off the result)
        // 100 * 0.8 (SAVE20) = 80
        // 80 * 0.8 (VIP) = 64
        // 64 * 0.95 (Bonus) = 60.8
        assertEquals(60.8, engine.applyDiscounts(100.0, "VIP", "SAVE20"), 0.001);
    }
}