package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ProductTest {

    @Test
    void constructorRejectsBlankOrInvalidValues() {
        assertThrows(IllegalArgumentException.class, () -> new Product(null, "Name", 1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("", "Name", 1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", null, 1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "", 1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 0.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", -1.0, "Cat"));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 1.0, null));
        assertThrows(IllegalArgumentException.class, () -> new Product("P1", "Name", 1.0, ""));
    }

    @Test
    void equalsAndHashCodeUseProductIdOnly() {
        Product first = new Product("P001", "Laptop", 999.99, "Electronics");
        Product sameIdDifferentData = new Product("P001", "Different", 10.0, "Accessories");
        Product differentId = new Product("P002", "Laptop", 999.99, "Electronics");

        assertEquals(first, sameIdDifferentData);
        assertEquals(first.hashCode(), sameIdDifferentData.hashCode());
        assertFalse(first.equals(differentId));
        assertFalse(first.equals(null));
        assertFalse(first.equals("P001"));
    }

    @Test
    void discountEligibilityDependsOnCategory() {
        Product electronics = new Product("P001", "Laptop", 999.99, "Electronics");
        Product accessories = new Product("P002", "Mouse", 29.99, "Accessories");

        assertFalse(electronics.isEligibleForDiscount());
        assertTrue(accessories.isEligibleForDiscount());
    }

    @Test
    void toStringContainsKeyFields() {
        Product product = new Product("P001", "Laptop", 999.99, "Electronics");

        String text = product.toString();
        assertTrue(text.contains("P001"));
        assertTrue(text.contains("Laptop"));
        assertTrue(text.contains("999.99"));
        assertTrue(text.contains("Electronics"));
    }
}
