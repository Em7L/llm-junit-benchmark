package com.shopping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class DiscountAndPricingTest {

    @Test
    void applyDiscountsHandlesCouponsCustomerTypesAndEdgeCases() {
        DiscountEngine engine = new DiscountEngine();

        assertEquals(0.0, engine.applyDiscounts(0.0, "VIP", "SAVE20"), 0.0001);
        assertEquals(0.0, engine.applyDiscounts(-10.0, "VIP", "SAVE20"), 0.0001);

        assertEquals(100.0, engine.applyDiscounts(100.0, "Regular", null), 0.0001);
        assertEquals(90.0, engine.applyDiscounts(100.0, "Regular", "SAVE10"), 0.0001);
        assertEquals(72.0, engine.applyDiscounts(100.0, "Premium", "SAVE10"), 0.0001);
        assertEquals(68.4, engine.applyDiscounts(100.0, "VIP", "SAVE20"), 0.0001);
        assertEquals(72.0, engine.applyDiscounts(100.0, "vip", "save10"), 0.0001);
        assertEquals(80.0, engine.applyDiscounts(100.0, "VIP", "INVALID"), 0.0001);
        assertEquals(90.0, engine.applyDiscounts(100.0, "Premium", "INVALID"), 0.0001);
    }

    @Test
    void pricingServiceComputesTotalsTaxAndFinalAmount() {
        PricingService pricing = new PricingService();

        Cart cart = new Cart();
        cart.addItem(new Product("P001", "Laptop", 999.99, "Electronics"), 1);
        cart.addItem(new Product("P002", "Mouse", 29.99, "Accessories"), 2);

        assertEquals(1059.97, pricing.calculateSubtotal(cart), 0.0001);
        assertEquals(0.0, pricing.calculateSubtotal(null), 0.0001);
        assertEquals(0.0, pricing.calculateSubtotal(new Cart()), 0.0001);

        assertEquals(50.0, pricing.calculateTotal(100.0, 50.0), 0.0001);
        assertEquals(0.0, pricing.calculateTotal(100.0, 150.0), 0.0001);
        assertEquals(8.0, pricing.calculateTax(100.0), 0.0001);
        assertEquals(108.0, pricing.computeFinalAmount(100.0, 0.0), 0.0001);
        assertEquals(54.0, pricing.computeFinalAmount(100.0, 50.0), 0.0001);
    }

    @Test
    void pricingDoesNotDependOnCartMutationAfterSubtotalCalculation() {
        PricingService pricing = new PricingService();
        Cart cart = new Cart();
        Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        cart.addItem(mouse, 1);

        double subtotal = pricing.calculateSubtotal(cart);
        cart.addItem(mouse, 1);

        assertEquals(29.99, subtotal, 0.0001);
        assertEquals(59.98, pricing.calculateSubtotal(cart), 0.0001);
    }
}
