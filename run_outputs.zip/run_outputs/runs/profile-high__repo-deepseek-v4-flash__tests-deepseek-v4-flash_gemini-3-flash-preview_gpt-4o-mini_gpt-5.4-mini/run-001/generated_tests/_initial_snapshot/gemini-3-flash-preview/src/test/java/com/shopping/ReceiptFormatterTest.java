package com.shopping;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ReceiptFormatterTest {
    private final ReceiptFormatter formatter = new ReceiptFormatter();

    @Test
    void handlesNullOrder() {
        assertEquals("No order to display.", formatter.formatReceipt(null));
        assertEquals("No order.", formatter.formatSummary(null));
    }

    @Test
    void formatsReceiptWithContent() {
        Product p = new Product("P1", "Widget", 10.0, "Gadgets");
        CartItem item = new CartItem(p, 2);
        Order order = new Order("Bob", List.of(item), 20.0, 5.0, 16.2);

        String receipt = formatter.formatReceipt(order);
        assertTrue(receipt.contains("RECEIPT"));
        assertTrue(receipt.contains("Bob"));
        assertTrue(receipt.contains("Widget x2 - $20.00"));
        assertTrue(receipt.contains("Subtotal: $20.00"));
        assertTrue(receipt.contains("Discount: -$5.00"));
        assertTrue(receipt.contains("Total: $16.20"));
    }

    @Test
    void formatsSummary() {
        Product p = new Product("P1", "Widget", 10.0, "Gadgets");
        CartItem item = new CartItem(p, 1);
        Order order = new Order("Bob", List.of(item), 10.0, 0.0, 10.8);
        String summary = formatter.formatSummary(order);
        assertTrue(summary.contains("1 items"));
        assertTrue(summary.contains("total $10.80"));
    }
}