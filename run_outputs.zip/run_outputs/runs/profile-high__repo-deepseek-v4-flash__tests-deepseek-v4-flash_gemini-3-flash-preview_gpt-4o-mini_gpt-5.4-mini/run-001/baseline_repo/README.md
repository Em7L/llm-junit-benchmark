# generated-java-app

A self-contained shopping cart and order management application written in Java 21. It demonstrates high-complexity logic including inventory validation, multi-tier discounting (coupons, customer types), pricing with tax, and receipt formatting. The application uses Maven with JaCoCo, Surefire, and Exec plugins.

The main entry point is `com.shopping.OrderOrchestrator`, which provides a sample order flow.

## Complexity Summary

- **Number of classes**: 9 (Product, CartItem, Cart, DiscountEngine, InventoryValidator, PricingService, Order, ReceiptFormatter, OrderOrchestrator)
- **Total public methods**: 27
- **Methods with >= 3 branches**: 5 (DiscountEngine.applyDiscounts, InventoryValidator.hasStock, InventoryValidator.checkAvailability, OrderOrchestrator.placeOrder, ReceiptFormatter.formatReceipt)
- **Class descriptions**:
  - `Product`: Represents a product with ID, name, price, category. Includes validation in constructor.
  - `CartItem`: Line item linking product and quantity, with subtotal calculation.
  - `Cart`: Manages collection of CartItems, supports add/remove/clear and aggregated queries.
  - `DiscountEngine`: Applies percentage discounts based on customer type and coupon code, with compound rules.
  - `InventoryValidator`: Tracks stock levels, validates availability, and reduces stock.
  - `PricingService`: Computes subtotal, total, tax, and final amount.
  - `Order`: Immutable order snapshot with order ID, items, and financials.
  - `ReceiptFormatter`: Generates formatted receipts and summaries.
  - `OrderOrchestrator`: Coordinates inventory check, pricing, discounting, stock reduction, and order creation; also includes a main method for demonstration.
