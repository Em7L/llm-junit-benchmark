package com.shopping;

import java.util.List;
import java.util.stream.Collectors;

public class ReceiptFormatter {

    /**
     * Format a complete receipt string from an order.
     * Handles edge cases: null order, empty items.
     */
    public String formatReceipt(Order order) {
        if (order == null) {
            return "No order to display.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("========== RECEIPT ==========\n");
        sb.append("Order ID: ").append(order.getOrderId()).append("\n");
        sb.append("Customer: ").append(order.getCustomerName()).append("\n");
        sb.append("Items:\n");
        List<CartItem> items = order.getItems();
        if (items.isEmpty()) {
            sb.append("  (empty)");
        } else {
            String itemsStr = items.stream()
                    .map(item -> String.format("  %s x%d - $%.2f", item.getProduct().getName(), item.getQuantity(), item.getSubtotal()))
                    .collect(Collectors.joining("\n"));
            sb.append(itemsStr);
        }
        sb.append("\n");
        sb.append(String.format("Subtotal: $%.2f\n", order.getSubtotal()));
        sb.append(String.format("Discount: -$%.2f\n", order.getDiscount()));
        sb.append(String.format("Total: $%.2f\n", order.getFinalTotal()));
        sb.append("==============================");
        return sb.toString();
    }

    /**
     * Format a short summary of the order.
     */
    public String formatSummary(Order order) {
        if (order == null) return "No order.";
        return String.format("Order %s: %d items, total $%.2f", order.getOrderId(), order.getItems().size(), order.getFinalTotal());
    }
}