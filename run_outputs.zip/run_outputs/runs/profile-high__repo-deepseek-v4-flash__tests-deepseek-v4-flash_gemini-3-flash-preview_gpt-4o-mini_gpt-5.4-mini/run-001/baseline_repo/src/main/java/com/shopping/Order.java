package com.shopping;

import java.util.List;
import java.util.UUID;

public class Order {
    private final String orderId;
    private final String customerName;
    private final List<CartItem> items;
    private final double subtotal;
    private final double discount;
    private final double finalTotal;

    public Order(String customerName, List<CartItem> items, double subtotal, double discount, double finalTotal) {
        this.orderId = UUID.randomUUID().toString().substring(0, 8);
        this.customerName = customerName;
        this.items = List.copyOf(items);
        this.subtotal = subtotal;
        this.discount = discount;
        this.finalTotal = finalTotal;
    }

    public String getOrderId() { return orderId; }
    public String getCustomerName() { return customerName; }
    public List<CartItem> getItems() { return items; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public double getFinalTotal() { return finalTotal; }

    @Override
    public String toString() {
        return String.format("Order{id='%s', customer='%s', items=%d, subtotal=%.2f, discount=%.2f, total=%.2f}",
                orderId, customerName, items.size(), subtotal, discount, finalTotal);
    }
}