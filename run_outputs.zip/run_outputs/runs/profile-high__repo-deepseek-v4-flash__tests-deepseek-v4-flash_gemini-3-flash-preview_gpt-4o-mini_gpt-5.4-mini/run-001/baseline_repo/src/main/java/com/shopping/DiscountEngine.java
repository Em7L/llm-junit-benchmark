package com.shopping;

import java.util.HashMap;
import java.util.Map;

public class DiscountEngine {
    private final Map<String, Double> couponRates;

    public DiscountEngine() {
        couponRates = new HashMap<>();
        couponRates.put("SAVE10", 0.10);
        couponRates.put("SAVE20", 0.20);
        // Additional coupons can be added
    }

    /**
     * Apply discounts based on customer type and coupon code.
     * Rules:
     * - Regular customers: no additional discount.
     * - Premium customers: 10% off on subtotal after coupon.
     * - VIP customers: 20% off on subtotal after coupon.
     * - Coupon codes: SAVE10 gives 10% off, SAVE20 gives 20% off.
     * - If customer type is VIP and coupon is SAVE20, additional 5% off (compound).
     * - If total after discount is less than 0, it's clamped to 0.
     */
    public double applyDiscounts(double subtotal, String customerType, String couponCode) {
        if (subtotal <= 0) {
            return 0.0;
        }
        double afterCoupon = subtotal;
        if (couponCode != null && !couponCode.isBlank()) {
            Double rate = couponRates.get(couponCode.toUpperCase());
            if (rate != null) {
                afterCoupon = subtotal * (1 - rate);
            }
            // else invalid coupon, no discount
        }
        double afterCustomer = afterCoupon;
        if (customerType != null) {
            if (customerType.equalsIgnoreCase("Premium")) {
                afterCustomer = afterCoupon * 0.9;
            } else if (customerType.equalsIgnoreCase("VIP")) {
                afterCustomer = afterCoupon * 0.8;
                // Additional bonus if coupon is SAVE20
                if (couponCode != null && couponCode.equalsIgnoreCase("SAVE20")) {
                    afterCustomer = afterCustomer * 0.95;
                }
            }
            // Regular, no discount
        }
        if (afterCustomer < 0) afterCustomer = 0;
        return afterCustomer;
    }
}