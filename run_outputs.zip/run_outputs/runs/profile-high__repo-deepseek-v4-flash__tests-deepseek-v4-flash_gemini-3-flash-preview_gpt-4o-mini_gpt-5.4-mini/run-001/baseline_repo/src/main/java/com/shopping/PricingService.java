package com.shopping;

public class PricingService {

    /**
     * Calculate subtotal from cart.
     */
    public double calculateSubtotal(Cart cart) {
        if (cart == null || cart.isEmpty()) return 0.0;
        return cart.getItems().stream()
                .mapToDouble(CartItem::getSubtotal)
                .sum();
    }

    /**
     * Calculate final total after applying discount.
     */
    public double calculateTotal(double subtotal, double discount) {
        double total = subtotal - discount;
        if (total < 0) total = 0;
        return total;
    }

    /**
     * Compute tax (8% of total).
     */
    public double calculateTax(double total) {
        return total * 0.08;
    }

    /**
     * Compute final amount including tax.
     */
    public double computeFinalAmount(double subtotal, double discount) {
        double total = calculateTotal(subtotal, discount);
        double tax = calculateTax(total);
        return total + tax;
    }
}