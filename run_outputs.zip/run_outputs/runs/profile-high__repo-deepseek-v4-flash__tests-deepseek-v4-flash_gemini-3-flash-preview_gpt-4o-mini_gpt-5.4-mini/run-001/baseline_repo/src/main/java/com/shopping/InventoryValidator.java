package com.shopping;

import java.util.HashMap;
import java.util.Map;

public class InventoryValidator {
    private final Map<String, Integer> stock; // product ID -> available quantity

    public InventoryValidator() {
        stock = new HashMap<>();
        stock.put("P001", 10);
        stock.put("P002", 5);
        stock.put("P003", 20);
        stock.put("P004", 0);
    }

    /**
     * Check if a single product has sufficient stock.
     */
    public boolean hasStock(Product product, int quantity) {
        if (product == null) return false;
        if (quantity <= 0) return false;
        Integer available = stock.get(product.getId());
        return available != null && available >= quantity;
    }

    /**
     * Validate entire cart against stock. Returns true if all items are available.
     */
    public boolean checkAvailability(Cart cart) {
        if (cart == null || cart.isEmpty()) return false;
        for (CartItem item : cart.getItems()) {
            if (!hasStock(item.getProduct(), item.getQuantity())) {
                return false;
            }
        }
        return true;
    }

    /**
     * Reduce stock for items in cart. Assumes availability already checked.
     */
    public void reduceStock(Cart cart) {
        if (cart == null || cart.isEmpty()) return;
        for (CartItem item : cart.getItems()) {
            String productId = item.getProduct().getId();
            int current = stock.getOrDefault(productId, 0);
            stock.put(productId, current - item.getQuantity());
        }
    }

    // Method to get current stock level (for testing/display)
    public int getStockLevel(Product product) {
        return stock.getOrDefault(product.getId(), 0);
    }
}