package com.shopping;

public class OrderOrchestrator {
    private final InventoryValidator inventory;
    private final PricingService pricing;
    private final DiscountEngine discountEngine;
    private final ReceiptFormatter receiptFormatter;

    public OrderOrchestrator() {
        this.inventory = new InventoryValidator();
        this.pricing = new PricingService();
        this.discountEngine = new DiscountEngine();
        this.receiptFormatter = new ReceiptFormatter();
    }

    /**
     * Orchestrate order placement: validate inventory, calculate pricing, apply discounts, create order.
     * Returns the order if successful, null if validation fails.
     */
    public Order placeOrder(String customerName, Cart cart, String customerType, String couponCode) {
        // Step 1: Validate inventory
        if (!inventory.checkAvailability(cart)) {
            System.out.println("Inventory validation failed.");
            return null;
        }

        // Step 2: Calculate subtotal
        double subtotal = pricing.calculateSubtotal(cart);

        // Step 3: Apply discounts
        double discountedTotal = discountEngine.applyDiscounts(subtotal, customerType, couponCode);
        double discount = subtotal - discountedTotal;

        // Step 4: Compute final amount (including tax)
        double finalTotal = pricing.computeFinalAmount(subtotal, discount);

        // Step 5: Reduce stock
        inventory.reduceStock(cart);

        // Step 6: Create order
        Order order = new Order(customerName, cart.getItems(), subtotal, discount, finalTotal);

        // Print receipt
        System.out.println(receiptFormatter.formatReceipt(order));

        return order;
    }

    // Helper for debug
    public void printStockStatus() {
        System.out.println("Current stock levels:");
        // For simplicity, just print known products; ideally iterate over product database
        System.out.println("P001: " + inventory.getStockLevel(new Product("P001", "Laptop", 999.99, "Electronics")));
        System.out.println("P002: " + inventory.getStockLevel(new Product("P002", "Mouse", 29.99, "Accessories")));
        System.out.println("P003: " + inventory.getStockLevel(new Product("P003", "Keyboard", 89.99, "Accessories")));
        System.out.println("P004: " + inventory.getStockLevel(new Product("P004", "Monitor", 299.99, "Electronics")));
    }

    public static void main(String[] args) {
        // Create products
        Product laptop = new Product("P001", "Laptop", 999.99, "Electronics");
        Product mouse = new Product("P002", "Mouse", 29.99, "Accessories");
        Product keyboard = new Product("P003", "Keyboard", 89.99, "Accessories");
        Product monitor = new Product("P004", "Monitor", 299.99, "Electronics");

        // Create cart
        Cart cart = new Cart();
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        cart.addItem(keyboard, 1);

        // Create orchestrator
        OrderOrchestrator orchestrator = new OrderOrchestrator();

        // Place order with VIP customer and SAVE20 coupon
        Order order = orchestrator.placeOrder("Alice", cart, "VIP", "SAVE20");

        // Print stock after order
        orchestrator.printStockStatus();
    }
}