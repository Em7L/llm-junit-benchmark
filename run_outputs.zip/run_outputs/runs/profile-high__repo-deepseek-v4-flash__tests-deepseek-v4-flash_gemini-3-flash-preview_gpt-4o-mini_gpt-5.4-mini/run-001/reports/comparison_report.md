# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-001/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_partially_improved | 1 |
| deepseek-v4-flash | passed | repair_successful | 1 |
| gemini-3-flash-preview | passed | repair_successful | 1 |
| gpt-4o-mini | passed | repair_not_needed | 0 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 20 | 5 | 0 | 83.25% | 78.26% | 130 | 89 | 16 | 25 | 68.46% |
| deepseek-v4-flash | test_failures | 93 | 5 | 0 | 89.66% | 97.83% | 130 | 110 | 10 | 10 | 84.62% |
| gemini-3-flash-preview | test_failures | 19 | 2 | 0 | 81.28% | 68.48% | 130 | 88 | 19 | 23 | 67.69% |
| gpt-4o-mini | passed | 6 | 0 | 0 | 20.69% | 16.30% | 130 | 24 | 8 | 98 | 18.46% |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 20 | 3 | 0 | 85.71% | 82.61% | 130 | 101 | 9 | 20 | 77.69% |
| deepseek-v4-flash | passed | 93 | 0 | 0 | 91.13% | 98.91% | 130 | 114 | 7 | 9 | 87.69% |
| gemini-3-flash-preview | passed | 19 | 0 | 0 | 81.77% | 69.57% | 130 | 94 | 14 | 22 | 72.31% |
| gpt-4o-mini | passed | 6 | 0 | 0 | 20.69% | 16.30% | 130 | 24 | 8 | 98 | 18.46% |

## Mutant Set Consistency
- Comparable PIT suites: `7`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `130`
- Union mutant IDs: `130`
- `_final_selected/deepseek-v4-flash` mutant IDs: `130`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `130`
- `_final_selected/gpt-4o-mini` mutant IDs: `130`
- `_final_selected/gpt-5.4-mini` mutant IDs: `130`
- `_initial_snapshot/deepseek-v4-flash` mutant IDs: `130`
- `_initial_snapshot/gemini-3-flash-preview` mutant IDs: `130`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `130`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `repair_not_needed`: The initial generated test suite already passed verification, so no repair attempt was needed.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.