package com.bookstore;

public class OrderFormatter {

    public String formatOrderSummary(Order order, int totalCostCents, Customer customer) {
        if (order == null || customer == null) throw new IllegalArgumentException("Arguments cannot be null");
        StringBuilder sb = new StringBuilder();
        sb.append("Order ID: ").append(order.getId()).append("\n");
        sb.append("Customer: ").append(customer.getName()).append("\n");
        sb.append("Items:\n");
        for (OrderItem item : order.getItems()) {
            sb.append("  Book ID ").append(item.getBookId())
              .append(" x ").append(item.getQuantity()).append("\n");
        }
        sb.append("Total Cost: $").append(String.format("%.2f", totalCostCents / 100.0)).append("\n");
        sb.append("Status: ").append(order.getStatus());
        return sb.toString();
    }
}