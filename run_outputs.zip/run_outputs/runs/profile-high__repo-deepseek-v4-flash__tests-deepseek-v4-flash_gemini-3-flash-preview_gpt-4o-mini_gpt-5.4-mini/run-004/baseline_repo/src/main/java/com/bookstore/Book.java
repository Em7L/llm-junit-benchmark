package com.bookstore;

public class Book {
    private final int id;
    private final String title;
    private final int priceInCents;
    private int stockCount;

    public Book(int id, String title, int priceInCents, int stockCount) {
        if (id <= 0) throw new IllegalArgumentException("Book ID must be positive");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Title cannot be blank");
        if (priceInCents <= 0) throw new IllegalArgumentException("Price must be positive");
        if (stockCount < 0) throw new IllegalArgumentException("Stock cannot be negative");
        this.id = id;
        this.title = title;
        this.priceInCents = priceInCents;
        this.stockCount = stockCount;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public int getPriceInCents() { return priceInCents; }
    public int getStockCount() { return stockCount; }

    public boolean restock(int quantity) {
        if (quantity <= 0) return false;
        stockCount += quantity;
        return true;
    }

    public boolean allocateStock(int quantity) {
        if (quantity <= 0 || quantity > stockCount) return false;
        stockCount -= quantity;
        return true;
    }
}