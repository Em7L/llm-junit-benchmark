package com.bookstore;

import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private final Map<Integer, Book> books = new HashMap<>();

    public void addBook(Book book) {
        if (book == null) throw new IllegalArgumentException("Book cannot be null");
        books.put(book.getId(), book);
    }

    public Book getBook(int bookId) {
        return books.get(bookId);
    }

    public boolean checkStock(int bookId, int quantity) {
        if (quantity <= 0) return false;
        Book book = books.get(bookId);
        return book != null && book.getStockCount() >= quantity;
    }

    public boolean allocateStock(int bookId, int quantity) {
        if (quantity <= 0) return false;
        Book book = books.get(bookId);
        if (book == null) return false;
        return book.allocateStock(quantity);
    }

    public void restock(int bookId, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        Book book = books.get(bookId);
        if (book == null) throw new IllegalArgumentException("Book not found");
        book.restock(quantity);
    }
}