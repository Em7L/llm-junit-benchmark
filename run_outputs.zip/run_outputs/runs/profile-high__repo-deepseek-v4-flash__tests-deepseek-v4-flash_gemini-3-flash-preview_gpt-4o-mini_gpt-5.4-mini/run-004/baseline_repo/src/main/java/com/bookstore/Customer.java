package com.bookstore;

public class Customer {
    private final int id;
    private final String name;
    private final String email;
    private int loyaltyPoints;

    public Customer(int id, String name, String email, int loyaltyPoints) {
        if (id <= 0) throw new IllegalArgumentException("Customer ID must be positive");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name cannot be blank");
        if (email == null || !email.contains("@")) throw new IllegalArgumentException("Invalid email");
        if (loyaltyPoints < 0) throw new IllegalArgumentException("Loyalty points cannot be negative");
        this.id = id;
        this.name = name;
        this.email = email;
        this.loyaltyPoints = loyaltyPoints;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public int getLoyaltyPoints() { return loyaltyPoints; }

    public void addPoints(int points) {
        if (points <= 0) throw new IllegalArgumentException("Points to add must be positive");
        loyaltyPoints += points;
    }

    public boolean deductPoints(int points) {
        if (points <= 0 || points > loyaltyPoints) return false;
        loyaltyPoints -= points;
        return true;
    }

    public String getStatus() {
        if (loyaltyPoints >= 1000) return "Gold";
        else if (loyaltyPoints >= 500) return "Silver";
        else if (loyaltyPoints >= 100) return "Bronze";
        else return "Regular";
    }
}