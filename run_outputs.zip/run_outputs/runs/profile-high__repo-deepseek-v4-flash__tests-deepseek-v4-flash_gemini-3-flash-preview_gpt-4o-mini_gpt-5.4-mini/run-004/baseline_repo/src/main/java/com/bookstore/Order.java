package com.bookstore;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private final int id;
    private final int customerId;
    private final List<OrderItem> items;
    private String status;

    public Order(int id, int customerId) {
        if (id <= 0) throw new IllegalArgumentException("Order ID must be positive");
        if (customerId <= 0) throw new IllegalArgumentException("Customer ID must be positive");
        this.id = id;
        this.customerId = customerId;
        this.items = new ArrayList<>();
        this.status = "PENDING";
    }

    public int getId() { return id; }
    public int getCustomerId() { return customerId; }
    public List<OrderItem> getItems() { return items; }
    public String getStatus() { return status; }

    public void setStatus(String status) {
        if (status == null || (!status.equals("PENDING") && !status.equals("PROCESSED") && !status.equals("FAILED")))
            throw new IllegalArgumentException("Invalid status");
        this.status = status;
    }

    public void addItem(OrderItem item) {
        if (item == null) throw new IllegalArgumentException("Item cannot be null");
        items.add(item);
    }

    public int getItemCount() { return items.size(); }
}