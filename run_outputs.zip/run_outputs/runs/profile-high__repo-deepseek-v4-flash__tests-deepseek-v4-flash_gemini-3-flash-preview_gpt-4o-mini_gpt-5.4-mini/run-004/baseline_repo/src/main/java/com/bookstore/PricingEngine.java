package com.bookstore;

public class PricingEngine {

    public int calculateOrderTotal(Order order, Customer customer, Inventory inventory) {
        if (order == null || customer == null || inventory == null)
            throw new IllegalArgumentException("Arguments cannot be null");
        int subtotal = 0;
        for (OrderItem item : order.getItems()) {
            Book book = inventory.getBook(item.getBookId());
            if (book == null) throw new IllegalArgumentException("Book not found: " + item.getBookId());
            subtotal += book.getPriceInCents() * item.getQuantity();
        }
        int itemCount = order.getItemCount();
        return applyDiscounts(subtotal, customer, itemCount);
    }

    private int applyDiscounts(int subtotal, Customer customer, int itemCount) {
        if (subtotal <= 0) return 0;
        int discountPercent = 0;
        String status = customer.getStatus();
        switch (status) {
            case "Gold":
                discountPercent = 20;
                break;
            case "Silver":
                discountPercent = 10;
                break;
            case "Bronze":
                discountPercent = 5;
                break;
            default:
                discountPercent = 0;
        }
        if (itemCount >= 10) {
            discountPercent += 5;
        }
        if (discountPercent > 50) {
            discountPercent = 50;
        }
        int total = (subtotal * (100 - discountPercent)) / 100;
        return total;
    }
}