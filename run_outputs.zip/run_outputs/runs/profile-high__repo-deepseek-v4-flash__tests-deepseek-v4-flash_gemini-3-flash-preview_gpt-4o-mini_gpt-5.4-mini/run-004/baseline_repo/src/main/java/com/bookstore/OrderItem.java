package com.bookstore;

public class OrderItem {
    private final int bookId;
    private int quantity;

    public OrderItem(int bookId, int quantity) {
        if (bookId <= 0) throw new IllegalArgumentException("Book ID must be positive");
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        this.bookId = bookId;
        this.quantity = quantity;
    }

    public int getBookId() { return bookId; }
    public int getQuantity() { return quantity; }

    public void setQuantity(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        this.quantity = quantity;
    }
}