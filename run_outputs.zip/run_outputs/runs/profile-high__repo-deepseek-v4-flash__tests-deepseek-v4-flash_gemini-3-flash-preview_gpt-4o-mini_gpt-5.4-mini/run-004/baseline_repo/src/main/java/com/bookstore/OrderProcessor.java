package com.bookstore;

public class OrderProcessor {
    private int processedCount = 0;

    public Order processOrder(Order order, Customer customer, Inventory inventory,
                              PricingEngine pricingEngine, OrderValidator validator,
                              OrderFormatter formatter) {
        if (order == null || customer == null || inventory == null ||
            pricingEngine == null || validator == null || formatter == null)
            throw new IllegalArgumentException("Arguments cannot be null");

        // Validate
        var errors = validator.validateOrder(order, customer, inventory);
        if (!errors.isEmpty()) {
            order.setStatus("FAILED");
            return order;
        }

        // Calculate total
        int totalCents = pricingEngine.calculateOrderTotal(order, customer, inventory);

        // Allocate stock
        for (OrderItem item : order.getItems()) {
            if (!inventory.allocateStock(item.getBookId(), item.getQuantity())) {
                order.setStatus("FAILED");
                return order;
            }
        }

        // Update customer loyalty points (1 point per $10 spent)
        customer.addPoints(totalCents / 1000);

        // Generate summary and set status
        processedCount++;
        String summary = formatter.formatOrderSummary(order, totalCents, customer);
        if (processedCount > 5) {
            summary += "\nBulk discount applied as a loyal customer.";
        }
        order.setStatus("PROCESSED");
        return order;
    }

    public int getProcessedCount() { return processedCount; }
}