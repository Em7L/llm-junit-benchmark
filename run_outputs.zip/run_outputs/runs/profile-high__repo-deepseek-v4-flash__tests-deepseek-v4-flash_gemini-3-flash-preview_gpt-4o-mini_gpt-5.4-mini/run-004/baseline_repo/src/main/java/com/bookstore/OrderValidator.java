package com.bookstore;

import java.util.ArrayList;
import java.util.List;

public class OrderValidator {

    public List<String> validateOrder(Order order, Customer customer, Inventory inventory) {
        List<String> errors = new ArrayList<>();
        if (order == null) {
            errors.add("Order is null");
            return errors;
        }
        if (customer == null) {
            errors.add("Customer is null");
        }
        if (inventory == null) {
            errors.add("Inventory is null");
        }
        List<OrderItem> items = order.getItems();
        if (items == null || items.isEmpty()) {
            errors.add("Order has no items");
            return errors;
        }
        for (OrderItem item : items) {
            if (item.getQuantity() <= 0) {
                errors.add("Item quantity must be positive for book ID: " + item.getBookId());
                continue;
            }
            if (inventory != null) {
                Book book = inventory.getBook(item.getBookId());
                if (book == null) {
                    errors.add("Book not found: " + item.getBookId());
                } else if (!inventory.checkStock(item.getBookId(), item.getQuantity())) {
                    errors.add("Insufficient stock for book ID: " + item.getBookId());
                }
            }
        }
        return errors;
    }
}