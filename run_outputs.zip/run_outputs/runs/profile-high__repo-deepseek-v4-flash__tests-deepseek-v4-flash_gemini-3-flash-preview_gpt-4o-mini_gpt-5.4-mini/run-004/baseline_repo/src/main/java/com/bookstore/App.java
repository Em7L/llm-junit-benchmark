package com.bookstore;

public class App {
    public static void main(String[] args) {
        // Set up inventory
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "Java Basics", 2000, 10));
        inventory.addBook(new Book(2, "Advanced Java", 3500, 5));
        inventory.addBook(new Book(3, "Design Patterns", 4500, 2));

        // Create customer
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);

        // Create order
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));
        order.addItem(new OrderItem(3, 1));

        // Process order
        PricingEngine pricing = new PricingEngine();
        OrderValidator validator = new OrderValidator();
        OrderFormatter formatter = new OrderFormatter();
        OrderProcessor processor = new OrderProcessor();

        Order result = processor.processOrder(order, customer, inventory, pricing, validator, formatter);
        System.out.println("Order status: " + result.getStatus());
    }
}