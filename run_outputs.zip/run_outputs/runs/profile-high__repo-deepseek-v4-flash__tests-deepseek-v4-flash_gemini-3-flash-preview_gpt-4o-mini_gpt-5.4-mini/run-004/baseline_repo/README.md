# Bookstore Order Processing System

A high-complexity Java application demonstrating order processing logic for a bookstore. It includes inventory management, pricing with discounts, order validation, and formatting, all orchestrated by an OrderProcessor.

## How to Run

```
mvn compile
mvn exec:java
```

## How to Test

```
mvn test
```
(JaCoCo coverage report generated in target/site/jacoco/index.xml)

## Complexity Summary

- Number of classes: 9
- Total public methods: 27
- Methods with >= 3 branches: 5 (Customer.getStatus, PricingEngine.applyDiscounts, OrderValidator.validateOrder, OrderProcessor.processOrder, Inventory.checkStock)
- Class descriptions:
  - Book: Represents a book with price and stock.
  - Customer: Represents a customer with loyalty points and status.
  - OrderItem: Represents a single item in an order.
  - Order: Represents an order with items and status.
  - Inventory: Manages book stock.
  - PricingEngine: Calculates total with discounts (volume + loyalty).
  - OrderValidator: Validates order integrity and stock availability.
  - OrderFormatter: Formats order summary string.
  - OrderProcessor: Orchestrates order processing, updates state.
