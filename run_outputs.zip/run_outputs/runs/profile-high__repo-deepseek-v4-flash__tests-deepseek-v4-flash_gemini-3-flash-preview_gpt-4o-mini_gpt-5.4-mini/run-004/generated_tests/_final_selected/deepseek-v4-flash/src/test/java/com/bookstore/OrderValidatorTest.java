package com.bookstore;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class OrderValidatorTest {
    private OrderValidator validator;
    private Inventory inventory;
    private Customer customer;

    @BeforeEach
    void setUp() {
        validator = new OrderValidator();
        inventory = new Inventory();
        inventory.addBook(new Book(1, "B1", 1000, 10));
        inventory.addBook(new Book(2, "B2", 2000, 5));
        customer = new Customer(1, "Alice", "a@b.com", 100);
    }

    @Test
    void validOrderReturnsEmptyErrors() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));
        List<String> errors = validator.validateOrder(order, customer, inventory);
        assertTrue(errors.isEmpty());
    }

    @Test
    void nullOrder() {
        List<String> errors = validator.validateOrder(null, customer, inventory);
        assertEquals(1, errors.size());
        assertEquals("Order is null", errors.get(0));
    }

    @Test
    void nullCustomer() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 1));
        List<String> errors = validator.validateOrder(order, null, inventory);
        assertTrue(errors.contains("Customer is null"));
    }

    @Test
    void nullInventory() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 1));
        List<String> errors = validator.validateOrder(order, customer, null);
        assertTrue(errors.contains("Inventory is null"));
    }

    @Test
    void orderWithNoItems() {
        Order order = new Order(1, 1);
        List<String> errors = validator.validateOrder(order, customer, inventory);
        assertEquals(1, errors.size());
        assertEquals("Order has no items", errors.get(0));
    }

    @Test
    void nonExistingBook() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(99, 1));
        List<String> errors = validator.validateOrder(order, customer, inventory);
        assertTrue(errors.contains("Book not found: 99"));
    }

    @Test
    void insufficientStock() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 11)); // stock is 10
        List<String> errors = validator.validateOrder(order, customer, inventory);
        assertTrue(errors.contains("Insufficient stock for book ID: 1"));
    }

    @Test
    void multipleErrors() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(99, 1)); // no book
        order.addItem(new OrderItem(2, 10)); // stock is 5
        List<String> errors = validator.validateOrder(order, customer, inventory);
        assertEquals(2, errors.size());
        assertTrue(errors.contains("Book not found: 99"));
        assertTrue(errors.contains("Insufficient stock for book ID: 2"));
    }
}
