package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorValid() {
        Customer c = new Customer(1, "Alice", "alice@example.com", 500);
        assertEquals(1, c.getId());
        assertEquals("Alice", c.getName());
        assertEquals("alice@example.com", c.getEmail());
        assertEquals(500, c.getLoyaltyPoints());
    }

    @Test
    void constructorInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(0, "Alice", "alice@test.com", 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer(-1, "Alice", "alice@test.com", 0));
    }

    @Test
    void constructorBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, "", "a@b.com", 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, "   ", "a@b.com", 0));
    }

    @Test
    void constructorInvalidEmail() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, "Alice", "noatsign", 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, "Alice", "", 0));
    }

    @Test
    void constructorNegativePoints() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, "Alice", "a@b.com", -1));
    }

    @Test
    void addPointsPositive() {
        Customer c = new Customer(1, "Alice", "a@b.com", 0);
        c.addPoints(100);
        assertEquals(100, c.getLoyaltyPoints());
    }

    @Test
    void addPointsNonPositive() {
        Customer c = new Customer(1, "Alice", "a@b.com", 0);
        assertThrows(IllegalArgumentException.class, () -> c.addPoints(0));
        assertThrows(IllegalArgumentException.class, () -> c.addPoints(-10));
    }

    @Test
    void deductPointsValid() {
        Customer c = new Customer(1, "Alice", "a@b.com", 100);
        assertTrue(c.deductPoints(50));
        assertEquals(50, c.getLoyaltyPoints());
    }

    @Test
    void deductPointsExceeding() {
        Customer c = new Customer(1, "Alice", "a@b.com", 100);
        assertFalse(c.deductPoints(101));
        assertEquals(100, c.getLoyaltyPoints());
    }

    @Test
    void deductPointsZeroOrNegative() {
        Customer c = new Customer(1, "Alice", "a@b.com", 100);
        assertFalse(c.deductPoints(0));
        assertFalse(c.deductPoints(-5));
        assertEquals(100, c.getLoyaltyPoints());
    }

    @Test
    void getStatusGold() {
        Customer c = new Customer(1, "Alice", "a@b.com", 1000);
        assertEquals("Gold", c.getStatus());
        Customer c2 = new Customer(2, "Bob", "b@b.com", 1500);
        assertEquals("Gold", c2.getStatus());
    }

    @Test
    void getStatusSilver() {
        Customer c = new Customer(1, "Alice", "a@b.com", 500);
        assertEquals("Silver", c.getStatus());
        Customer c2 = new Customer(2, "Bob", "b@b.com", 999);
        assertEquals("Silver", c2.getStatus());
    }

    @Test
    void getStatusBronze() {
        Customer c = new Customer(1, "Alice", "a@b.com", 100);
        assertEquals("Bronze", c.getStatus());
        Customer c2 = new Customer(2, "Bob", "b@b.com", 499);
        assertEquals("Bronze", c2.getStatus());
    }

    @Test
    void getStatusRegular() {
        Customer c = new Customer(1, "Alice", "a@b.com", 0);
        assertEquals("Regular", c.getStatus());
        Customer c2 = new Customer(2, "Bob", "b@b.com", 99);
        assertEquals("Regular", c2.getStatus());
    }
}