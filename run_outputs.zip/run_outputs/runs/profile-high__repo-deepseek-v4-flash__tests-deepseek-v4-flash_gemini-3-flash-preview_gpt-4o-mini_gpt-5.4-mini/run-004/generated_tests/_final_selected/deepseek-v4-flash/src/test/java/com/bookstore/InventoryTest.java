package com.bookstore;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    private Inventory inventory;
    private Book book;

    @BeforeEach
    void setUp() {
        inventory = new Inventory();
        book = new Book(1, "Test", 1000, 10);
        inventory.addBook(book);
    }

    @Test
    void addBookNull() {
        assertThrows(IllegalArgumentException.class, () -> inventory.addBook(null));
    }

    @Test
    void getBookExisting() {
        assertEquals(book, inventory.getBook(1));
    }

    @Test
    void getBookNonExisting() {
        assertNull(inventory.getBook(99));
    }

    @Test
    void checkStockValid() {
        assertTrue(inventory.checkStock(1, 5));
    }

    @Test
    void checkStockInsufficient() {
        assertFalse(inventory.checkStock(1, 11));
    }

    @Test
    void checkStockNonExistingBook() {
        assertFalse(inventory.checkStock(99, 1));
    }

    @Test
    void checkStockNonPositiveQuantity() {
        assertFalse(inventory.checkStock(1, 0));
        assertFalse(inventory.checkStock(1, -1));
    }

    @Test
    void allocateStockValid() {
        assertTrue(inventory.allocateStock(1, 3));
        assertEquals(7, book.getStockCount());
    }

    @Test
    void allocateStockInsufficient() {
        assertFalse(inventory.allocateStock(1, 11));
        assertEquals(10, book.getStockCount());
    }

    @Test
    void allocateStockNonExisting() {
        assertFalse(inventory.allocateStock(99, 1));
    }

    @Test
    void allocateStockNonPositive() {
        assertFalse(inventory.allocateStock(1, 0));
        assertFalse(inventory.allocateStock(1, -1));
        assertEquals(10, book.getStockCount());
    }

    @Test
    void restockValid() {
        inventory.restock(1, 5);
        assertEquals(15, book.getStockCount());
    }

    @Test
    void restockNonPositiveQuantity() {
        assertThrows(IllegalArgumentException.class, () -> inventory.restock(1, 0));
        assertThrows(IllegalArgumentException.class, () -> inventory.restock(1, -1));
    }

    @Test
    void restockNonExistingBook() {
        assertThrows(IllegalArgumentException.class, () -> inventory.restock(99, 5));
    }
}