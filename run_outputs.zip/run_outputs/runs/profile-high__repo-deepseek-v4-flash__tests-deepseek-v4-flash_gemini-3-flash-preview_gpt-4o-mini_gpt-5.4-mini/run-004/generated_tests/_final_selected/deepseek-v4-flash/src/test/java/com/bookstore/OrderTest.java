package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @Test
    void constructorValid() {
        Order order = new Order(1, 1);
        assertEquals(1, order.getId());
        assertEquals(1, order.getCustomerId());
        assertTrue(order.getItems().isEmpty());
        assertEquals("PENDING", order.getStatus());
        assertEquals(0, order.getItemCount());
    }

    @Test
    void constructorInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Order(0, 1));
        assertThrows(IllegalArgumentException.class, () -> new Order(-1, 1));
    }

    @Test
    void constructorInvalidCustomerId() {
        assertThrows(IllegalArgumentException.class, () -> new Order(1, 0));
        assertThrows(IllegalArgumentException.class, () -> new Order(1, -1));
    }

    @Test
    void setStatusValid() {
        Order order = new Order(1, 1);
        order.setStatus("PROCESSED");
        assertEquals("PROCESSED", order.getStatus());
        order.setStatus("FAILED");
        assertEquals("FAILED", order.getStatus());
        order.setStatus("PENDING");
        assertEquals("PENDING", order.getStatus());
    }

    @Test
    void setStatusInvalid() {
        Order order = new Order(1, 1);
        assertThrows(IllegalArgumentException.class, () -> order.setStatus("INVALID"));
        assertThrows(IllegalArgumentException.class, () -> order.setStatus(null));
    }

    @Test
    void addItemValid() {
        Order order = new Order(1, 1);
        OrderItem item = new OrderItem(1, 2);
        order.addItem(item);
        assertEquals(1, order.getItemCount());
        assertSame(item, order.getItems().get(0));
    }

    @Test
    void addItemNull() {
        Order order = new Order(1, 1);
        assertThrows(IllegalArgumentException.class, () -> order.addItem(null));
    }
}