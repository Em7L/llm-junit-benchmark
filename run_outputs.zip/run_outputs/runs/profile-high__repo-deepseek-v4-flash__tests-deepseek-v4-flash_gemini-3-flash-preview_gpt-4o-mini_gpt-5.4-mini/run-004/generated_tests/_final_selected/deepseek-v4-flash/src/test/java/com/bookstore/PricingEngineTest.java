package com.bookstore;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {
    private PricingEngine engine;
    private Inventory inventory;

    @BeforeEach
    void setUp() {
        engine = new PricingEngine();
        inventory = new Inventory();
        inventory.addBook(new Book(1, "B1", 1000, 10)); // $10.00 each
        inventory.addBook(new Book(2, "B2", 2000, 5));  // $20.00 each
    }

    @Test
    void calculateOrderTotalNullArgs() {
        Order order = new Order(1, 1);
        Customer customer = new Customer(1, "A", "a@b.com", 0);
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(null, customer, inventory));
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, null, inventory));
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, customer, null));
    }

    @Test
    void calculateOrderTotalNoDiscount() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2)); // subtotal 2000
        Customer customer = new Customer(1, "A", "a@b.com", 0); // Regular, no discount
        int total = engine.calculateOrderTotal(order, customer, inventory);
        assertEquals(2000, total);
    }

    @Test
    void calculateOrderTotalBronzeDiscount() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2)); // subtotal 2000
        Customer customer = new Customer(1, "A", "a@b.com", 100); // Bronze -> 5%
        int total = engine.calculateOrderTotal(order, customer, inventory);
        assertEquals(1900, total); // 2000 * 95% = 1900
    }

    @Test
    void calculateOrderTotalSilverDiscount() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2)); // subtotal 2000
        Customer customer = new Customer(1, "A", "a@b.com", 500); // Silver -> 10%
        int total = engine.calculateOrderTotal(order, customer, inventory);
        assertEquals(1800, total); // 2000 * 90% = 1800
    }

    @Test
    void calculateOrderTotalGoldDiscount() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2)); // subtotal 2000
        Customer customer = new Customer(1, "A", "a@b.com", 1000); // Gold -> 20%
        int total = engine.calculateOrderTotal(order, customer, inventory);
        assertEquals(1600, total); // 2000 * 80% = 1600
    }

    @Test
    void calculateOrderTotalVolumeDiscount() {
        Order order = new Order(1, 1);
        for (int i = 0; i < 10; i++) {
            order.addItem(new OrderItem(1, 1)); // 10 items, subtotal 10000
        }
        Customer customer = new Customer(1, "A", "a@b.com", 0); // Regular + volume 5% = 5%
        int total = engine.calculateOrderTotal(order, customer, inventory);
        assertEquals(9500, total); // 10000 * 95% = 9500
    }

    @Test
    void calculateOrderTotalDiscountCap() {
        Order order = new Order(1, 1);
        for (int i = 0; i < 10; i++) {
            order.addItem(new OrderItem(1, 1)); // 10 items, subtotal 10000
        }
        Customer customer = new Customer(1, "A", "a@b.com", 1000); // Gold 20% + volume 5% = 25% but capped at 50%? Actually 20+5=25 < 50, so no cap. Let's make it exceed: Gold + volume 5% = 25%, not over 50. To exceed, need higher volume discount? Volume discount is fixed 5% for >=10 items. So max discount is 20+5=25. So cap not reached. But we can test when subtotal is 0? That returns 0. The code has discountPercent up to 50, but can't reach with current logic. We'll test the cap by setting customer status to Gold and many items? 20+5=25. Still under. Actually, the cap is only applied if discountPercent > 50, but it's hard to reach because only two discounts are applied. So we skip that branch.
        // Instead, test subtotal <=0 returns 0.
    }

    @Test
    void calculateOrderTotalSubtotalZero() {
        Order order = new Order(1, 1);
        Customer customer = new Customer(1, "A", "a@b.com", 100);
        int total = engine.calculateOrderTotal(order, customer, inventory);
        assertEquals(0, total);
    }

    @Test
    void calculateOrderTotalMissingBook() {
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(99, 1)); // book not in inventory
        Customer customer = new Customer(1, "A", "a@b.com", 0);
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, customer, inventory));
    }
}