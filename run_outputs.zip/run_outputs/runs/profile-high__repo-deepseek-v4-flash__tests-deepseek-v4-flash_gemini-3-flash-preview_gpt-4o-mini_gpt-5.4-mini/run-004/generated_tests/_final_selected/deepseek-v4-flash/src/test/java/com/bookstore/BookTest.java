package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    @Test
    void constructorValid() {
        Book book = new Book(1, "Title", 1000, 5);
        assertEquals(1, book.getId());
        assertEquals("Title", book.getTitle());
        assertEquals(1000, book.getPriceInCents());
        assertEquals(5, book.getStockCount());
    }

    @Test
    void constructorInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Book(0, "Title", 1000, 5));
        assertThrows(IllegalArgumentException.class, () -> new Book(-1, "Title", 1000, 5));
    }

    @Test
    void constructorBlankTitle() {
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "", 1000, 5));
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "   ", 1000, 5));
    }

    @Test
    void constructorNonPositivePrice() {
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", 0, 5));
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", -100, 5));
    }

    @Test
    void constructorNegativeStock() {
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", 1000, -1));
    }

    @Test
    void restockPositive() {
        Book book = new Book(1, "Title", 1000, 5);
        assertTrue(book.restock(3));
        assertEquals(8, book.getStockCount());
    }

    @Test
    void restockZeroOrNegative() {
        Book book = new Book(1, "Title", 1000, 5);
        assertFalse(book.restock(0));
        assertFalse(book.restock(-1));
        assertEquals(5, book.getStockCount());
    }

    @Test
    void allocateStockValid() {
        Book book = new Book(1, "Title", 1000, 5);
        assertTrue(book.allocateStock(3));
        assertEquals(2, book.getStockCount());
    }

    @Test
    void allocateStockExceeding() {
        Book book = new Book(1, "Title", 1000, 5);
        assertFalse(book.allocateStock(6));
        assertEquals(5, book.getStockCount());
    }

    @Test
    void allocateStockZeroOrNegative() {
        Book book = new Book(1, "Title", 1000, 5);
        assertFalse(book.allocateStock(0));
        assertFalse(book.allocateStock(-1));
        assertEquals(5, book.getStockCount());
    }
}