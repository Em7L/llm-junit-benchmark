package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderItemTest {

    @Test
    void constructorValid() {
        OrderItem item = new OrderItem(1, 2);
        assertEquals(1, item.getBookId());
        assertEquals(2, item.getQuantity());
    }

    @Test
    void constructorInvalidBookId() {
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(0, 1));
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(-1, 1));
    }

    @Test
    void constructorInvalidQuantity() {
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(1, 0));
        assertThrows(IllegalArgumentException.class, () -> new OrderItem(1, -1));
    }

    @Test
    void setQuantityValid() {
        OrderItem item = new OrderItem(1, 2);
        item.setQuantity(5);
        assertEquals(5, item.getQuantity());
    }

    @Test
    void setQuantityInvalid() {
        OrderItem item = new OrderItem(1, 2);
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(-1));
    }
}