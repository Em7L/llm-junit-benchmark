package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderProcessorTest {

    @Test
    void processOrderRejectsNullArguments() {
        OrderProcessor processor = new OrderProcessor();
        Order order = new Order(1, 1);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);
        Inventory inventory = new Inventory();
        PricingEngine pricingEngine = new PricingEngine();
        OrderValidator validator = new OrderValidator();
        OrderFormatter formatter = new OrderFormatter();

        assertThrows(IllegalArgumentException.class, () -> processor.processOrder(null, customer, inventory, pricingEngine, validator, formatter));
        assertThrows(IllegalArgumentException.class, () -> processor.processOrder(order, null, inventory, pricingEngine, validator, formatter));
        assertThrows(IllegalArgumentException.class, () -> processor.processOrder(order, customer, null, pricingEngine, validator, formatter));
        assertThrows(IllegalArgumentException.class, () -> processor.processOrder(order, customer, inventory, null, validator, formatter));
        assertThrows(IllegalArgumentException.class, () -> processor.processOrder(order, customer, inventory, pricingEngine, null, formatter));
        assertThrows(IllegalArgumentException.class, () -> processor.processOrder(order, customer, inventory, pricingEngine, validator, null));
    }

    @Test
    void processOrderMarksFailedWhenValidationFails() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "Java Basics", 1000, 1));
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));

        OrderProcessor processor = new OrderProcessor();
        Order result = processor.processOrder(order, customer, inventory, new PricingEngine(), new OrderValidator(), new OrderFormatter());

        assertSame(order, result);
        assertEquals("FAILED", result.getStatus());
        assertEquals(0, processor.getProcessedCount());
        assertEquals(1, inventory.getBook(1).getStockCount());
        assertEquals(0, customer.getLoyaltyPoints());
    }

    @Test
    void processOrderAllocatesStockUpdatesPointsAndMarksProcessed() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "Java Basics", 1000, 10));
        inventory.addBook(new Book(2, "Advanced Java", 2000, 10));

        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));
        order.addItem(new OrderItem(2, 1));

        OrderProcessor processor = new OrderProcessor();
        Order result = processor.processOrder(order, customer, inventory, new PricingEngine(), new OrderValidator(), new OrderFormatter());

        assertSame(order, result);
        assertEquals("PROCESSED", result.getStatus());
        assertEquals(8, inventory.getBook(1).getStockCount());
        assertEquals(9, inventory.getBook(2).getStockCount());
        assertEquals(503, customer.getLoyaltyPoints());
        assertEquals(1, processor.getProcessedCount());
    }

    @Test
    void processedCountIncrementsAcrossMultipleOrders() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "Book", 1000, 100));
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);
        OrderProcessor processor = new OrderProcessor();

        for (int i = 0; i < 6; i++) {
            Order order = new Order(i + 1, 1);
            order.addItem(new OrderItem(1, 1));
            processor.processOrder(order, customer, inventory, new PricingEngine(), new OrderValidator(), new OrderFormatter());
            assertEquals("PROCESSED", order.getStatus());
        }

        assertEquals(6, processor.getProcessedCount());
        assertEquals(94, inventory.getBook(1).getStockCount());
        assertEquals(6, customer.getLoyaltyPoints());
    }
}
