package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorRejectsInvalidArguments() {
        assertAll(
                () -> assertThrows(IllegalArgumentException.class, () -> new Customer(0, "Name", "a@b.com", 0)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Customer(1, null, "a@b.com", 0)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Customer(1, "  ", "a@b.com", 0)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Customer(1, "Name", null, 0)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Customer(1, "Name", "invalid", 0)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Customer(1, "Name", "a@b.com", -1))
        );
    }

    @Test
    void addAndDeductPointsUpdateBalance() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 10);

        assertThrows(IllegalArgumentException.class, () -> customer.addPoints(0));
        customer.addPoints(40);
        assertEquals(50, customer.getLoyaltyPoints());

        assertFalse(customer.deductPoints(0));
        assertFalse(customer.deductPoints(60));
        assertEquals(50, customer.getLoyaltyPoints());

        assertTrue(customer.deductPoints(20));
        assertEquals(30, customer.getLoyaltyPoints());
    }

    @Test
    void getStatusUsesExpectedThresholds() {
        assertEquals("Regular", new Customer(1, "R", "r@example.com", 99).getStatus());
        assertEquals("Bronze", new Customer(1, "B", "b@example.com", 100).getStatus());
        assertEquals("Silver", new Customer(1, "S", "s@example.com", 500).getStatus());
        assertEquals("Gold", new Customer(1, "G", "g@example.com", 1000).getStatus());
    }
}
