package com.bookstore;

import org.junit.jupiter.api.Test;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;

class OrderFormatterTest {

    @Test
    void formatOrderSummaryProducesReadableMultilineOutput() {
        Order order = new Order(5, 9);
        order.addItem(new OrderItem(1, 2));
        order.addItem(new OrderItem(7, 1));
        order.setStatus("PROCESSED");
        Customer customer = new Customer(9, "Alice", "alice@example.com", 100);

        String summary = new OrderFormatter().formatOrderSummary(order, 1234, customer);

        String expectedTotal = String.format(Locale.getDefault(), "%.2f", 1234 / 100.0);
        assertAll(
                () -> assertTrue(summary.contains("Order ID: 5")),
                () -> assertTrue(summary.contains("Customer: Alice")),
                () -> assertTrue(summary.contains("Items:")),
                () -> assertTrue(summary.contains("Book ID 1 x 2")),
                () -> assertTrue(summary.contains("Book ID 7 x 1")),
                () -> assertTrue(summary.contains("Total Cost: $" + expectedTotal)),
                () -> assertTrue(summary.contains("Status: PROCESSED"))
        );
    }

    @Test
    void formatOrderSummaryRejectsNullArguments() {
        OrderFormatter formatter = new OrderFormatter();
        Order order = new Order(1, 1);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);

        assertThrows(IllegalArgumentException.class, () -> formatter.formatOrderSummary(null, 100, customer));
        assertThrows(IllegalArgumentException.class, () -> formatter.formatOrderSummary(order, 100, null));
    }
}
