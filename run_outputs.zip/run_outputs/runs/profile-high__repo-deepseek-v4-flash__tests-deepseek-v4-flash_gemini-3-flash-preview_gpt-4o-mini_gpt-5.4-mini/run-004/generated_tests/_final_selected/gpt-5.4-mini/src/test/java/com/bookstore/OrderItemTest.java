package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderItemTest {

    @Test
    void constructorAndSetterValidatePositiveValues() {
        assertAll(
                () -> assertThrows(IllegalArgumentException.class, () -> new OrderItem(0, 1)),
                () -> assertThrows(IllegalArgumentException.class, () -> new OrderItem(1, 0))
        );

        OrderItem item = new OrderItem(3, 2);
        assertEquals(3, item.getBookId());
        assertEquals(2, item.getQuantity());

        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        item.setQuantity(5);
        assertEquals(5, item.getQuantity());
    }
}
