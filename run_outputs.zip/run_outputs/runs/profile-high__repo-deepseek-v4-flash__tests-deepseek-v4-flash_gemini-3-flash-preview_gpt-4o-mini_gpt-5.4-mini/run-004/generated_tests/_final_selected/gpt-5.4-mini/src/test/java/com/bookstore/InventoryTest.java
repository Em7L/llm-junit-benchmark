package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {

    @Test
    void addBookAndGetBookWorkTogether() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Title", 1000, 3);

        assertThrows(IllegalArgumentException.class, () -> inventory.addBook(null));
        inventory.addBook(book);

        assertSame(book, inventory.getBook(1));
        assertNull(inventory.getBook(999));
    }

    @Test
    void checkStockHandlesMissingBooksAndInvalidQuantities() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "Title", 1000, 3));

        assertFalse(inventory.checkStock(1, 0));
        assertFalse(inventory.checkStock(2, 1));
        assertTrue(inventory.checkStock(1, 3));
        assertFalse(inventory.checkStock(1, 4));
    }

    @Test
    void allocateStockAndRestockUpdateUnderlyingBook() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Title", 1000, 3);
        inventory.addBook(book);

        assertFalse(inventory.allocateStock(1, 0));
        assertFalse(inventory.allocateStock(2, 1));
        assertFalse(inventory.allocateStock(1, 4));
        assertEquals(3, book.getStockCount());

        assertTrue(inventory.allocateStock(1, 2));
        assertEquals(1, book.getStockCount());

        assertThrows(IllegalArgumentException.class, () -> inventory.restock(1, 0));
        assertThrows(IllegalArgumentException.class, () -> inventory.restock(2, 1));

        inventory.restock(1, 5);
        assertEquals(6, book.getStockCount());
    }
}
