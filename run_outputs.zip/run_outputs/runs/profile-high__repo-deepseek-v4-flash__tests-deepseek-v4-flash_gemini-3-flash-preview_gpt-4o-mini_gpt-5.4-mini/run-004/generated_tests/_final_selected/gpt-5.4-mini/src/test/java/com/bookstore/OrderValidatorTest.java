package com.bookstore;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {

    @Test
    void validateOrderReturnsExpectedErrorsForNullAndEmptyInputs() {
        OrderValidator validator = new OrderValidator();
        Inventory inventory = new Inventory();
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);
        Order order = new Order(1, 1);

        assertEquals(List.of("Order is null"), validator.validateOrder(null, customer, inventory));
        assertEquals(List.of("Order has no items"), validator.validateOrder(order, customer, inventory));

        order.addItem(new OrderItem(1, 1));
        assertEquals(List.of("Inventory is null"), validator.validateOrder(order, customer, null));
    }

    @Test
    void validateOrderDetectsMissingBookAndInsufficientStock() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "Available", 1000, 2));
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);

        Order missingBookOrder = new Order(2, 1);
        missingBookOrder.addItem(new OrderItem(99, 1));
        assertEquals(List.of("Book not found: 99"),
                new OrderValidator().validateOrder(missingBookOrder, customer, inventory));

        Order lowStockOrder = new Order(3, 1);
        lowStockOrder.addItem(new OrderItem(1, 3));
        assertEquals(List.of("Insufficient stock for book ID: 1"),
                new OrderValidator().validateOrder(lowStockOrder, customer, inventory));
    }
}
