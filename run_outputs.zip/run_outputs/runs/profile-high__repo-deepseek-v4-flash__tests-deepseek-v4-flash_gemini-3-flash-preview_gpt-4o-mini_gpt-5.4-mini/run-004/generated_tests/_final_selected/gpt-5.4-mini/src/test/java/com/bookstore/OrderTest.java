package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @Test
    void constructorRejectsInvalidIds() {
        assertAll(
                () -> assertThrows(IllegalArgumentException.class, () -> new Order(0, 1)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Order(1, 0))
        );
    }

    @Test
    void defaultStatusAndItemHandlingAreCorrect() {
        Order order = new Order(10, 20);
        OrderItem item = new OrderItem(1, 2);

        assertEquals("PENDING", order.getStatus());
        assertEquals(0, order.getItemCount());

        assertThrows(IllegalArgumentException.class, () -> order.setStatus("UNKNOWN"));
        order.setStatus("FAILED");
        assertEquals("FAILED", order.getStatus());

        assertThrows(IllegalArgumentException.class, () -> order.addItem(null));
        order.addItem(item);
        assertEquals(1, order.getItemCount());
        assertSame(item, order.getItems().get(0));
    }
}
