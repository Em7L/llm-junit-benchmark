package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    @Test
    void constructorRejectsInvalidArguments() {
        assertAll(
                () -> assertThrows(IllegalArgumentException.class, () -> new Book(0, "Title", 100, 1)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Book(1, null, 100, 1)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Book(1, "   ", 100, 1)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", 0, 1)),
                () -> assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", 100, -1))
        );
    }

    @Test
    void restockUpdatesStockOnlyForPositiveQuantity() {
        Book book = new Book(1, "Title", 100, 2);

        assertFalse(book.restock(0));
        assertEquals(2, book.getStockCount());

        assertTrue(book.restock(3));
        assertEquals(5, book.getStockCount());
    }

    @Test
    void allocateStockRespectsAvailabilityAndQuantity() {
        Book book = new Book(1, "Title", 100, 4);

        assertFalse(book.allocateStock(0));
        assertFalse(book.allocateStock(5));
        assertEquals(4, book.getStockCount());

        assertTrue(book.allocateStock(2));
        assertEquals(2, book.getStockCount());
    }

    @Test
    void gettersReturnConstructorValues() {
        Book book = new Book(7, "Java Basics", 1299, 8);

        assertAll(
                () -> assertEquals(7, book.getId()),
                () -> assertEquals("Java Basics", book.getTitle()),
                () -> assertEquals(1299, book.getPriceInCents()),
                () -> assertEquals(8, book.getStockCount())
        );
    }
}
