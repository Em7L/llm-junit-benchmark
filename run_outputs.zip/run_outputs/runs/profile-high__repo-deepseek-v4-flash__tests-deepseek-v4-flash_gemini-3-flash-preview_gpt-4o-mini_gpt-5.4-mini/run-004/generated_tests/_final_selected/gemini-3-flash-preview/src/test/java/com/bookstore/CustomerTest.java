package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {
    @Test
    void getStatusThresholds() {
        Customer c1 = new Customer(1, "A", "a@b.com", 0);
        assertEquals("Regular", c1.getStatus());
        
        c1.addPoints(100);
        assertEquals("Bronze", c1.getStatus());
        
        c1.addPoints(400);
        assertEquals("Silver", c1.getStatus());
        
        c1.addPoints(500);
        assertEquals("Gold", c1.getStatus());
    }

    @Test
    void deductPointsBehavior() {
        Customer customer = new Customer(1, "A", "a@b.com", 100);
        assertTrue(customer.deductPoints(50));
        assertEquals(50, customer.getLoyaltyPoints());
        assertFalse(customer.deductPoints(51));
        assertFalse(customer.deductPoints(0));
    }

    @Test
    void constructorValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, " ", "a@b.com", 0));
        assertThrows(IllegalArgumentException.class, () -> new Customer(1, "A", "invalid-email", 0));
    }
}