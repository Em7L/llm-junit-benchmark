package com.bookstore;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    private Inventory inventory;

    @BeforeEach
    void setUp() {
        inventory = new Inventory();
    }

    @Test
    void manageBooks() {
        Book book = new Book(1, "Java", 100, 5);
        inventory.addBook(book);
        assertEquals(book, inventory.getBook(1));
        assertTrue(inventory.checkStock(1, 3));
        assertFalse(inventory.checkStock(1, 6));
        assertFalse(inventory.checkStock(2, 1));
    }

    @Test
    void allocationIntegration() {
        inventory.addBook(new Book(1, "Java", 100, 5));
        assertTrue(inventory.allocateStock(1, 5));
        assertFalse(inventory.checkStock(1, 1));
        inventory.restock(1, 10);
        assertEquals(10, inventory.getBook(1).getStockCount());
    }
}