package com.bookstore;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderValidatorTest {
    @Test
    void validateEmptyOrder() {
        OrderValidator validator = new OrderValidator();
        Order order = new Order(1, 1);
        List<String> errors = validator.validateOrder(order, null, null);
        assertTrue(errors.contains("Order has no items"));
    }

    @Test
    void validateStockAvailability() {
        OrderValidator validator = new OrderValidator();
        Inventory inv = new Inventory();
        inv.addBook(new Book(1, "B", 100, 2));
        
        Customer customer = new Customer(1, "C", "c@e.com", 0);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 5));

        List<String> errors = validator.validateOrder(order, customer, inv);
        assertTrue(errors.stream().anyMatch(e -> e.contains("Insufficient stock")));
    }
}