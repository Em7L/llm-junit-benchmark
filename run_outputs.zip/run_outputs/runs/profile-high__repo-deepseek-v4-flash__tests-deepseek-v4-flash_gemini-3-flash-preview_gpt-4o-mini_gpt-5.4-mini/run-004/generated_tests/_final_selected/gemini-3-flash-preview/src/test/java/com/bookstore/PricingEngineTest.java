package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {
    @Test
    void calculateTotalWithDiscounts() {
        PricingEngine engine = new PricingEngine();
        Inventory inv = new Inventory();
        inv.addBook(new Book(1, "Book", 1000, 100));
        
        Customer regular = new Customer(1, "R", "r@e.com", 0);
        Customer gold = new Customer(2, "G", "g@e.com", 1000);
        
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));

        // Regular: no discount. 1000 * 2 = 2000
        assertEquals(2000, engine.calculateOrderTotal(order, regular, inv));
        
        // Gold: 20% discount. 2000 * 0.8 = 1600
        assertEquals(1600, engine.calculateOrderTotal(order, gold, inv));
    }

    @Test
    void bulkDiscountIntegration() {
        PricingEngine engine = new PricingEngine();
        Inventory inv = new Inventory();
        inv.addBook(new Book(1, "Book", 100, 100));
        Customer regular = new Customer(1, "R", "r@e.com", 0);
        
        Order order = new Order(1, 1);
        for(int i = 0; i < 10; i++) order.addItem(new OrderItem(1, 1));

        // Regular + 10 items (5% bulk discount). 1000 * 0.95 = 950
        assertEquals(950, engine.calculateOrderTotal(order, regular, inv));
    }
}