package com.bookstore;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

class BookTest {
    @Test
    void constructorThrowsOnInvalidInput() {
        assertThrows(IllegalArgumentException.class, () -> new Book(-1, "Title", 100, 1));
        assertThrows(IllegalArgumentException.class, () -> new Book(1, " ", 100, 1));
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", 0, 1));
        assertThrows(IllegalArgumentException.class, () -> new Book(1, "Title", 100, -1));
    }

    @Test
    void restockUpdatesCount() {
      Book book = new Book(1, "Title", 100, 10);
      assertTrue(book.restock(5));
      assertEquals(15, book.getStockCount());
      assertFalse(book.restock(0));
      assertFalse(book.restock(-5));
    }

    @Test
    void allocateStockReducesCount() {
      Book book = new Book(1, "Title", 100, 10);
      assertTrue(book.allocateStock(4));
      assertEquals(6, book.getStockCount());
      assertFalse(book.allocateStock(11));
      assertFalse(book.allocateStock(0));
      assertEquals(6, book.getStockCount());
    }
}