package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderItemTest {
    @Test
    void createOrderItem_success() {
        OrderItem item = new OrderItem(1, 2);
        assertEquals(1, item.getBookId());
        assertEquals(2, item.getQuantity());
    }

    @Test
    void setQuantity_success() {
        OrderItem item = new OrderItem(1, 2);
        item.setQuantity(3);
        assertEquals(3, item.getQuantity());
    }

    @Test
    void setQuantity_throwsOnInvalidValue() {
        OrderItem item = new OrderItem(1, 2);
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(-1));
    }
}