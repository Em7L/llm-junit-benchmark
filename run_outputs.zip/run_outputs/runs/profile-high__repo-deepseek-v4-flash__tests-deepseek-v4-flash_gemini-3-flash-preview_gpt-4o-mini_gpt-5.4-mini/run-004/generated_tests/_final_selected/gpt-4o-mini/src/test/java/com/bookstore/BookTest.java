package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BookTest {
    @Test
    void createsBookSuccessfully() {
        Book book = new Book(1, "Java Basics", 2000, 10);
        assertEquals(1, book.getId());
        assertEquals("Java Basics", book.getTitle());
        assertEquals(2000, book.getPriceInCents());
        assertEquals(10, book.getStockCount());
    }

    @Test
    void allocateStock_decreasesStockSuccessfully() {
        Book book = new Book(1, "Java Basics", 2000, 10);
        assertTrue(book.allocateStock(2));
        assertEquals(8, book.getStockCount());
    }

    @Test
    void allocateStock_failsWhenNotEnoughStock() {
        Book book = new Book(1, "Java Basics", 2000, 1);
        assertFalse(book.allocateStock(2));
        assertEquals(1, book.getStockCount());
    }

    @Test
    void restock_increasesStockSuccessfully() {
        Book book = new Book(1, "Java Basics", 2000, 10);
        assertTrue(book.restock(5));
        assertEquals(15, book.getStockCount());
    }

    @Test
    void restock_failsOnNegativeQuantity() {
        Book book = new Book(1, "Java Basics", 2000, 10);
        assertFalse(book.restock(-5));
        assertEquals(10, book.getStockCount());
    }
}