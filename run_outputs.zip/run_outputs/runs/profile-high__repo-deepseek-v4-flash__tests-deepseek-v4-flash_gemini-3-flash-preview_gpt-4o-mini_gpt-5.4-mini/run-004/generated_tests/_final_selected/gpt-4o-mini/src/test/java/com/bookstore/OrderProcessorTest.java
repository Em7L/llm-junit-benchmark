package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class OrderProcessorTest {
    @Test
    void processOrder_success() {
        Inventory inventory = new Inventory();
        Book book1 = new Book(1, "Java Basics", 2000, 10);
        Book book2 = new Book(2, "Advanced Java", 3500, 5);
        inventory.addBook(book1);
        inventory.addBook(book2);

        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2)); // 2 x Java Basics
        OrderProcessor processor = new OrderProcessor();
        Order result = processor.processOrder(order, customer, inventory, new PricingEngine(), new OrderValidator(), new OrderFormatter());

        assertEquals("PROCESSED", result.getStatus());
        assertEquals(4000, result.getItems().size());
        assertEquals(1, processor.getProcessedCount());
        assertEquals(600, customer.getLoyaltyPoints()); // Points updated
    }

    @Test
    void processOrder_failsOnInsufficientStock() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 0);
        inventory.addBook(book);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 1));

        OrderProcessor processor = new OrderProcessor();
        Order result = processor.processOrder(order, customer, inventory, new PricingEngine(), new OrderValidator(), new OrderFormatter());

        assertEquals("FAILED", result.getStatus());
        assertEquals(0, processor.getProcessedCount());
    }

    @Test
    void processOrder_failsOnValidationErrors() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 0)); // Invalid quantity

        OrderProcessor processor = new OrderProcessor();
        Order result = processor.processOrder(order, customer, inventory, new PricingEngine(), new OrderValidator(), new OrderFormatter());

        assertEquals("FAILED", result.getStatus());
        assertEquals(0, processor.getProcessedCount());
    }
}