package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {
    @Test
    void customerCreation_validInput() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        assertEquals(1, customer.getId());
        assertEquals("Alice", customer.getName());
        assertEquals("alice@example.com", customer.getEmail());
        assertEquals(500, customer.getLoyaltyPoints());
    }

    @Test
    void addPoints_increasesLoyaltyPoints() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        customer.addPoints(200);
        assertEquals(700, customer.getLoyaltyPoints());
    }

    @Test
    void addPoints_failsOnZeroOrNegative() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        assertThrows(IllegalArgumentException.class, () -> customer.addPoints(0));
        assertThrows(IllegalArgumentException.class, () -> customer.addPoints(-100));
    }

    @Test
    void deductPoints_reducesLoyaltyPoints() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        assertTrue(customer.deductPoints(200));
        assertEquals(300, customer.getLoyaltyPoints());
    }

    @Test
    void deductPoints_failsWhenInsufficientPoints() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 100);
        assertFalse(customer.deductPoints(200));
        assertEquals(100, customer.getLoyaltyPoints());
    }

    @Test
    void getStatus_returnsCorrectStatus() {
        Customer customer = new Customer(1, "Alice", "alice@example.com", 1100);
        assertEquals("Gold", customer.getStatus());
        customer.addPoints(500);
        assertEquals("Gold", customer.getStatus()); // Should remain Gold
        customer.deductPoints(600);
        assertEquals("Silver", customer.getStatus());
    }
}