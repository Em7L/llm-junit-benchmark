package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    @Test
    void addBook_success() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        assertEquals(book, inventory.getBook(1));
    }

    @Test
    void checkStock_success() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        assertTrue(inventory.checkStock(1, 5));
    }

    @Test
    void checkStock_insufficientStock() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 3);
        inventory.addBook(book);
        assertFalse(inventory.checkStock(1, 5));
    }

    @Test
    void allocateStock_success() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        assertTrue(inventory.allocateStock(1, 5));
        assertEquals(5, book.getStockCount());
    }

    @Test
    void allocateStock_failsWithInvalidQuantity() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 5);
        inventory.addBook(book);
        assertFalse(inventory.allocateStock(1, 0));
        assertFalse(inventory.allocateStock(1, 6));
        assertEquals(5, book.getStockCount());
    }

    @Test
    void restock_success() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        inventory.restock(1, 5);
        assertEquals(15, book.getStockCount());
    }

    @Test
    void restock_failsOnInvalidBook() {
        Inventory inventory = new Inventory();
        assertThrows(IllegalArgumentException.class, () -> inventory.restock(1, 5));
    }
}