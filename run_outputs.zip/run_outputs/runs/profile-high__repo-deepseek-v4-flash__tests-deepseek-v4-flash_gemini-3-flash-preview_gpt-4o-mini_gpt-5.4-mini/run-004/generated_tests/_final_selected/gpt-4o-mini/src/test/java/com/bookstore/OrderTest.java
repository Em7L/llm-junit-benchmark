package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderTest {
    @Test
    void createsOrderSuccessfully() {
        Order order = new Order(1, 1);
        assertEquals(1, order.getId());
        assertEquals(1, order.getCustomerId());
        assertEquals(0, order.getItemCount());
        assertEquals("PENDING", order.getStatus());
    }

    @Test
    void setStatus_throwsOnInvalidStatus() {
        Order order = new Order(1, 1);
        assertThrows(IllegalArgumentException.class, () -> order.setStatus("INVALID"));
    }

    @Test
    void addItem_success() {
        Order order = new Order(1, 1);
        OrderItem item = new OrderItem(1, 2);
        order.addItem(item);
        assertEquals(1, order.getItemCount());
    }

    @Test
    void addItem_throwsOnNullItem() {
        Order order = new Order(1, 1);
        assertThrows(IllegalArgumentException.class, () -> order.addItem(null));
    }
}