package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class OrderValidatorTest {
    @Test
    void validateOrder_success() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));

        OrderValidator validator = new OrderValidator();
        List<String> errors = validator.validateOrder(order, customer, inventory);

        assertTrue(errors.isEmpty());
    }

    @Test
    void validateOrder_failsOnBookNotFound() {
        Inventory inventory = new Inventory();
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));

        OrderValidator validator = new OrderValidator();
        List<String> errors = validator.validateOrder(order, customer, inventory);

        assertFalse(errors.isEmpty());
        assertTrue(errors.contains("Book not found: 1"));
    }

    @Test
    void validateOrder_failsOnInsufficientStock() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 1);
        inventory.addBook(book);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2)); // Requesting more than available

        OrderValidator validator = new OrderValidator();
        List<String> errors = validator.validateOrder(order, customer, inventory);

        assertFalse(errors.isEmpty());
        assertTrue(errors.contains("Insufficient stock for book ID: 1"));
    }

    @Test
    void validateOrder_failsOnInvalidOrder() {
        Inventory inventory = new Inventory();
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 0)); // Invalid quantity

        OrderValidator validator = new OrderValidator();
        List<String> errors = validator.validateOrder(order, customer, inventory);

        assertFalse(errors.isEmpty());
        assertTrue(errors.contains("Item quantity must be positive for book ID: 1"));
    }
}