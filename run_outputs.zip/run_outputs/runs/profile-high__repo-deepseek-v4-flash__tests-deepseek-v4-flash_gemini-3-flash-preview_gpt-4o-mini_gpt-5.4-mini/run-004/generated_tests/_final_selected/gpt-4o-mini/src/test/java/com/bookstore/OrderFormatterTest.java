package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderFormatterTest {
    @Test
    void formatOrderSummary_success() {
        Inventory inventory = new Inventory();
        Book book = new Book(1, "Java Basics", 2000, 10);
        inventory.addBook(book);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 2));
        OrderFormatter formatter = new OrderFormatter();

        String summary = formatter.formatOrderSummary(order, 4000, customer);
        assertTrue(summary.contains("Order ID: 1"));
        assertTrue(summary.contains("Customer: Alice"));
        assertTrue(summary.contains("Total Cost: $40.00"));
        assertTrue(summary.contains("Status: PENDING"));
    }

    @Test
    void formatOrderSummary_throwsOnNullArguments() {
        OrderFormatter formatter = new OrderFormatter();
        assertThrows(IllegalArgumentException.class, () -> formatter.formatOrderSummary(null, 0, null));
    }
}