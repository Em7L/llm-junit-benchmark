package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AppTest {
    @Test
    void main_executesWithoutException() {
        assertDoesNotThrow(() -> App.main(new String[]{}));
    }
}