package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {
    @Test
    void calculateOrderTotal_success() {
        Inventory inventory = new Inventory();
        Book book1 = new Book(1, "Java Basics", 1000, 1);
        Book book2 = new Book(2, "Advanced Java", 1500, 1);
        inventory.addBook(book1);
        inventory.addBook(book2);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 500);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 1));
        order.addItem(new OrderItem(2, 1));

        PricingEngine pricingEngine = new PricingEngine();
        int total = pricingEngine.calculateOrderTotal(order, customer, inventory);
        assertEquals(2500, total); // no discounts applied
    }

    @Test
    void calculateOrderTotal_appliesDiscounts() {
        Inventory inventory = new Inventory();
        Book book1 = new Book(1, "Java Basics", 1000, 1);
        inventory.addBook(book1);
        Customer customer = new Customer(1, "Alice", "alice@example.com", 1100);
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 1));

        PricingEngine pricingEngine = new PricingEngine();
        int total = pricingEngine.calculateOrderTotal(order, customer, inventory);
        assertEquals(800, total); // 20% discount for Gold status
    }

    @Test
    void applyDiscounts_failsOnInvalidInput() {
        assertThrows(IllegalArgumentException.class, () -> new PricingEngine().applyDiscounts(-100, new Customer(1, "Alice", "alice@example.com", 500), 1));
    }
}