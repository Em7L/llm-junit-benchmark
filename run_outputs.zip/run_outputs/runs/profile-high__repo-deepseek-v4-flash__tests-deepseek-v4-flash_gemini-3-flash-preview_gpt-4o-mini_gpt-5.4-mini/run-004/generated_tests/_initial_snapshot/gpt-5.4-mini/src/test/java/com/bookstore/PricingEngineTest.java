package com.bookstore;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {

    @Test
    void calculateOrderTotalAppliesStatusAndVolumeDiscounts() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "One", 1000, 20));
        inventory.addBook(new Book(2, "Two", 500, 20));

        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 10));
        order.addItem(new OrderItem(2, 1));

        PricingEngine engine = new PricingEngine();
        Customer silverCustomer = new Customer(1, "Sam", "sam@example.com", 500);

        int total = engine.calculateOrderTotal(order, silverCustomer, inventory);
        // subtotal = 10500, Silver 10% + volume 5% = 15% discount => 8925
        assertEquals(8925, total);
    }

    @Test
    void calculateOrderTotalUsesCorrectThresholdsAndRejectsMissingData() {
        Inventory inventory = new Inventory();
        inventory.addBook(new Book(1, "One", 1000, 20));
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(1, 1));

        PricingEngine engine = new PricingEngine();

        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(null, new Customer(1, "A", "a@b.com", 0), inventory));
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, null, inventory));
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, new Customer(1, "A", "a@b.com", 0), null));
        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, new Customer(1, "A", "a@b.com", 0), new Inventory()));

        Customer regular = new Customer(2, "R", "r@example.com", 99);
        Customer bronze = new Customer(3, "B", "b@example.com", 100);
        Customer silver = new Customer(4, "S", "s@example.com", 500);
        Customer gold = new Customer(5, "G", "g@example.com", 1000);

        assertEquals(1000, engine.calculateOrderTotal(order, regular, inventory));
        assertEquals(950, engine.calculateOrderTotal(order, bronze, inventory));
        assertEquals(900, engine.calculateOrderTotal(order, silver, inventory));
        assertEquals(800, engine.calculateOrderTotal(order, gold, inventory));
    }

    @Test
    void calculateOrderTotalThrowsWhenBookMissing() {
        Inventory inventory = new Inventory();
        Order order = new Order(1, 1);
        order.addItem(new OrderItem(99, 1));

        PricingEngine engine = new PricingEngine();
        Customer customer = new Customer(1, "Alice", "alice@example.com", 0);

        assertThrows(IllegalArgumentException.class, () -> engine.calculateOrderTotal(order, customer, inventory));
    }
}
