package com.bookstore;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderFormatterTest {

    @Test
    void formatOrderSummaryValid() {
        Customer customer = new Customer(1, "Alice", "alice@test.com", 500);
        Order order = new Order(123, 1);
        order.addItem(new OrderItem(1, 2));
        order.addItem(new OrderItem(2, 1));
        order.setStatus("PROCESSED");
        OrderFormatter formatter = new OrderFormatter();
        String summary = formatter.formatOrderSummary(order, 5000, customer);
        String expected = "Order ID: 123\n" +
                "Customer: Alice\n" +
                "Items:\n" +
                "  Book ID 1 x 2\n" +
                "  Book ID 2 x 1\n" +
                "Total Cost: $50.00\n" +
                "Status: PROCESSED";
        assertEquals(expected, summary);
    }

    @Test
    void formatOrderSummaryNullOrder() {
        OrderFormatter formatter = new OrderFormatter();
        Customer customer = new Customer(1, "A", "a@b.com", 0);
        assertThrows(IllegalArgumentException.class, () -> formatter.formatOrderSummary(null, 0, customer));
    }

    @Test
    void formatOrderSummaryNullCustomer() {
        OrderFormatter formatter = new OrderFormatter();
        Order order = new Order(1, 1);
        assertThrows(IllegalArgumentException.class, () -> formatter.formatOrderSummary(order, 0, null));
    }

    @Test
    void formatOrderSummaryZeroCost() {
        Customer customer = new Customer(1, "Bob", "b@c.com", 100);
        Order order = new Order(2, 1);
        order.addItem(new OrderItem(1, 1));
        order.setStatus("PENDING");
        OrderFormatter formatter = new OrderFormatter();
        String summary = formatter.formatOrderSummary(order, 0, customer);
        assertTrue(summary.contains("Total Cost: $0.00"));
    }
}