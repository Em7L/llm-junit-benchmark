# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-004/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_successful | 1 |
| deepseek-v4-flash | passed | repair_successful | 1 |
| gemini-3-flash-preview | passed | repair_not_needed | 0 |
| gpt-4o-mini | passed | repair_no_improvement | 1 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 24 | 4 | 1 | 74.11% | 85.21% | 158 | 121 | 13 | 24 | 76.58% |
| deepseek-v4-flash | test_failures | 79 | 2 | 1 | 89.34% | 95.07% | 158 | 140 | 10 | 8 | 88.61% |
| gemini-3-flash-preview | passed | 15 | 0 | 0 | 81.22% | 69.72% | 158 | 115 | 25 | 18 | 72.78% |
| gpt-4o-mini | test_compile_failure | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | passed | 24 | 0 | 0 | 86.80% | 93.66% | 158 | 136 | 10 | 12 | 86.08% |
| deepseek-v4-flash | passed | 78 | 0 | 0 | 89.34% | 95.07% | 158 | 142 | 8 | 8 | 89.87% |
| gemini-3-flash-preview | passed | 15 | 0 | 0 | 81.22% | 69.72% | 158 | 115 | 25 | 18 | 72.78% |
| gpt-4o-mini | test_compile_failure | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |

## Mutant Set Consistency
- Comparable PIT suites: `5`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `158`
- Union mutant IDs: `158`
- `_final_selected/deepseek-v4-flash` mutant IDs: `158`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `158`
- `_final_selected/gpt-5.4-mini` mutant IDs: `158`
- `_initial_snapshot/deepseek-v4-flash` mutant IDs: `158`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `158`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `repair_not_needed`: The initial generated test suite already passed verification, so no repair attempt was needed.
- `repair_no_improvement`: One or more repair attempts were applied, but the final generated test suite did not verify any better than the first verifiable suite.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `maven_status=test_compile_failure`: The generated or existing test sources did not compile during Maven test validation.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.
- `disabling_not_applicable`: Disabling baseline-failing tests was not applicable because evaluation did not reach the stage where named failing tests could be disabled.