package com.rental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class BaseRateCalculatorTest {

    private final BaseRateCalculator calculator = new BaseRateCalculator();

    @Test
    void calculatesBaseRateForEconomyCarUnder3Years() {
        Car car = new Car("Toyota", "Yaris", CarType.ECONOMY, 2021, 25000);
        double rate = calculator.computeBaseRate(car);
        assertEquals(28.0, rate, 0.001);
    }

    @Test
    void calculatesBaseRateForLuxuryCarWithHighMileage() {
        Car car = new Car("Audi", "A6", CarType.LUXURY, 2019, 60000);
        double rate = calculator.computeBaseRate(car);
        assertEquals(86.0, rate, 0.001);
    }

    @Test
    void appliesMileageSurcharge() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2018, 55000);
        double rate = calculator.computeBaseRate(car);
        assertEquals(43.0, rate, 0.001);
    }

    @Test
    void ensuresMinimumBaseRate() {
        Car car = new Car("Chevy", "Spark", CarType.ECONOMY, 2020, 6000);
        double rate = calculator.computeBaseRate(car);
        assertEquals(20.0, rate, 0.001);
    }
}