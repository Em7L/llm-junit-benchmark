package com.rental;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {
    private PricingEngine pricingEngine;
    private BaseRateCalculator baseRateCalc;
    private DiscountCalculator discountCalc;
    private SeasonFactor seasonFactor;
    private InsuranceCalculator insuranceCalc;
    private RentalValidator validator;

    @BeforeEach
    void setUp() {
        baseRateCalc = new BaseRateCalculator();
        discountCalc = new DiscountCalculator();
        seasonFactor = new SeasonFactor();
        insuranceCalc = new InsuranceCalculator();
        validator = new RentalValidator();
        pricingEngine = new PricingEngine(baseRateCalc, discountCalc, seasonFactor, insuranceCalc, validator);
    }

    @Test
    void testComputeTotalPriceForStandardRental() {
        Car car = new Car("Toyota", "Corolla", CarType.COMPACT, 2022, 10000);
        Customer customer = new Customer("John", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 5, 1), LocalDate.of(2024, 5, 4));
        
        double total = pricingEngine.computeTotalPrice(rental);
        // Base: 40 * 0.8 (Compact) * 1.0 (Age) = 32.0. 
        // Season: May 1 is 1.0 multiplier.
        // Duration: 3 days. Subtotal = 32.0 * 3 = 96.0.
        // Discount: 3 days = 0.05. 96.0 * 0.05 = 4.8. After discount = 91.2.
        // Insurance: false = 0.
        assertEquals(91.2, total, 0.001);
    }

    @Test
    void testValidationFailureThrowsException() {
        Car car = new Car("Old", "Banger", CarType.ECONOMY, 2000, 200000);
        Customer customer = new Customer("Young", 18, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 5, 1), LocalDate.of(2024, 5, 2));
        
        assertThrows(IllegalArgumentException.class, () -> pricingEngine.computeTotalPrice(rental));
    }

    @Test
    void testGeneratePriceBreakdownContainsTotal() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2023, 5000);
        Customer customer = new Customer("Alice", 40, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 10, 1), LocalDate.of(2024, 10, 2));
        
        String breakdown = pricingEngine.generatePriceBreakdown(rental);
        assertTrue(breakdown.contains("Total:"));
    }
}