package com.rental;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PricingEngineAndInsuranceTest {

    private PricingEngine createEngine() {
        return new PricingEngine(new BaseRateCalculator(), new DiscountCalculator(), new SeasonFactor(), new InsuranceCalculator(), new RentalValidator());
    }

    @Test
    void computesTotalPriceForValidRentalWithInsuranceAndSeasonalPeak() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 1), LocalDate.of(2024, 7, 5));
        rental.setDriverAge(28);
        rental.setIncludesInsurance(true);

        double total = createEngine().computeTotalPrice(rental);

        assertEquals(144.8, total, 0.0001);
    }

    @Test
    void computesTotalPriceWithoutInsuranceAndWithWinterSeasonFactor() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 12, 20), LocalDate.of(2024, 12, 25));
        rental.setDriverAge(22);
        rental.setIncludesInsurance(false);

        double total = createEngine().computeTotalPrice(rental);

        assertEquals(174.0, total, 0.0001);
    }

    @Test
    void insuranceCalculatorUsesLuxuryAndSubtotalRules() {
        InsuranceCalculator calculator = new InsuranceCalculator();
        Rental luxuryAdult = new Rental(
                new Car("BMW", "7", CarType.LUXURY, 2022, 10000),
                new Customer("Grace", 40, false),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 3)
        );
        luxuryAdult.setDriverAge(30);

        Rental luxuryYoungAdult = new Rental(
                new Car("BMW", "7", CarType.LUXURY, 2022, 10000),
                new Customer("Hank", 22, false),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 3)
        );
        luxuryYoungAdult.setDriverAge(22);

        Rental suvYoung = new Rental(
                new Car("Jeep", "Grand Cherokee", CarType.SUV, 2022, 10000),
                new Customer("Ivy", 23, false),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 3)
        );
        suvYoung.setDriverAge(23);

        assertEquals(30.0 + 25.0, calculator.computeInsuranceCost(luxuryAdult, 250.0), 0.0001);
        assertEquals(50.0, calculator.computeInsuranceCost(luxuryYoungAdult, 150.0), 0.0001);
        assertEquals(40.0, calculator.computeInsuranceCost(suvYoung, 150.0), 0.0001);
    }

    @Test
    void computeTotalPriceRejectsInvalidRental() {
        Rental rental = new Rental(
                new Car("Old", "Beater", CarType.LUXURY, 2000, 90000),
                new Customer("Bob", 20, false),
                LocalDate.of(2024, 7, 10),
                LocalDate.of(2024, 7, 10)
        );
        rental.setDriverAge(20);
        rental.setIncludesInsurance(true);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> createEngine().computeTotalPrice(rental));
        assertEquals("Rental validation failed: Car is too old.; Driver must be at least 21.; Rental duration must be positive.; Luxury cars require driver at least 25.", ex.getMessage());
    }

    @Test
    void generatePriceBreakdownReturnsFormattedTotalString() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 1), LocalDate.of(2024, 7, 5));
        rental.setDriverAge(28);
        rental.setIncludesInsurance(true);

        String breakdown = createEngine().generatePriceBreakdown(rental);

        assertEquals("Total: 144.8", breakdown);
    }

    @Test
    void rentalDurationAndDefaultDriverAgeAreDerivedFromDatesAndCustomer() {
        Customer customer = new Customer("Jane", 34, false);
        Rental rental = new Rental(
                new Car("Honda", "Accord", CarType.FULLSIZE, 2021, 25000),
                customer,
                LocalDate.of(2024, 5, 1),
                LocalDate.of(2024, 5, 6)
        );

        assertEquals(5, rental.getRentalDurationInDays());
        assertEquals(34, rental.getDriverAge());
    }
}