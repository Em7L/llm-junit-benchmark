package com.rental;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DiscountCalculatorTest {

    private final DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void combinesLoyaltyLongRentalAndSeniorDriverDiscounts() {
        Rental rental = new Rental(
                new Car("Toyota", "Camry", CarType.MIDSIZE, 2022, 12000),
                new Customer("Alice", 65, true),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 8)
        );

        double rate = calculator.computeDiscountRate(rental);

        assertEquals(0.15, rate, 0.0001);
    }

    @Test
    void appliesYoungDriverSurchargeAsNegativeDiscount() {
        Rental rental = new Rental(
                new Car("Honda", "Civic", CarType.COMPACT, 2023, 5000),
                new Customer("Bob", 30, false),
                LocalDate.of(2024, 6, 1),
                LocalDate.of(2024, 6, 4)
        );
        rental.setDriverAge(22);

        double rate = calculator.computeDiscountRate(rental);

        assertEquals(-0.2, rate, 0.0001);
    }

    @Test
    void capsDiscountRateAtUpperBoundWhenMultipleDiscountsApply() {
        Rental rental = new Rental(
                new Car("Toyota", "Prius", CarType.COMPACT, 2023, 1000),
                new Customer("Carol", 30, true),
                LocalDate.of(2024, 1, 10),
                LocalDate.of(2024, 1, 20)
        );
        rental.setDriverAge(61);

        double rate = calculator.computeDiscountRate(rental);

        assertEquals(0.25, rate, 0.0001);
    }

    @Test
    void longRentalWithoutOtherConditionsGetsDurationDiscountOnly() {
        Rental rental = new Rental(
                new Car("Nissan", "Altima", CarType.MIDSIZE, 2020, 25000),
                new Customer("Dana", 40, false),
                LocalDate.of(2024, 3, 1),
                LocalDate.of(2024, 3, 4)
        );

        double rate = calculator.computeDiscountRate(rental);

        assertEquals(0.05, rate, 0.0001);
    }
}