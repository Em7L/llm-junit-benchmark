package com.rental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;

class DiscountCalculatorTest {

    private final DiscountCalculator calculator = new DiscountCalculator();

    @Test
    void noDiscountForNonLoyaltyMember() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("John", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(30);
        double discountRate = calculator.computeDiscountRate(rental);
        assertEquals(0.0, discountRate);
    }

    @Test
    void loyaltyDiscountApplied() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2020, 20000);
        Customer customer = new Customer("Jane", 29, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(10));
        rental.setDriverAge(25);
        double discountRate = calculator.computeDiscountRate(rental);
        assertEquals(0.1, discountRate);
    }

    @Test
    void longRentalDiscountApplied() {
        Car car = new Car("Nissan", "Altima", CarType.FULLSIZE, 2019, 15000);
        Customer customer = new Customer("Steve", 45, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(8));
        rental.setDriverAge(40);
        double discountRate = calculator.computeDiscountRate(rental);
        assertEquals(0.25, discountRate, 0.001);
    }

    @Test
    void surchargeForYoungDriverLoyaltyMember() {
        Car car = new Car("Ford", "Focus", CarType.COMPACT, 2020, 25000);
        Customer customer = new Customer("Alice", 22, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(3));
        rental.setDriverAge(22);
        double discountRate = calculator.computeDiscountRate(rental);
        assertEquals(-0.1, discountRate);
    }
}