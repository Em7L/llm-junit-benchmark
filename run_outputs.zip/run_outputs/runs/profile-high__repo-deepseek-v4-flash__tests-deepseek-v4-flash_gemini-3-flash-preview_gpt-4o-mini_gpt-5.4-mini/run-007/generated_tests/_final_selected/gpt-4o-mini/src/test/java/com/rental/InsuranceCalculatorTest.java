package com.rental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class InsuranceCalculatorTest {

    private final InsuranceCalculator calculator = new InsuranceCalculator();

    @Test
    void calculatesInsuranceForLuxuryCarOfAge25AndAbove() {
        Car car = new Car("BMW", "5 Series", CarType.LUXURY, 2021, 10000);
        Rental rental = new Rental(car, new Customer("Bob", 30, true), null, null);
        rental.setDriverAge(30);
        double cost = calculator.computeInsuranceCost(rental, 300.0);
        assertEquals(30.0, cost);
    }

    @Test
    void calculatesInsuranceForSUV() {
        Car car = new Car("Toyota", "RAV4", CarType.SUV, 2020, 15000);
        Rental rental = new Rental(car, new Customer("Charlie", 28, true), null, null);
        rental.setDriverAge(28);
        double cost = calculator.computeInsuranceCost(rental, 300.0);
        assertEquals(20.0, cost);
    }

    @Test
    void calculatesInsuranceCostForYoungDriverWithLuxuryCar() {
        Car car = new Car("Porsche", "911", CarType.LUXURY, 2020, 5000);
        Rental rental = new Rental(car, new Customer("Diana", 22, true), null, null);
        rental.setDriverAge(22);
        double cost = calculator.computeInsuranceCost(rental, 150.0);
        assertEquals(100.0, cost);
    }

    @Test
    void appliesSecurityPackageForEligibleDriver() {
        Car car = new Car("Toyota", "Highlander", CarType.SUV, 2021, 30000);
        Rental rental = new Rental(car, new Customer("Eve", 32, true), null, null);
        rental.setDriverAge(32);
        double cost = calculator.computeInsuranceCost(rental, 250.0);
        assertEquals(25.0, cost);
    }

    @Test
    void capsInsuranceCostAt500() {
        Car car = new Car("Luxury", "Car", CarType.LUXURY, 2021, 10000);
        Rental rental = new Rental(car, new Customer("Frank", 35, true), null, null);
        rental.setDriverAge(35);
        double cost = calculator.computeInsuranceCost(rental, 6000.0);
        assertEquals(500.0, cost);
    }
}