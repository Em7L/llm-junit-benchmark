package com.rental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;

class RentalValidatorTest {

    private final RentalValidator validator = new RentalValidator();

    @Test
    void validatesRentalSuccessfully() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2019, 18000);
        Customer customer = new Customer("Gina", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(28);
        assertTrue(validator.validate(rental).isEmpty());
    }

    @Test
    void failsWhenCarIsTooOld() {
        Car car = new Car("Toyota", "Corolla", CarType.COMPACT, 1999, 150000);
        Customer customer = new Customer("Hank", 40, false);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(30);
        assertFalse(validator.validate(rental).isEmpty());
    }

    @Test
    void failsWhenDriverIsTooYoung() {
        Car car = new Car("Kia", "Soul", CarType.ECONOMY, 2020, 5000);
        Customer customer = new Customer("Ian", 19, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(19);
        assertFalse(validator.validate(rental).isEmpty());
    }

    @Test
    void failsWhenDriverIsTooOld() {
        Car car = new Car("Subaru", "Outback", CarType.MIDSIZE, 2020, 20000);
        Customer customer = new Customer("Julia", 80, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(80);
        assertFalse(validator.validate(rental).isEmpty());
    }

    @Test
    void luxuryCarRequiresOlderDriver() {
        Car car = new Car("Mercedes", "Benz", CarType.LUXURY, 2021, 5000);
        Customer customer = new Customer("Kathy", 26, true);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(20);
        assertFalse(validator.validate(rental).isEmpty());
    }
}