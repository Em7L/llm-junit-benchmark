package com.rental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.List;

class PricingEngineTest {

    private final PricingEngine engine = new PricingEngine(new BaseRateCalculator(), new DiscountCalculator(), new SeasonFactor(), new InsuranceCalculator(), new RentalValidator());

    @Test
    void computesTotalPriceSuccessfully() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 1), LocalDate.of(2024, 7, 5));
        rental.setDriverAge(28);
        rental.setIncludesInsurance(true);
        double total = engine.computeTotalPrice(rental);
        assertTrue(total > 0);
    }

    @Test
    void failsOnInvalidRental() {
        Car car = new Car("Ford", "Focus", CarType.COMPACT, 2019, 15000);
        Customer customer = new Customer("Bob", 19, false);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(5));
        rental.setDriverAge(19);
        assertThrows(IllegalArgumentException.class, () -> engine.computeTotalPrice(rental));
    }

    @Test
    void computesCorrectTotalPriceWithDiscounts() {
        Car car = new Car("Nissan", "Sentra", CarType.FULLSIZE, 2018, 40000);
        Customer customer = new Customer("Lisa", 35, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 12, 20), LocalDate.of(2024, 12, 25));
        rental.setDriverAge(39);
        rental.setIncludesInsurance(false);
        double total = engine.computeTotalPrice(rental);
        assertTrue(total > 0);
    }
}