package com.rental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BaseRateCalculatorTest {
    private final BaseRateCalculator calculator = new BaseRateCalculator();

    @Test
    void testComputeBaseRateByCarType() {
        Car economy = new Car("Make", "Model", CarType.ECONOMY, 2024, 0);
        Car luxury = new Car("Make", "Model", CarType.LUXURY, 2024, 0);
        
        double economyRate = calculator.computeBaseRate(economy);
        double luxuryRate = calculator.computeBaseRate(luxury);
        
        assertTrue(luxuryRate > economyRate);
        assertEquals(28.0, economyRate, 0.001); // 40 * 0.7 * 1.0
        assertEquals(80.0, luxuryRate, 0.001);  // 40 * 2.0 * 1.0
    }

    @Test
    void testAgeFactorBoundaries() {
        int currentYear = java.time.Year.now().getValue();
        Car newCar = new Car("M", "M", CarType.MIDSIZE, currentYear - 2, 0);
        Car midAgeCar = new Car("M", "M", CarType.MIDSIZE, currentYear - 5, 0);
        Car oldCar = new Car("M", "M", CarType.MIDSIZE, currentYear - 10, 0);

        assertEquals(40.0, calculator.computeBaseRate(newCar), 0.001);    // factor 1.0
        assertEquals(36.0, calculator.computeBaseRate(midAgeCar), 0.001); // factor 0.9
        assertEquals(32.0, calculator.computeBaseRate(oldCar), 0.001);    // factor 0.8
    }

    @Test
    void testMileageSurcharge() {
        Car lowMileage = new Car("M", "M", CarType.MIDSIZE, 2024, 20000);
        Car mediumMileage = new Car("M", "M", CarType.MIDSIZE, 2024, 40000);
        Car highMileage = new Car("M", "M", CarType.MIDSIZE, 2024, 60000);

        assertEquals(40.0, calculator.computeBaseRate(lowMileage), 0.001);
        assertEquals(42.0, calculator.computeBaseRate(mediumMileage), 0.001);
        assertEquals(45.0, calculator.computeBaseRate(highMileage), 0.001);
    }

    @Test
    void testMinimumBaseRateBoundary() {
        // Very old economy car with low mileage to force rate down
        int currentYear = java.time.Year.now().getValue();
        Car veryOldEconomy = new Car("M", "M", CarType.ECONOMY, currentYear - 15, 0);
        // Calculation: 40 * 0.7 (Economy) * 0.8 (Old) = 22.4. 
        // If it were even lower, it would snap to 20.0.
        assertTrue(calculator.computeBaseRate(veryOldEconomy) >= 20.0);
    }
}