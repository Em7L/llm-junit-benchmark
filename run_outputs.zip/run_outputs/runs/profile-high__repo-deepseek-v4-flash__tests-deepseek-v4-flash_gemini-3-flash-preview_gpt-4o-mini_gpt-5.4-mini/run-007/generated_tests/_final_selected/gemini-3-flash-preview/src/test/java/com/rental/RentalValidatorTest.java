package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RentalValidatorTest {
    private final RentalValidator validator = new RentalValidator();

    @Test
    void testValidateSuccess() {
        Car car = new Car("T", "C", CarType.MIDSIZE, 2020, 10000);
        Customer customer = new Customer("A", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 2));
        
        List<String> errors = validator.validate(rental);
        assertTrue(errors.isEmpty());
    }

    @Test
    void testValidateDriverAgeBoundaries() {
        Car car = new Car("T", "C", CarType.MIDSIZE, 2020, 10000);
        Customer customer = new Customer("A", 20, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 2));
        
        assertTrue(validator.validate(rental).contains("Driver must be at least 21."));
        
        rental.setDriverAge(80);
        assertTrue(validator.validate(rental).contains("Driver age exceeds maximum."));
    }

    @Test
    void testValidateLuxuryCarRequirement() {
        Car car = new Car("L", "X", CarType.LUXURY, 2024, 0);
        Customer customer = new Customer("A", 22, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 2));
        
        assertTrue(validator.validate(rental).contains("Luxury cars require driver at least 25."));
    }

    @Test
    void testValidateDurationPositive() {
        Car car = new Car("T", "C", CarType.MIDSIZE, 2020, 10000);
        Customer customer = new Customer("A", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 1, 2), LocalDate.of(2024, 1, 1));
        
        assertTrue(validator.validate(rental).contains("Rental duration must be positive."));
    }

    @Test
    void testLoyaltyMemberSeniorWarning() {
        Car car = new Car("T", "C", CarType.MIDSIZE, 2020, 10000);
        Customer customer = new Customer("A", 72, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 2));
        
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Loyalty member over 70: additional insurance required."));
    }
}