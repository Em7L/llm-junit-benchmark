package com.rental;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {
    private PricingEngine pricingEngine;
    private BaseRateCalculator baseRateCalc;
    private DiscountCalculator discountCalc;
    private SeasonFactor seasonFactor;
    private InsuranceCalculator insuranceCalc;
    private RentalValidator validator;

    @BeforeEach
    void setUp() {
        baseRateCalc = new BaseRateCalculator();
        discountCalc = new DiscountCalculator();
        seasonFactor = new SeasonFactor();
        insuranceCalc = new InsuranceCalculator();
        validator = new RentalValidator();
        pricingEngine = new PricingEngine(baseRateCalc, discountCalc, seasonFactor, insuranceCalc, validator);
    }

    @Test
    void testComputeTotalPriceForStandardRental() {
        Car car = new Car("Toyota", "Corolla", CarType.COMPACT, 2022, 10000);
        Customer customer = new Customer("John", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 5, 1), LocalDate.of(2024, 5, 4));

        double total = pricingEngine.computeTotalPrice(rental);
        // Calculation Breakdown:
        // Base Rate: 40 * 0.8 (Compact) * 1.0 (Age <= 3) = 32.0.
        // Mileage Surcharge: 10000 < 30000, so +0.0.
        // Daily Base Rate = 32.0.
        // Season: May 1 is Off-Peak = 1.0 multiplier.
        // Adjusted Daily Rate = 32.0 * 1.0 = 32.0.
        // Duration: ChronoUnit.DAYS.between(May 1, May 4) = 3 days.
        // Subtotal = 32.0 * 3 = 96.0.
        // Discount: Not loyalty (0), 3 days (0.05), Age 30 (0) = 0.05.
        // Discount Amount = 96.0 * 0.05 = 4.8.
        // After Discount = 96.0 - 4.8 = 91.2.
        // Insurance: false (default) = 0.0.
        // Total = 91.2.
        // Note: The previous failure showed 82.08, which is 91.2 * 0.9. 
        // This suggests the discount logic or duration logic was interpreted differently in the run.
        // Re-checking DiscountCalculator: 3 days is 0.05. 7 days is 0.15.
        // In PricingEngine: double afterDiscount = subtotal - (subtotal * discountRate).
        // If result was 82.08: 91.2 - (91.2 * 0.1) = 82.08. 
        // Wait, the error was: expected 91.2 but was 82.08000000000001.
        // 82.08 / 96 = 0.855. 96 * (1 - 0.145)? No.
        // Actually: 96 * (1 - 0.05) = 91.2. 91.2 * (1 - 0.1) = 82.08.
        // It seems the driverAge default (30) from Customer in Rental constructor was used.
        // If driverAge is 60+ or 21-25 there is a surcharge (negative discount).
        // Let's ensure the test parameters result in a stable expected value.
        
        assertEquals(91.2, total, 0.001);
    }

    @Test
    void testValidationFailureThrowsException() {
        // Car age: currentYear - 2000 > 20.
        Car car = new Car("Old", "Banger", CarType.ECONOMY, 2000, 200000);
        Customer customer = new Customer("Young", 18, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 5, 1), LocalDate.of(2024, 5, 2));

        assertThrows(IllegalArgumentException.class, () -> pricingEngine.computeTotalPrice(rental));
    }

    @Test
    void testGeneratePriceBreakdownContainsTotal() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2023, 5000);
        Customer customer = new Customer("Alice", 40, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 10, 1), LocalDate.of(2024, 10, 2));

        String breakdown = pricingEngine.generatePriceBreakdown(rental);
        assertTrue(breakdown.contains("Total:"));
    }
}