package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class SeasonFactorTest {
    private final SeasonFactor seasonFactor = new SeasonFactor();

    @Test
    void testSummerPeakMultiplier() {
        assertEquals(1.5, seasonFactor.getMultiplier(LocalDate.of(2024, 6, 15)));
        assertEquals(1.5, seasonFactor.getMultiplier(LocalDate.of(2024, 7, 15)));
        assertEquals(1.5, seasonFactor.getMultiplier(LocalDate.of(2024, 8, 31)));
    }

    @Test
    void testWinterHolidayMultiplier() {
        assertEquals(1.3, seasonFactor.getMultiplier(LocalDate.of(2024, 12, 15)));
        assertEquals(1.3, seasonFactor.getMultiplier(LocalDate.of(2024, 1, 1)));
        assertEquals(1.3, seasonFactor.getMultiplier(LocalDate.of(2024, 1, 5)));
    }

    @Test
    void testOffPeakMultiplier() {
        assertEquals(1.0, seasonFactor.getMultiplier(LocalDate.of(2024, 3, 1)));
        assertEquals(1.0, seasonFactor.getMultiplier(LocalDate.of(2024, 10, 31)));
    }
}