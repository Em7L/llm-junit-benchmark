package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class InsuranceCalculatorTest {
    private final InsuranceCalculator calculator = new InsuranceCalculator();

    @Test
    void testLuxuryInsurancePricing() {
        Car car = new Car("P", "P", CarType.LUXURY, 2024, 0);
        Customer customer = new Customer("C", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(1));
        
        double cost = calculator.computeInsuranceCost(rental, 100.0);
        assertEquals(30.0, cost, 0.001);
        
        rental.setDriverAge(22);
        assertEquals(50.0, calculator.computeInsuranceCost(rental, 100.0), 0.001);
    }

    @Test
    void testSecurityPackageAddOn() {
        Car car = new Car("M", "M", CarType.MIDSIZE, 2024, 0);
        Customer customer = new Customer("C", 40, false);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(1));
        
        // subtotal 300 > 200 and age 40 > 30
        double cost = calculator.computeInsuranceCost(rental, 300.0);
        // base 15.0 + (300 * 0.1) = 45.0
        assertEquals(45.0, cost, 0.001);
    }

    @Test
    void testInsuranceCostCap() {
        Car car = new Car("M", "M", CarType.MIDSIZE, 2024, 0);
        Customer customer = new Customer("C", 40, false);
        Rental rental = new Rental(car, customer, LocalDate.now(), LocalDate.now().plusDays(1));
        
        // Huge subtotal to trigger cap
        double cost = calculator.computeInsuranceCost(rental, 10000.0);
        assertEquals(500.0, cost);
    }
}