package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class SeasonFactorTest {

    private final SeasonFactor sf = new SeasonFactor();

    @Test
    void testOffPeak() {
        LocalDate date = LocalDate.of(2024, 3, 15);
        assertEquals(1.0, sf.getMultiplier(date), 0.001);
    }

    @Test
    void testSummerPeakStartBoundary() {
        // June 14: off-peak
        LocalDate before = LocalDate.of(2024, 6, 14);
        assertEquals(1.0, sf.getMultiplier(before), 0.001);
        // June 15: peak
        LocalDate start = LocalDate.of(2024, 6, 15);
        assertEquals(1.5, sf.getMultiplier(start), 0.001);
    }

    @Test
    void testSummerPeakEndBoundary() {
        // August 31: peak
        LocalDate end = LocalDate.of(2024, 8, 31);
        assertEquals(1.5, sf.getMultiplier(end), 0.001);
        // September 1: off-peak
        LocalDate after = LocalDate.of(2024, 9, 1);
        assertEquals(1.0, sf.getMultiplier(after), 0.001);
    }

    @Test
    void testWinterHolidayStartBoundary() {
        // December 14: off-peak
        LocalDate before = LocalDate.of(2024, 12, 14);
        assertEquals(1.0, sf.getMultiplier(before), 0.001);
        // December 15: peak
        LocalDate start = LocalDate.of(2024, 12, 15);
        assertEquals(1.3, sf.getMultiplier(start), 0.001);
    }

    @Test
    void testWinterHolidayEndBoundary() {
        // January 5: peak (note: January 5 of next year? We'll use 2025)
        LocalDate end = LocalDate.of(2025, 1, 5);
        assertEquals(1.3, sf.getMultiplier(end), 0.001);
        // January 6: off-peak
        LocalDate after = LocalDate.of(2025, 1, 6);
        assertEquals(1.0, sf.getMultiplier(after), 0.001);
    }

    @Test
    void testSummerPeakJuly() {
        LocalDate date = LocalDate.of(2024, 7, 4);
        assertEquals(1.5, sf.getMultiplier(date), 0.001);
    }

    @Test
    void testWinterHolidayDecember() {
        LocalDate date = LocalDate.of(2024, 12, 25);
        assertEquals(1.3, sf.getMultiplier(date), 0.001);
    }
}