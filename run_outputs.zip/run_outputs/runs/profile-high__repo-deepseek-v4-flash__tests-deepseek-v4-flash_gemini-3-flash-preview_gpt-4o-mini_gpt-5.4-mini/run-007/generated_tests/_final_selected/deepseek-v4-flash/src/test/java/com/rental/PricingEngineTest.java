package com.rental;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class PricingEngineTest {

    private PricingEngine engine;
    private BaseRateCalculator baseRateCalc;
    private DiscountCalculator discountCalc;
    private SeasonFactor seasonFactor;
    private InsuranceCalculator insuranceCalc;
    private RentalValidator validator;

    @BeforeEach
    void setUp() {
        baseRateCalc = new BaseRateCalculator();
        discountCalc = new DiscountCalculator();
        seasonFactor = new SeasonFactor();
        insuranceCalc = new InsuranceCalculator();
        validator = new RentalValidator();
        engine = new PricingEngine(baseRateCalc, discountCalc, seasonFactor, insuranceCalc, validator);
    }

    @Test
    void testComputeTotalPriceValidRental() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 1), LocalDate.of(2024, 7, 5));
        rental.setDriverAge(28);
        rental.setIncludesInsurance(true);
        double total = engine.computeTotalPrice(rental);
        assertTrue(total > 0);
        // We can compute expected manually but not necessary for integration test
    }

    @Test
    void testComputeTotalPriceWithoutInsurance() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2021, 20000);
        Customer customer = new Customer("Bob", 25, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 3, 1), LocalDate.of(2024, 3, 5));
        rental.setDriverAge(25);
        rental.setIncludesInsurance(false);
        double total = engine.computeTotalPrice(rental);
        assertTrue(total > 0);
    }

    @Test
    void testComputeTotalPriceInvalidRentalThrowsException() {
        Car car = new Car("Old", "Car", CarType.ECONOMY, 1999, 100000); // too old
        Customer customer = new Customer("Charlie", 40, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 6, 1), LocalDate.of(2024, 6, 5));
        rental.setDriverAge(40);
        rental.setIncludesInsurance(false);
        assertThrows(IllegalArgumentException.class, () -> engine.computeTotalPrice(rental));
    }

    @Test
    void testComputeTotalPriceNegativeDurationThrows() {
        Car car = new Car("Test", "Car", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Diana", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 5), LocalDate.of(2024, 7, 1)); // end before start
        rental.setDriverAge(30);
        rental.setIncludesInsurance(false);
        // Rental duration will be negative? getRentalDurationInDays returns negative, which fails validation
        assertThrows(IllegalArgumentException.class, () -> engine.computeTotalPrice(rental));
    }

    @Test
    void testGeneratePriceBreakdown() {
        Car car = new Car("Ford", "Focus", CarType.ECONOMY, 2024, 0);
        Customer customer = new Customer("Eve", 35, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 8, 1), LocalDate.of(2024, 8, 3));
        rental.setDriverAge(35);
        rental.setIncludesInsurance(false);
        String breakdown = engine.generatePriceBreakdown(rental);
        assertTrue(breakdown.startsWith("Total: "));
        double total = Double.parseDouble(breakdown.substring(7).trim());
        assertTrue(total >= 0);
    }

    @Test
    void testComputeTotalPriceBoundaryMinimum() {
        // To test total >=0, we can try to create a scenario where after discount it becomes negative? But discounts are capped between -0.5 and 0.5, and insurance is non-negative, so total should be non-negative. But we can test with surcharges that could make afterDiscount negative? Actually discountRate can be negative, so afterDiscount = subtotal - (subtotal * negative) = subtotal * (1 - negative) > subtotal. So afterDiscount is always >= subtotal if discountRate negative? Actually if discountRate negative, discountAmount is negative, so afterDiscount = subtotal - (negative) = subtotal + positive > subtotal. So afterDiscount is always positive. Then insurance is non-negative. So total is always positive. So no need to test negative boundary.
    }

    @Test
    void testComputeTotalPriceWithSeasonalMultiplier() {
        // Summer peak: multiplier 1.5
        Car car = new Car("Nissan", "Altima", CarType.MIDSIZE, 2022, 20000);
        Customer customer = new Customer("Frank", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 15), LocalDate.of(2024, 7, 18)); // summer
        rental.setDriverAge(30);
        rental.setIncludesInsurance(false);
        double totalSummer = engine.computeTotalPrice(rental);
        // Compare with off-peak
        Rental rentalOff = new Rental(car, customer, LocalDate.of(2024, 3, 15), LocalDate.of(2024, 3, 18));
        rentalOff.setDriverAge(30);
        rentalOff.setIncludesInsurance(false);
        double totalOff = engine.computeTotalPrice(rentalOff);
        assertTrue(totalSummer > totalOff);
    }
}