package com.rental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BaseRateCalculatorTest {

    private final BaseRateCalculator calc = new BaseRateCalculator();

    @Test
    void testComputeBaseRateEconomyNewLowMileage() {
        // age <= 3, mileage <= 30000
        Car car = new Car("Hyundai", "Accent", CarType.ECONOMY, 2022, 20000);
        double rate = calc.computeBaseRate(car);
        // typeFactor=0.7, ageFactor=1.0, base=40*0.7*1.0=28, no mileage surcharge, min 20 => 28
        assertEquals(28.0, rate, 0.001);
    }

    @Test
    void testComputeBaseRateMidAgeHighMileage() {
        // age 4-7, mileage >50000
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2019, 60000);
        double rate = calc.computeBaseRate(car);
        // typeFactor=1.0, ageFactor=0.9 (since age=5), base=40*1.0*0.9=36, mileage surcharge +5 => 41, min 20 => 41
        assertEquals(41.0, rate, 0.001);
    }

    @Test
    void testComputeBaseRateOldCarMiddleMileage() {
        // age >7, mileage 30001-50000
        Car car = new Car("Ford", "Fusion", CarType.FULLSIZE, 2015, 40000);
        double rate = calc.computeBaseRate(car);
        // typeFactor=1.2, ageFactor=0.8 (age=9), base=40*1.2*0.8=38.4, mileage surcharge +2 => 40.4, min 20 => 40.4
        assertEquals(40.4, rate, 0.001);
    }

    @Test
    void testComputeBaseRateLuxuryNewLowMileage() {
        Car car = new Car("Mercedes", "S-Class", CarType.LUXURY, 2024, 0);
        double rate = calc.computeBaseRate(car);
        // typeFactor=2.0, ageFactor=1.0, base=40*2*1=80, no surcharge, min 20 => 80
        assertEquals(80.0, rate, 0.001);
    }

    @Test
    void testComputeBaseRateBoundaryMin() {
        // Ensure minimum of 20 is enforced: baseRate <20
        Car car = new Car("Cheap", "Basic", CarType.ECONOMY, 2024, 0);
        // typeFactor=0.7, ageFactor=1.0, base=28, but that's >20. To get below 20, need typeFactor*ageFactor<0.5 => not possible with given factors. So test when baseRate would be below 20? Actually factors: economy 0.7, ageFactor min 0.8 => 40*0.7*0.8=22.4 >20. So we cannot get below 20. But we can test boundary by setting car with very low factors? Not possible. So skip? Alternatively, test that baseRate is never below 20. But we can test that computeBaseRate returns at least 20. We'll test with a car that would give borderline: economy, age 10, low mileage: 40*0.7*0.8=22.4, so still above 20. So the minimum is effectively 20 only if the computed rate is below 20. Since it never goes below, the test would be redundant. We can still assert that result is >=20.
        double rate = calc.computeBaseRate(car);
        assertTrue(rate >= 20.0);
    }

    @Test
    void testMileageSurchargeThresholds() {
        // Mileage exactly 30000 (no surcharge) vs 30001 (surcharge $2)
        Car car1 = new Car("A", "B", CarType.COMPACT, 2022, 30000);
        Car car2 = new Car("A", "B", CarType.COMPACT, 2022, 30001);
        double rate1 = calc.computeBaseRate(car1);
        double rate2 = calc.computeBaseRate(car2);
        assertEquals(rate1 + 2.0, rate2, 0.001);

        // Mileage exactly 50000 (surcharge $2) vs 50001 (surcharge $5)
        Car car3 = new Car("C", "D", CarType.COMPACT, 2022, 50000);
        Car car4 = new Car("C", "D", CarType.COMPACT, 2022, 50001);
        double rate3 = calc.computeBaseRate(car3);
        double rate4 = calc.computeBaseRate(car4);
        assertEquals(rate3 + 3.0, rate4, 0.001); // difference between $2 and $5 is $3
    }

    @Test
    void testAgeFactorBoundaries() {
        // Age 3 vs 4: ageFactor 1.0 vs 0.9
        Car carYoung = new Car("X", "Y", CarType.MIDSIZE, 2021, 0); // age 3
        Car carOld = new Car("X", "Y", CarType.MIDSIZE, 2020, 0); // age 4
        double rateYoung = calc.computeBaseRate(carYoung);
        double rateOld = calc.computeBaseRate(carOld);
        assertEquals(rateYoung * 0.9, rateOld, 0.001); // because type and mileage same, ageFactor changes

        // Age 7 vs 8: ageFactor 0.9 vs 0.8
        Car carSeven = new Car("X", "Y", CarType.MIDSIZE, 2017, 0); // age 7
        Car carEight = new Car("X", "Y", CarType.MIDSIZE, 2016, 0); // age 8
        double rateSeven = calc.computeBaseRate(carSeven);
        double rateEight = calc.computeBaseRate(carEight);
        assertEquals(rateSeven * (0.8/0.9), rateEight, 0.001);
    }
}