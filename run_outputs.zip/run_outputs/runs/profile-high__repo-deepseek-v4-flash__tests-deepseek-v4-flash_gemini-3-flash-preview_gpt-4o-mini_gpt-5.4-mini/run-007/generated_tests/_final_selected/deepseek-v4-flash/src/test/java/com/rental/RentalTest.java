package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class RentalTest {

    @Test
    void testConstructorAndGetters() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        LocalDate start = LocalDate.of(2024, 7, 1);
        LocalDate end = LocalDate.of(2024, 7, 5);
        Rental rental = new Rental(car, customer, start, end);
        assertEquals(car, rental.getCar());
        assertEquals(customer, rental.getCustomer());
        assertEquals(start, rental.getStartDate());
        assertEquals(end, rental.getEndDate());
        assertEquals(30, rental.getDriverAge()); // initialized from customer age
        assertFalse(rental.isIncludesInsurance());
    }

    @Test
    void testSetDriverAge() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2021, 20000);
        Customer customer = new Customer("Bob", 25, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 6, 1), LocalDate.of(2024, 6, 10));
        rental.setDriverAge(28);
        assertEquals(28, rental.getDriverAge());
    }

    @Test
    void testSetIncludesInsurance() {
        Car car = new Car("Ford", "Focus", CarType.ECONOMY, 2024, 0);
        Customer customer = new Customer("Charlie", 22, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 8, 1), LocalDate.of(2024, 8, 3));
        rental.setIncludesInsurance(true);
        assertTrue(rental.isIncludesInsurance());
    }

    @Test
    void testRentalDurationInDays() {
        Car car = new Car("BMW", "X5", CarType.SUV, 2022, 40000);
        Customer customer = new Customer("Diana", 35, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 12, 20), LocalDate.of(2024, 12, 25));
        assertEquals(5, rental.getRentalDurationInDays());
    }

    @Test
    void testRentalDurationZero() {
        Car car = new Car("Tesla", "Model S", CarType.LUXURY, 2023, 10000);
        Customer customer = new Customer("Eve", 40, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 5, 10), LocalDate.of(2024, 5, 10));
        assertEquals(0, rental.getRentalDurationInDays());
    }
}