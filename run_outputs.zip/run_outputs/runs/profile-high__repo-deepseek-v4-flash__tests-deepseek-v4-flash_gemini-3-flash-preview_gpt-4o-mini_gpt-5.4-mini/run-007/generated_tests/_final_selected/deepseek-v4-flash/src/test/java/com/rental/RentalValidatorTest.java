package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RentalValidatorTest {

    private final RentalValidator validator = new RentalValidator();

    private Rental createRental(Car car, Customer customer, LocalDate start, LocalDate end, int driverAge, boolean insurance) {
        Rental rental = new Rental(car, customer, start, end);
        rental.setDriverAge(driverAge);
        rental.setIncludesInsurance(insurance);
        return rental;
    }

    @Test
    void testValidRental() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 7, 1), LocalDate.of(2024, 7, 5), 30, false);
        List<String> errors = validator.validate(rental);
        assertTrue(errors.isEmpty());
    }

    @Test
    void testCarTooOld() {
        Car car = new Car("Old", "Car", CarType.ECONOMY, 2000, 100000); // age >20
        Customer customer = new Customer("Bob", 40, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 5), 40, false);
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Car is too old."));
    }

    @Test
    void testDriverTooYoung() {
        Car car = new Car("Honda", "Civic", CarType.COMPACT, 2021, 20000);
        Customer customer = new Customer("Charlie", 20, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 6, 1), LocalDate.of(2024, 6, 3), 20, false);
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Driver must be at least 21."));
    }

    @Test
    void testDriverTooOld() {
        Car car = new Car("Ford", "Focus", CarType.ECONOMY, 2015, 50000);
        Customer customer = new Customer("Diana", 80, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 3, 1), LocalDate.of(2024, 3, 5), 80, false);
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Driver age exceeds maximum."));
    }

    @Test
    void testNonPositiveDuration() {
        Car car = new Car("Tesla", "Model 3", CarType.LUXURY, 2023, 10000);
        Customer customer = new Customer("Eve", 35, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 5, 10), LocalDate.of(2024, 5, 10), 35, false); // same day
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Rental duration must be positive."));
    }

    @Test
    void testLuxuryCarYoungDriver() {
        Car car = new Car("BMW", "7 Series", CarType.LUXURY, 2022, 15000);
        Customer customer = new Customer("Frank", 24, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 8, 1), LocalDate.of(2024, 8, 3), 24, false);
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Luxury cars require driver at least 25."));
    }

    @Test
    void testLoyaltyMemberOver70WithoutExceedingMaxAge() {
        Car car = new Car("Audi", "A4", CarType.MIDSIZE, 2019, 30000);
        Customer customer = new Customer("Grace", 72, true);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 2, 1), LocalDate.of(2024, 2, 5), 72, false);
        List<String> errors = validator.validate(rental);
        // Should contain "Loyalty member over 70: additional insurance required."
        assertTrue(errors.contains("Loyalty member over 70: additional insurance required."));
    }

    @Test
    void testLoyaltyMemberOver70ButAlsoTooOld() {
        // If driver age >75, the "Driver age exceeds maximum." error is added, and the loyalty warning is added only if that error is not present? The code checks: if loyalty member and age >70 and !errors.contains("Driver age exceeds maximum.") then add warning. So when age >75, the maximum error is already present, so warning should not be added.
        Car car = new Car("Lexus", "RX", CarType.SUV, 2020, 40000);
        Customer customer = new Customer("Henry", 80, true);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 4, 1), LocalDate.of(2024, 4, 5), 80, false);
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Driver age exceeds maximum."));
        assertFalse(errors.contains("Loyalty member over 70: additional insurance required."));
    }

    @Test
    void testMultipleErrors() {
        Car car = new Car("VeryOld", "Old", CarType.ECONOMY, 1999, 100000); // age >20
        Customer customer = new Customer("Ivy", 19, false);
        Rental rental = createRental(car, customer, LocalDate.of(2024, 12, 1), LocalDate.of(2024, 12, 1), 19, false); // same day, duration 0
        List<String> errors = validator.validate(rental);
        assertTrue(errors.contains("Car is too old."));
        assertTrue(errors.contains("Driver must be at least 21."));
        assertTrue(errors.contains("Rental duration must be positive."));
    }
}