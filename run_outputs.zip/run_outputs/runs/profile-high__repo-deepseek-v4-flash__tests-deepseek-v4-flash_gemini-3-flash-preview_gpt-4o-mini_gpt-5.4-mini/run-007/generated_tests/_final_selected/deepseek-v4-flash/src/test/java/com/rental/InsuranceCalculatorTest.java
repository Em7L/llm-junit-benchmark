package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class InsuranceCalculatorTest {

    private final InsuranceCalculator calc = new InsuranceCalculator();

    private Rental createRental(CarType carType, int driverAge, boolean insurance) {
        Car car = new Car("Test", "Model", carType, 2022, 20000);
        Customer customer = new Customer("Test", 30, false);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 5));
        rental.setDriverAge(driverAge);
        rental.setIncludesInsurance(insurance);
        return rental;
    }

    @Test
    void testNonLuxuryNonSUV() {
        Rental rental = createRental(CarType.COMPACT, 30, true);
        double subtotal = 100.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(15.0, cost, 0.001);
    }

    @Test
    void testLuxuryDriverOver25() {
        Rental rental = createRental(CarType.LUXURY, 30, true);
        double subtotal = 200.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(30.0, cost, 0.001);
    }

    @Test
    void testLuxuryDriver21to24() {
        Rental rental = createRental(CarType.LUXURY, 22, true);
        double subtotal = 100.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(50.0, cost, 0.001);
    }

    @Test
    void testLuxuryDriverUnder21() {
        Rental rental = createRental(CarType.LUXURY, 20, true);
        double subtotal = 100.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(100.0, cost, 0.001);
    }

    @Test
    void testSUVDriverUnder25() {
        Rental rental = createRental(CarType.SUV, 24, true);
        double subtotal = 100.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(40.0, cost, 0.001);
    }

    @Test
    void testSUVDriverOver25() {
        Rental rental = createRental(CarType.SUV, 25, true);
        double subtotal = 100.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(20.0, cost, 0.001);
    }

    @Test
    void testSecurityPackageAddOn() {
        // subtotal > 200 and driverAge > 30
        Rental rental = createRental(CarType.MIDSIZE, 35, true);
        double subtotal = 250.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        // base = 15.0, plus 10% of subtotal = 25.0 => total 40.0
        assertEquals(40.0, cost, 0.001);
    }

    @Test
    void testSecurityPackageNotAppliedWhenSubtotalNotExceed() {
        Rental rental = createRental(CarType.MIDSIZE, 35, true);
        double subtotal = 200.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(15.0, cost, 0.001);
    }

    @Test
    void testSecurityPackageNotAppliedWhenDriverAge30OrLess() {
        Rental rental = createRental(CarType.MIDSIZE, 30, true);
        double subtotal = 250.0;
        double cost = calc.computeInsuranceCost(rental, subtotal);
        assertEquals(15.0, cost, 0.001);
    }

    @Test
    void testBoundaryMaxInsurance() {
        // Create scenario where base exceeds 500
        Rental rental = createRental(CarType.LUXURY, 20, true); // base = 100.0
        double subtotal = 5000.0; // but driverAge 20 not >30, so no add-on. Actually driverAge 20 <=30, so no add-on. To get high base, we need luxury young driver under 21 gives 100, not enough. To exceed 500, need add-on: subtotal>200 and driverAge>30. So set luxury, driverAge 35, subtotal 5000 => base 30 (since age>=25? Actually luxury with age>=25 gives 30, add-on 10% of subtotal = 500 => 530, capped at 500.
        Rental rental2 = createRental(CarType.LUXURY, 35, true);
        double subtotal2 = 5000.0;
        double cost = calc.computeInsuranceCost(rental2, subtotal2);
        assertEquals(500.0, cost, 0.001);
    }

    @Test
    void testInsuranceCostExactBoundary() {
        // Test that 500 is cap
        Rental rental = createRental(CarType.LUXURY, 35, true);
        double subtotal = 5000.0; // gives 30 + 500 = 530, capped to 500
        assertEquals(500.0, calc.computeInsuranceCost(rental, subtotal), 0.001);
    }
}