package com.rental;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class DiscountCalculatorTest {

    private final DiscountCalculator calc = new DiscountCalculator();

    private Rental createRental(Customer customer, int driverAge, long days, boolean loyalty) {
        Car car = new Car("Test", "Car", CarType.MIDSIZE, 2022, 20000);
        // use start and end dates to achieve desired days
        LocalDate start = LocalDate.of(2024, 1, 1);
        LocalDate end = start.plusDays(days);
        Rental rental = new Rental(car, customer, start, end);
        rental.setDriverAge(driverAge);
        return rental;
    }

    @Test
    void testNoDiscounts() {
        Customer customer = new Customer("NoLoyalty", 30, false);
        Rental rental = createRental(customer, 30, 1, false); // duration 1 day, age 30
        double rate = calc.computeDiscountRate(rental);
        assertEquals(0.0, rate, 0.001);
    }

    @Test
    void testLoyaltyDiscount() {
        Customer customer = new Customer("Loyal", 30, true);
        Rental rental = createRental(customer, 30, 1, true);
        double rate = calc.computeDiscountRate(rental);
        assertEquals(0.1, rate, 0.001);
    }

    @Test
    void testLongRentalDiscount7Days() {
        Customer customer = new Customer("Long", 30, false);
        Rental rental = createRental(customer, 30, 7, false);
        double rate = calc.computeDiscountRate(rental);
        assertEquals(0.15, rate, 0.001);
    }

    @Test
    void testLongRentalDiscount3Days() {
        Customer customer = new Customer("Medium", 30, false);
        Rental rental = createRental(customer, 30, 3, false);
        double rate = calc.computeDiscountRate(rental);
        assertEquals(0.05, rate, 0.001);
    }

    @Test
    void testYoungDriverSurcharge() {
        Customer customer = new Customer("Young", 22, false);
        Rental rental = createRental(customer, 22, 1, false);
        double rate = calc.computeDiscountRate(rental);
        assertEquals(-0.2, rate, 0.001);
    }

    @Test
    void testSeniorDriverSurcharge() {
        Customer customer = new Customer("Senior", 65, false);
        Rental rental = createRental(customer, 65, 1, false);
        double rate = calc.computeDiscountRate(rental);
        assertEquals(-0.1, rate, 0.001);
    }

    @Test
    void testCombinationCappingUpper() {
        // loyalty + long rental (>=7) = 0.1+0.15=0.25, still within cap
        Customer customer = new Customer("LoyalLong", 30, true);
        Rental rental = createRental(customer, 30, 7, true);
        double rate = calc.computeDiscountRate(rental);
        assertEquals(0.25, rate, 0.001);
    }

    @Test
    void testCombinationCappingLower() {
        // young driver surcharge + senior? cannot both. But we can have young + no other discounts = -0.2, still within cap
        // To test lower cap, need combination: loyalty? no, negative. Actually young surcharge is -0.2, senior surcharge -0.1, if both? Not possible due to age. We can test with young and long rental? Young (-0.2) + long (>7) (0.15) = -0.05. Not hitting -0.5. To hit -0.5, we need multiple surcharges, but only two possible: young (-0.2) and senior? can't. So lower cap might not be reachable. But we can test that rate is not below -0.5 by adding a case that would go below? Not possible with given rules. So we test that capping works when combined with other discounts? The code sums and then caps. So if we have loyalty+long+young? loyalty+long=0.25, young=-0.2 => 0.05, still within. To exceed upper cap, we need multiple discounts: loyalty+long+? no other positive. So upper cap may not be reached. We can test directly by creating a scenario? Not needed. We'll test that capping is applied in extreme case by mocking? No. We'll skip capping tests or test that values are within range.
        // But we can assert that after computation, rate is between -0.5 and 0.5 for any combination.
        Rental rental = createRental(new Customer("Any", 22, true), 22, 7, true);
        double rate = calc.computeDiscountRate(rental);
        assertTrue(rate >= -0.5 && rate <= 0.5);
    }

    @Test
    void testDriverAgeBoundary21And60() {
        // Age 21: young surcharge applies (21-24)
        Customer customer = new Customer("Age21", 21, false);
        Rental rental = createRental(customer, 21, 1, false);
        assertEquals(-0.2, calc.computeDiscountRate(rental), 0.001);

        // Age 60: senior surcharge applies
        Customer customer60 = new Customer("Age60", 60, false);
        Rental rental60 = createRental(customer60, 60, 1, false);
        assertEquals(-0.1, calc.computeDiscountRate(rental60), 0.001);

        // Age 25: no age surcharge
        Customer customer25 = new Customer("Age25", 25, false);
        Rental rental25 = createRental(customer25, 25, 1, false);
        assertEquals(0.0, calc.computeDiscountRate(rental25), 0.001);

        // Age 59: no surcharge
        Customer customer59 = new Customer("Age59", 59, false);
        Rental rental59 = createRental(customer59, 59, 1, false);
        assertEquals(0.0, calc.computeDiscountRate(rental59), 0.001);
    }
}