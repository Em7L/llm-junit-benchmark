package com.rental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void testConstructorAndGetters() {
        Customer customer = new Customer("Alice", 30, true);
        assertEquals(30, customer.getAge());
        assertTrue(customer.isLoyaltyMember());
    }

    @Test
    void testNonLoyaltyMember() {
        Customer customer = new Customer("Bob", 25, false);
        assertFalse(customer.isLoyaltyMember());
    }

    @Test
    void testYoungCustomer() {
        Customer customer = new Customer("Charlie", 22, false);
        assertEquals(22, customer.getAge());
    }
}