package com.rental;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SeasonFactorTest {

    private final SeasonFactor seasonFactor = new SeasonFactor();

    @Test
    void returnsSummerMultiplierWithinPeakWindow() {
        assertEquals(1.5, seasonFactor.getMultiplier(LocalDate.of(2024, 6, 15)), 0.0001);
        assertEquals(1.5, seasonFactor.getMultiplier(LocalDate.of(2024, 7, 10)), 0.0001);
        assertEquals(1.5, seasonFactor.getMultiplier(LocalDate.of(2024, 8, 31)), 0.0001);
    }

    @Test
    void returnsWinterMultiplierWithinHolidayWindow() {
        assertEquals(1.3, seasonFactor.getMultiplier(LocalDate.of(2024, 12, 15)), 0.0001);
        assertEquals(1.3, seasonFactor.getMultiplier(LocalDate.of(2025, 1, 5)), 0.0001);
    }

    @Test
    void returnsOffPeakMultiplierOutsideSpecialPeriods() {
        assertEquals(1.0, seasonFactor.getMultiplier(LocalDate.of(2024, 2, 1)), 0.0001);
        assertEquals(1.0, seasonFactor.getMultiplier(LocalDate.of(2024, 6, 14)), 0.0001);
        assertEquals(1.0, seasonFactor.getMultiplier(LocalDate.of(2024, 12, 14)), 0.0001);
    }
}