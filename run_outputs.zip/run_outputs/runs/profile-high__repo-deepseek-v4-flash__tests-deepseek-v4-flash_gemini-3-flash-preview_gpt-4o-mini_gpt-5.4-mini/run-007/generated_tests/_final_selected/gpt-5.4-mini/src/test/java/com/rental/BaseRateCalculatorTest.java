package com.rental;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BaseRateCalculatorTest {

    private final BaseRateCalculator calculator = new BaseRateCalculator();

    @Test
    void computesEconomyRateWithAgeAndMileageAdjustments() {
        int currentYear = java.time.Year.now().getValue();
        Car car = new Car("Ford", "Fiesta", CarType.ECONOMY, currentYear, 60000);

        double rate = calculator.computeBaseRate(car);

        // 40 * 0.7 * 1.0 + 5 mileage surcharge
        assertEquals(33.0, rate, 0.0001);
    }

    @Test
    void appliesMidMileageSurchargeForMidsizeCar() {
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, java.time.Year.now().getValue() - 5, 40000);

        double rate = calculator.computeBaseRate(car);

        // 40 * 1.0 * 0.9 + 2 mileage surcharge
        assertEquals(38.0, rate, 0.0001);
    }

    @Test
    void enforcesMinimumBaseRateForVeryOldHighMileageLuxuryCar() {
        Car car = new Car("Mercedes", "S-Class", CarType.LUXURY, 1990, 200000);

        double rate = calculator.computeBaseRate(car);

        assertEquals(69.0, rate, 0.0001);
    }

    @Test
    void selectsCorrectTypeFactorForAllCarTypes() {
        int currentYear = java.time.Year.now().getValue();
        assertEquals(28.0, calculator.computeBaseRate(new Car("A", "B", CarType.ECONOMY, currentYear, 0)), 0.0001);
        assertEquals(32.0, calculator.computeBaseRate(new Car("A", "B", CarType.COMPACT, currentYear, 0)), 0.0001);
        assertEquals(40.0, calculator.computeBaseRate(new Car("A", "B", CarType.MIDSIZE, currentYear, 0)), 0.0001);
        assertEquals(48.0, calculator.computeBaseRate(new Car("A", "B", CarType.FULLSIZE, currentYear, 0)), 0.0001);
        assertEquals(60.0, calculator.computeBaseRate(new Car("A", "B", CarType.SUV, currentYear, 0)), 0.0001);
        assertEquals(80.0, calculator.computeBaseRate(new Car("A", "B", CarType.LUXURY, currentYear, 0)), 0.0001);
    }
}
