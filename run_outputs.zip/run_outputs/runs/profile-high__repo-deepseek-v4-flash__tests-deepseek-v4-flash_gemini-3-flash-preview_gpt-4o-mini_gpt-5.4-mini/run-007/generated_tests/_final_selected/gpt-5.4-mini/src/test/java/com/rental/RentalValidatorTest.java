package com.rental;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RentalValidatorTest {

    private final RentalValidator validator = new RentalValidator();

    @Test
    void acceptsValidRentalWithoutErrors() {
        Rental rental = new Rental(
                new Car("Toyota", "Camry", CarType.MIDSIZE, 2022, 15000),
                new Customer("Alice", 30, true),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 5)
        );
        rental.setDriverAge(30);

        List<String> errors = validator.validate(rental);

        assertTrue(errors.isEmpty());
    }

    @Test
    void reportsMultipleErrorsForInvalidRental() {
        Rental rental = new Rental(
                new Car("Old", "Beater", CarType.LUXURY, 2000, 90000),
                new Customer("Bob", 20, false),
                LocalDate.of(2024, 7, 10),
                LocalDate.of(2024, 7, 10)
        );
        rental.setDriverAge(20);

        List<String> errors = validator.validate(rental);

        assertEquals(4, errors.size());
        assertTrue(errors.contains("Car is too old."));
        assertTrue(errors.contains("Driver must be at least 21."));
        assertTrue(errors.contains("Rental duration must be positive."));
        assertTrue(errors.contains("Luxury cars require driver at least 25."));
    }

    @Test
    void warnsLoyaltyMemberOverSeventyWhenOtherAgeRuleDoesNotApply() {
        Rental rental = new Rental(
                new Car("Toyota", "Camry", CarType.MIDSIZE, 2022, 15000),
                new Customer("Ellen", 72, true),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 4)
        );
        rental.setDriverAge(72);

        List<String> errors = validator.validate(rental);

        assertEquals(1, errors.size());
        assertEquals("Loyalty member over 70: additional insurance required.", errors.get(0));
    }

    @Test
    void doesNotAddLoyaltyWarningWhenDriverAgeExceedsMaximum() {
        Rental rental = new Rental(
                new Car("Toyota", "Camry", CarType.MIDSIZE, 2022, 15000),
                new Customer("Frank", 80, true),
                LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 7, 4)
        );
        rental.setDriverAge(80);

        List<String> errors = validator.validate(rental);

        assertTrue(errors.contains("Driver age exceeds maximum."));
        assertTrue(errors.size() >= 1);
        assertTrue(errors.stream().noneMatch(e -> e.contains("additional insurance required")));
    }
}