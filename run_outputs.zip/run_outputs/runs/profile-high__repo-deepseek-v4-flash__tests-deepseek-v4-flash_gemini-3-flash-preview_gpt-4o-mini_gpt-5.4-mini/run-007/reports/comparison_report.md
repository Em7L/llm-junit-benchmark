# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-007/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_partially_improved | 1 |
| deepseek-v4-flash | passed | repair_partially_improved | 1 |
| gemini-3-flash-preview | passed | repair_no_improvement | 1 |
| gpt-4o-mini | passed | repair_no_improvement | 1 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 21 | 8 | 0 | 65.70% | 62.11% | 123 | 65 | 14 | 44 | 52.85% |
| deepseek-v4-flash | test_compile_failure | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| gemini-3-flash-preview | test_failures | 21 | 1 | 0 | 83.72% | 76.84% | 123 | 74 | 36 | 13 | 60.16% |
| gpt-4o-mini | test_failures | 21 | 9 | 0 | 79.07% | 61.05% | 123 | 40 | 56 | 27 | 32.52% |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 21 | 1 | 0 | 83.14% | 75.79% | 123 | 85 | 19 | 19 | 69.11% |
| deepseek-v4-flash | test_failures | 62 | 5 | 0 | 88.37% | 90.53% | 123 | 96 | 19 | 8 | 78.05% |
| gemini-3-flash-preview | test_failures | 21 | 1 | 0 | 83.72% | 76.84% | 123 | 74 | 36 | 13 | 60.16% |
| gpt-4o-mini | test_failures | 21 | 9 | 0 | 79.07% | 61.05% | 123 | 40 | 56 | 27 | 32.52% |

## Mutant Set Consistency
- Comparable PIT suites: `7`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `123`
- Union mutant IDs: `123`
- `_final_selected/deepseek-v4-flash` mutant IDs: `123`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `123`
- `_final_selected/gpt-4o-mini` mutant IDs: `123`
- `_final_selected/gpt-5.4-mini` mutant IDs: `123`
- `_initial_snapshot/gemini-3-flash-preview` mutant IDs: `123`
- `_initial_snapshot/gpt-4o-mini` mutant IDs: `123`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `123`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_no_improvement`: One or more repair attempts were applied, but the final generated test suite did not verify any better than the first verifiable suite.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `maven_status=test_compile_failure`: The generated or existing test sources did not compile during Maven test validation.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.