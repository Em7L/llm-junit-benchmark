package com.rental;

public class InsuranceCalculator {

    public double computeInsuranceCost(Rental rental, double subtotal) {
        double base = 0.0;
        CarType carType = rental.getCar().getType();
        int driverAge = rental.getDriverAge();

        // Edge-case-heavy method: multiple scenarios
        if (carType == CarType.LUXURY) {
            if (driverAge >= 25) {
                base = 30.0;
            } else if (driverAge >= 21) {
                base = 50.0;
            } else {
                base = 100.0; // young driver high risk
            }
        } else if (carType == CarType.SUV) {
            base = (driverAge < 25) ? 40.0 : 20.0;
        } else {
            base = 15.0;
        }

        // Security package add-on: 10% of subtotal if subtotal > 200
        if (subtotal > 200 && driverAge > 30) {
            base += subtotal * 0.1;
        }

        // Boundary check: insurance cost cannot exceed 500
        if (base > 500) {
            base = 500;
        }
        return base;
    }
}