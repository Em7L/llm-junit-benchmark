package com.rental;

import java.time.LocalDate;
import java.time.Month;

public class SeasonFactor {

    public double getMultiplier(LocalDate date) {
        Month month = date.getMonth();
        int day = date.getDayOfMonth();

        // Summer peak: June 15 - August 31
        if ((month == Month.JUNE && day >= 15) || month == Month.JULY || (month == Month.AUGUST && day <= 31)) {
            return 1.5;
        }
        // Winter holidays: December 15 - January 5
        if ((month == Month.DECEMBER && day >= 15) || (month == Month.JANUARY && day <= 5)) {
            return 1.3;
        }
        // Off-peak
        return 1.0;
    }
}