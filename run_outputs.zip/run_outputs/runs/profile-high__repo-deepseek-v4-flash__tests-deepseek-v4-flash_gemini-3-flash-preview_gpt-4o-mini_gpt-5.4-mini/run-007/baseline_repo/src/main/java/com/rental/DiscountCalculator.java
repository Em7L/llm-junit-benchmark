package com.rental;

import java.util.ArrayList;
import java.util.List;

public class DiscountCalculator {

    public double computeDiscountRate(Rental rental) {
        double rate = 0.0;
        List<Double> discounts = new ArrayList<>();

        // Loyalty discount
        if (rental.getCustomer().isLoyaltyMember()) {
            discounts.add(0.1);
        }

        // Long rental discount
        long days = rental.getRentalDurationInDays();
        if (days >= 7) {
            discounts.add(0.15);
        } else if (days >= 3) {
            discounts.add(0.05);
        }

        // Driver age discount (young driver surcharge as negative discount)
        int driverAge = rental.getDriverAge();
        if (driverAge < 25 && driverAge >= 21) {
            discounts.add(-0.2); // surcharge
        } else if (driverAge >= 60) {
            discounts.add(-0.1);
        }

        // Sum discounts (capped between -0.5 and 0.5)
        for (double d : discounts) {
            rate += d;
        }
        if (rate > 0.5) rate = 0.5;
        if (rate < -0.5) rate = -0.5;
        return rate;
    }
}