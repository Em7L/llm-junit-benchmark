package com.rental;

public class Customer {
    private final String name;
    private final int age;
    private final boolean loyaltyMember;

    public Customer(String name, int age, boolean loyaltyMember) {
        this.name = name;
        this.age = age;
        this.loyaltyMember = loyaltyMember;
    }

    public int getAge() { return age; }
    public boolean isLoyaltyMember() { return loyaltyMember; }
}