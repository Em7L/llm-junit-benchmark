package com.rental;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Rental {
    private final Car car;
    private final Customer customer;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private int driverAge;
    private boolean includesInsurance;

    public Rental(Car car, Customer customer, LocalDate startDate, LocalDate endDate) {
        this.car = car;
        this.customer = customer;
        this.startDate = startDate;
        this.endDate = endDate;
        this.driverAge = customer.getAge();
        this.includesInsurance = false;
    }

    public Car getCar() { return car; }
    public Customer getCustomer() { return customer; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public int getDriverAge() { return driverAge; }
    public void setDriverAge(int driverAge) { this.driverAge = driverAge; }
    public boolean isIncludesInsurance() { return includesInsurance; }
    public void setIncludesInsurance(boolean includesInsurance) { this.includesInsurance = includesInsurance; }

    public long getRentalDurationInDays() {
        return ChronoUnit.DAYS.between(startDate, endDate);
    }
}