package com.rental;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Create a sample rental and compute price
        Car car = new Car("Toyota", "Camry", CarType.MIDSIZE, 2020, 30000);
        Customer customer = new Customer("Alice", 30, true);
        Rental rental = new Rental(car, customer, LocalDate.of(2024, 7, 1), LocalDate.of(2024, 7, 5));
        rental.setDriverAge(28);
        rental.setIncludesInsurance(true);

        PricingEngine engine = new PricingEngine(new BaseRateCalculator(), new DiscountCalculator(), new SeasonFactor(), new InsuranceCalculator(), new RentalValidator());
        double total = engine.computeTotalPrice(rental);
        System.out.println("Total price: " + total);

        Rental rental2 = new Rental(car, customer, LocalDate.of(2024, 12, 20), LocalDate.of(2024, 12, 25));
        rental2.setDriverAge(22);
        rental2.setIncludesInsurance(false);
        double total2 = engine.computeTotalPrice(rental2);
        System.out.println("Total price 2: " + total2);
    }
}