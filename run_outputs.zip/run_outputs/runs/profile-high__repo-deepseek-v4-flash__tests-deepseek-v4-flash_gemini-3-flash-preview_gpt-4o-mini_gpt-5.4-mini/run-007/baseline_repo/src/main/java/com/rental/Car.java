package com.rental;

public class Car {
    private final String make;
    private final String model;
    private final CarType type;
    private final int year;
    private final int mileage;

    public Car(String make, String model, CarType type, int year, int mileage) {
        this.make = make;
        this.model = model;
        this.type = type;
        this.year = year;
        this.mileage = mileage;
    }

    public CarType getType() { return type; }
    public int getYear() { return year; }
    public int getMileage() { return mileage; }

    public int getAgeInYears() {
        return java.time.Year.now().getValue() - year;
    }
}