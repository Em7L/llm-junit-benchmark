package com.rental;

public class BaseRateCalculator {

    public double computeBaseRate(Car car) {
        double typeFactor = getTypeFactor(car.getType());
        int age = car.getAgeInYears();
        double ageFactor = (age <= 3) ? 1.0 : (age <= 7) ? 0.9 : 0.8;
        double baseRate = 40.0 * typeFactor * ageFactor;

        // Mileage surcharge
        int mileage = car.getMileage();
        if (mileage > 50000) {
            baseRate += 5.0;
        } else if (mileage > 30000) {
            baseRate += 2.0;
        }

        // Boundary check: baseRate must be at least 20
        if (baseRate < 20.0) {
            baseRate = 20.0;
        }
        return baseRate;
    }

    private double getTypeFactor(CarType type) {
        switch (type) {
            case ECONOMY: return 0.7;
            case COMPACT: return 0.8;
            case MIDSIZE: return 1.0;
            case FULLSIZE: return 1.2;
            case SUV: return 1.5;
            case LUXURY: return 2.0;
            default: return 1.0;
        }
    }
}