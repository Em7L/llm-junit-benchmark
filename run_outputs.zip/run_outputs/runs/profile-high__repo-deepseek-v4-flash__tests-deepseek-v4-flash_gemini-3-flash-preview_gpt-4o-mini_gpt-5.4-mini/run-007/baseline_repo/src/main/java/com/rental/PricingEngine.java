package com.rental;

import java.util.ArrayList;
import java.util.List;

public class PricingEngine {
    private final BaseRateCalculator baseRateCalc;
    private final DiscountCalculator discountCalc;
    private final SeasonFactor seasonFactor;
    private final InsuranceCalculator insuranceCalc;
    private final RentalValidator validator;

    public PricingEngine(BaseRateCalculator baseRateCalc, DiscountCalculator discountCalc, SeasonFactor seasonFactor, InsuranceCalculator insuranceCalc, RentalValidator validator) {
        this.baseRateCalc = baseRateCalc;
        this.discountCalc = discountCalc;
        this.seasonFactor = seasonFactor;
        this.insuranceCalc = insuranceCalc;
        this.validator = validator;
    }

    public double computeTotalPrice(Rental rental) {
        // Validate rental
        List<String> errors = validator.validate(rental);
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException("Rental validation failed: " + String.join("; ", errors));
        }

        // Base daily rate
        double baseDailyRate = baseRateCalc.computeBaseRate(rental.getCar());

        // Seasonal adjustment
        double seasonMultiplier = seasonFactor.getMultiplier(rental.getStartDate());
        double adjustedDailyRate = baseDailyRate * seasonMultiplier;

        // Duration
        long days = rental.getRentalDurationInDays();
        if (days <= 0) {
            throw new IllegalArgumentException("Rental duration must be positive.");
        }

        // Subtotal before discounts and insurance
        double subtotal = adjustedDailyRate * days;

        // Discounts
        double discountRate = discountCalc.computeDiscountRate(rental);
        double discountAmount = subtotal * discountRate;
        double afterDiscount = subtotal - discountAmount;

        // Insurance
        double insuranceCost = 0.0;
        if (rental.isIncludesInsurance()) {
            insuranceCost = insuranceCalc.computeInsuranceCost(rental, afterDiscount);
        }

        double total = afterDiscount + insuranceCost;
        // Apply boundary: total must be non-negative
        if (total < 0) {
            total = 0.0;
        }
        return total;
    }

    public String generatePriceBreakdown(Rental rental) {
        // Method with state built from prior calls (simplified)
        double total = computeTotalPrice(rental);
        return "Total: " + total;
    }
}