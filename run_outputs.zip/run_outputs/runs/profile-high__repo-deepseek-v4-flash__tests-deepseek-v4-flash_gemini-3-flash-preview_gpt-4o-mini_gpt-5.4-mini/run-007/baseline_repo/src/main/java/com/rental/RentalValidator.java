package com.rental;

import java.util.ArrayList;
import java.util.List;

public class RentalValidator {

    public List<String> validate(Rental rental) {
        List<String> errors = new ArrayList<>();
        Car car = rental.getCar();
        Customer customer = rental.getCustomer();

        // Car age check: no cars older than 20 years
        if (car.getAgeInYears() > 20) {
            errors.add("Car is too old.");
        }

        // Driver age check
        int driverAge = rental.getDriverAge();
        if (driverAge < 21) {
            errors.add("Driver must be at least 21.");
        } else if (driverAge > 75) {
            errors.add("Driver age exceeds maximum.");
        }

        // Rental duration must be positive
        if (rental.getRentalDurationInDays() <= 0) {
            errors.add("Rental duration must be positive.");
        }

        // Luxury cars require driver age >= 25
        if (car.getType() == CarType.LUXURY && driverAge < 25) {
            errors.add("Luxury cars require driver at least 25.");
        }

        // Multi-condition: if loyalty member but age > 70, warn but not error
        if (customer.isLoyaltyMember() && driverAge > 70 && !errors.contains("Driver age exceeds maximum.")) {
            errors.add("Loyalty member over 70: additional insurance required.");
        }

        return errors;
    }
}