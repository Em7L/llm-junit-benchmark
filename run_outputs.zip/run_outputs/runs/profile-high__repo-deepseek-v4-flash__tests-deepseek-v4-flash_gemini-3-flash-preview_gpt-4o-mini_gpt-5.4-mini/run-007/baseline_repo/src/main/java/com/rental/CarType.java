package com.rental;

public enum CarType {
    ECONOMY,
    COMPACT,
    MIDSIZE,
    FULLSIZE,
    SUV,
    LUXURY
}