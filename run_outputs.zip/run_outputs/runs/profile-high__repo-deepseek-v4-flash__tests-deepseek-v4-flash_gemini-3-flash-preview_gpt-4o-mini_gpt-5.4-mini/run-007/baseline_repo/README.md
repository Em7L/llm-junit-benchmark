# Rental Car Pricing Engine

A pricing engine for car rentals. Computes total cost based on car type, age, mileage, seasonal factors, customer loyalty, rental duration, driver age, and insurance options. The engine validates rentals and applies discounts/surcharges.

## Complexity Summary
- Number of classes: 10
- Total public methods: 23
- Methods with >= 3 branches: 5 (BaseRateCalculator.computeBaseRate, DiscountCalculator.computeDiscountRate, SeasonFactor.getMultiplier, InsuranceCalculator.computeInsuranceCost, RentalValidator.validate)
- Class descriptions:
  - Car: Represents a rental car with type, year, mileage, and age calculation.
  - CarType: Enum of car categories.
  - Customer: Customer info with age and loyalty status.
  - Rental: Rental transaction with dates, driver age, insurance flag.
  - PricingEngine: Orchestrates price calculation using other components.
  - BaseRateCalculator: Computes base daily rate based on car type, age, mileage.
  - DiscountCalculator: Computes discount/surcharge rate based on loyalty, duration, driver age.
  - SeasonFactor: Returns seasonal price multiplier based on date.
  - InsuranceCalculator: Computes insurance cost with multiple scenarios.
  - RentalValidator: Validates rental conditions and returns error list.