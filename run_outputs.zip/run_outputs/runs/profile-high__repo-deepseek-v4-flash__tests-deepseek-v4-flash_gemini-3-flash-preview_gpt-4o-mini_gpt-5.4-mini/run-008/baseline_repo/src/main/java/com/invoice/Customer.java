package com.invoice;

import java.time.LocalDate;

public class Customer {
    public enum Tier {
        BRONZE, SILVER, GOLD, PLATINUM
    }

    private String id;
    private String name;
    private Tier tier;
    private String region;

    public Customer(String id, String name, Tier tier, String region) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Customer ID cannot be null or empty");
        }
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be null or empty");
        }
        if (tier == null) {
            throw new IllegalArgumentException("Customer tier cannot be null");
        }
        if (region == null || region.isEmpty()) {
            throw new IllegalArgumentException("Region cannot be null or empty");
        }
        this.id = id;
        this.name = name;
        this.tier = tier;
        this.region = region;
    }

    String getId() { return id; }
    String getName() { return name; }
    Tier getTier() { return tier; }
    String getRegion() { return region; }

    public double getDiscountMultiplier() {
        switch (tier) {
            case PLATINUM: return 0.10;
            case GOLD: return 0.05;
            case SILVER: return 0.02;
            default: return 0.0;
        }
    }

    public boolean isHighValue() {
        return tier == Tier.PLATINUM || tier == Tier.GOLD;
    }
}