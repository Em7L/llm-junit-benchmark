package com.invoice;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class InvoiceValidator {

    public List<String> validate(Invoice invoice, Customer customer) {
        List<String> errors = new ArrayList<>();

        if (invoice == null) {
            errors.add("Invoice cannot be null");
            return errors;
        }

        if (invoice.getInvoiceId() == null || invoice.getInvoiceId().isEmpty()) {
            errors.add("Invoice ID is missing");
        }

        if (customer == null) {
            errors.add("Customer cannot be null");
        } else {
            if (customer.getId() == null || customer.getId().isEmpty()) {
                errors.add("Customer ID is missing");
            }
            if (customer.getTier() == null) {
                errors.add("Customer tier is not set");
            }
        }

        if (invoice.getItems() == null || invoice.getItems().isEmpty()) {
            errors.add("Invoice must have at least one line item");
        } else {
            for (LineItem item : invoice.getItems()) {
                if (item.getQuantity() <= 0) {
                    errors.add("Line item quantity must be positive (product: " + item.getProductId() + ")");
                }
                if (item.getUnitPrice() < 0) {
                    errors.add("Line item unit price cannot be negative (product: " + item.getProductId() + ")");
                }
            }
        }

        if (invoice.getRegion() == null || invoice.getRegion().isEmpty()) {
            errors.add("Region is missing");
        }

        if (invoice.getDate() == null) {
            errors.add("Invoice date is missing");
        } else if (invoice.getDate().isAfter(LocalDate.now())) {
            errors.add("Invoice date cannot be in the future");
        }

        return errors;
    }

    public boolean isValid(Invoice invoice, Customer customer) {
        return validate(invoice, customer).isEmpty();
    }
}