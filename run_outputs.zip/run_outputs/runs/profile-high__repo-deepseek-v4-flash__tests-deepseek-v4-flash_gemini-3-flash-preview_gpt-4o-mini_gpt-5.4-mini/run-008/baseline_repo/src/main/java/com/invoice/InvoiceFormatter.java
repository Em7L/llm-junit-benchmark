package com.invoice;

import java.util.List;

public class InvoiceFormatter {

    public String format(Invoice invoice) {
        if (invoice == null) return "No invoice data.";

        StringBuilder sb = new StringBuilder();
        sb.append("Invoice: ").append(invoice.getInvoiceId()).append("\n");
        sb.append("Customer: ").append(invoice.getCustomer().getName()).append("\n");
        sb.append("Date: ").append(invoice.getDate()).append("\n");
        sb.append("Region: ").append(invoice.getRegion()).append("\n");
        sb.append("Items:\n");
        for (LineItem item : invoice.getItems()) {
            sb.append(formatLineItem(item)).append("\n");
        }
        sb.append("Subtotal: $").append(String.format("%.2f", invoice.getSubtotal())).append("\n");
        sb.append("Discount: -$").append(String.format("%.2f", invoice.getDiscount())).append("\n");
        sb.append("Tax: +$").append(String.format("%.2f", invoice.getTax())).append("\n");
        sb.append("Total: $").append(String.format("%.2f", invoice.getGrandTotal())).append("\n");
        return sb.toString();
    }

    public String formatLineItem(LineItem item) {
        if (item == null) return "";
        return String.format("  %s x%d @ $%.2f = $%.2f",
                item.getDescription().isEmpty() ? item.getProductId() : item.getDescription(),
                item.getQuantity(),
                item.getUnitPrice(),
                item.getTotal());
    }

    public String formatSummary(Invoice invoice) {
        return String.format("Invoice %s: %d items, total $%.2f",
                invoice.getInvoiceId(), invoice.getItemCount(), invoice.getGrandTotal());
    }
}