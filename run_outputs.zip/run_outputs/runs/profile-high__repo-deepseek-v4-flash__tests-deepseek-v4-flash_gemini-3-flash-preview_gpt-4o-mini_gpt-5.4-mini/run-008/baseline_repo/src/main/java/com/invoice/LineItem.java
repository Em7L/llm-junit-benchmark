package com.invoice;

public class LineItem {
    private String productId;
    private String description;
    private int quantity;
    private double unitPrice;

    public LineItem(String productId, String description, int quantity, double unitPrice) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("Product ID required");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be > 0");
        }
        if (unitPrice < 0) {
            throw new IllegalArgumentException("Unit price cannot be negative");
        }
        this.productId = productId;
        this.description = description != null ? description : "";
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    String getProductId() { return productId; }
    String getDescription() { return description; }
    int getQuantity() { return quantity; }
    double getUnitPrice() { return unitPrice; }

    public double getTotal() {
        return quantity * unitPrice;
    }

    void setQuantity(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be > 0");
        }
        this.quantity = quantity;
    }

    void setUnitPrice(double unitPrice) {
        if (unitPrice < 0) {
            throw new IllegalArgumentException("Unit price cannot be negative");
        }
        this.unitPrice = unitPrice;
    }
}