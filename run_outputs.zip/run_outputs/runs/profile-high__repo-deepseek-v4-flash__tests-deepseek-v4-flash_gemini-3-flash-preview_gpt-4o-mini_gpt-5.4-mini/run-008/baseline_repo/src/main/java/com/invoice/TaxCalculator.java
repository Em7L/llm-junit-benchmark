package com.invoice;

public class TaxCalculator {

    public double calculateTax(Invoice invoice, String region) {
        double subtotal = invoice.computeSubtotal();
        double taxRate;
        switch (region.toUpperCase()) {
            case "DOMESTIC":
                taxRate = 0.07;
                break;
            case "INTERNATIONAL":
                taxRate = 0.05;
                break;
            case "SPECIAL":
                taxRate = 0.10;
                break;
            default:
                taxRate = 0.0;
        }
        return subtotal * taxRate;
    }

    public boolean isTaxExempt(Invoice invoice) {
        if (invoice.getItemCount() == 0) {
            return true;
        }
        for (LineItem item : invoice.getItems()) {
            if (item.getUnitPrice() > 1000 && item.getQuantity() <= 2) {
                return false;
            }
        }
        return false;
    }
}