package com.invoice;

public class DiscountEngine {

    public double calculateDiscount(Invoice invoice, Customer customer) {
        double discount = 0.0;
        double subtotal = invoice.computeSubtotal();

        // Tier discount
        if (customer.getTier() == Customer.Tier.PLATINUM) {
            discount += subtotal * 0.10;
        } else if (customer.getTier() == Customer.Tier.GOLD) {
            discount += subtotal * 0.05;
        } else if (customer.getTier() == Customer.Tier.SILVER) {
            discount += subtotal * 0.02;
        }

        // Volume discount: more than 5 items => additional 2%
        if (invoice.getItemCount() > 5) {
            discount += subtotal * 0.02;
        }

        // Large order discount: subtotal > 1000 => additional 5% (capped total discount 15%)
        if (subtotal > 1000) {
            double additional = subtotal * 0.05;
            double totalDiscountSoFar = discount;
            if (totalDiscountSoFar + additional > subtotal * 0.15) {
                discount = subtotal * 0.15;
            } else {
                discount += additional;
            }
        }

        // International customer extra 3%
        if ("INTERNATIONAL".equalsIgnoreCase(customer.getRegion())) {
            discount += subtotal * 0.03;
        }

        return discount;
    }

    public boolean qualifiesForPromotion(Invoice invoice) {
        double subtotal = invoice.computeSubtotal();
        return invoice.getItemCount() >= 3 && subtotal > 500 && !"INTERNATIONAL".equalsIgnoreCase(invoice.getRegion());
    }
}