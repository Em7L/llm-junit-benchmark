package com.invoice;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Invoice {
    private String invoiceId;
    private Customer customer;
    private List<LineItem> items;
    private String region;
    private LocalDate date;
    private double subtotal;
    private double discount;
    private double tax;
    private double grandTotal;
    private boolean processed;

    public Invoice(String invoiceId, Customer customer, String region, LocalDate date) {
        if (invoiceId == null || invoiceId.isEmpty()) {
            throw new IllegalArgumentException("Invoice ID required");
        }
        if (customer == null) {
            throw new IllegalArgumentException("Customer required");
        }
        if (region == null || region.isEmpty()) {
            throw new IllegalArgumentException("Region required");
        }
        if (date == null) {
            throw new IllegalArgumentException("Date required");
        }
        this.invoiceId = invoiceId;
        this.customer = customer;
        this.items = new ArrayList<>();
        this.region = region;
        this.date = date;
        this.processed = false;
    }

    String getInvoiceId() { return invoiceId; }
    Customer getCustomer() { return customer; }
    List<LineItem> getItems() { return Collections.unmodifiableList(items); }
    String getRegion() { return region; }
    LocalDate getDate() { return date; }
    double getSubtotal() { return subtotal; }
    double getDiscount() { return discount; }
    double getTax() { return tax; }
    double getGrandTotal() { return grandTotal; }
    boolean isProcessed() { return processed; }

    void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    void setDiscount(double discount) { this.discount = discount; }
    void setTax(double tax) { this.tax = tax; }
    void setGrandTotal(double grandTotal) { this.grandTotal = grandTotal; }
    void setProcessed(boolean processed) { this.processed = processed; }

    public void addLineItem(LineItem item) {
        if (item == null) {
            throw new IllegalArgumentException("Item cannot be null");
        }
        items.add(item);
    }

    public boolean removeLineItem(String productId) {
        return items.removeIf(item -> item.getProductId().equals(productId));
    }

    public int getItemCount() {
        return items.size();
    }

    public double computeSubtotal() {
        double sum = 0;
        for (LineItem item : items) {
            sum += item.getTotal();
        }
        return sum;
    }

    public String getStatusMessage() {
        if (processed) {
            return "Invoice " + invoiceId + " finalized. Total: $" + String.format("%.2f", grandTotal);
        } else {
            return "Invoice " + invoiceId + " pending. Items: " + getItemCount();
        }
    }
}