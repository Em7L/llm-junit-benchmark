package com.invoice;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Setup components
        DiscountEngine discountEngine = new DiscountEngine();
        TaxCalculator taxCalculator = new TaxCalculator();
        InvoiceValidator validator = new InvoiceValidator();
        InvoiceFormatter formatter = new InvoiceFormatter();
        InvoiceService service = new InvoiceService(discountEngine, taxCalculator, validator, formatter);

        // Create customer
        Customer customer = new Customer("C001", "John Doe", Customer.Tier.GOLD, "DOMESTIC");

        // Create invoice with line items
        Invoice invoice = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        invoice.addLineItem(new LineItem("P001", "Widget", 3, 25.00));
        invoice.addLineItem(new LineItem("P002", "Gadget", 1, 150.00));
        invoice.addLineItem(new LineItem("P003", "Doodad", 5, 10.50));

        // Process invoice
        try {
            Invoice processed = service.processInvoice(invoice, customer);
            System.out.println(formatter.format(processed));
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }

        // Demonstrate multi-invoice processing
        Invoice invoice2 = new Invoice("INV-002", customer, "DOMESTIC", LocalDate.now());
        invoice2.addLineItem(new LineItem("P004", "Thing", 2, 500.00));
        List<Invoice> invoices = Arrays.asList(invoice, invoice2);
        List<Invoice> processedList = service.processInvoices(invoices, customer);
        String report = service.generateReport(processedList);
        System.out.println(report);
        System.out.println("Net revenue: $" + String.format("%.2f", service.calculateNetRevenue(processedList)));
    }
}