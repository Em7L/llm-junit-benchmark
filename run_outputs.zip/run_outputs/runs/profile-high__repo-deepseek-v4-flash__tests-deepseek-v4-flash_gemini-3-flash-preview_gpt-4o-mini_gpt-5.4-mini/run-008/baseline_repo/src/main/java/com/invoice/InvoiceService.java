package com.invoice;

import java.util.ArrayList;
import java.util.List;

public class InvoiceService {
    private final DiscountEngine discountEngine;
    private final TaxCalculator taxCalculator;
    private final InvoiceValidator validator;
    private final InvoiceFormatter formatter;

    public InvoiceService(DiscountEngine discountEngine, TaxCalculator taxCalculator,
                          InvoiceValidator validator, InvoiceFormatter formatter) {
        this.discountEngine = discountEngine;
        this.taxCalculator = taxCalculator;
        this.validator = validator;
        this.formatter = formatter;
    }

    public Invoice processInvoice(Invoice invoice, Customer customer) {
        List<String> errors = validator.validate(invoice, customer);
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException("Validation failed: " + String.join("; ", errors));
        }

        double subtotal = invoice.computeSubtotal();
        double discount = discountEngine.calculateDiscount(invoice, customer);
        double tax = taxCalculator.calculateTax(invoice, invoice.getRegion());
        double grandTotal = subtotal - discount + tax;
        if (grandTotal < 0) grandTotal = 0;

        invoice.setSubtotal(subtotal);
        invoice.setDiscount(discount);
        invoice.setTax(tax);
        invoice.setGrandTotal(grandTotal);
        invoice.setProcessed(true);
        return invoice;
    }

    public List<Invoice> processInvoices(List<Invoice> invoices, Customer customer) {
        List<Invoice> processed = new ArrayList<>();
        for (Invoice inv : invoices) {
            if (validator.isValid(inv, customer)) {
                try {
                    processInvoice(inv, customer);
                    processed.add(inv);
                } catch (IllegalArgumentException e) {
                    // skip invalid ones
                }
            }
        }
        return processed;
    }

    public String generateReport(List<Invoice> invoices) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Invoice Report ===\n");
        for (Invoice inv : invoices) {
            sb.append(formatter.formatSummary(inv)).append("\n");
        }
        sb.append("Total invoices: ").append(invoices.size());
        return sb.toString();
    }

    public double calculateNetRevenue(List<Invoice> invoices) {
        double total = 0;
        for (Invoice inv : invoices) {
            total += inv.getGrandTotal();
        }
        return total;
    }
}