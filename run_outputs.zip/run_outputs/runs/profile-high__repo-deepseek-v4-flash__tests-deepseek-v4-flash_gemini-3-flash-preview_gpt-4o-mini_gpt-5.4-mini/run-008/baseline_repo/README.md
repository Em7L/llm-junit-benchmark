# Invoice Processing App

A simple Java application for processing invoices with discounts, taxes, and validation.

## Complexity Summary
- Number of classes: 9 (Customer, LineItem, Invoice, DiscountEngine, TaxCalculator, InvoiceValidator, InvoiceFormatter, InvoiceService, Main)
- Total public methods: 25
- Methods with >=3 branches: 5 (DiscountEngine.calculateDiscount, InvoiceValidator.validate, InvoiceFormatter.format, TaxCalculator.calculateTax, InvoiceService.processInvoices)
- Class descriptions:
  - Customer: Represents a customer with tier and region, provides discount multiplier.
  - LineItem: Represents a product line, calculates total price.
  - Invoice: Holds invoice data, provides status message based on processing state.
  - DiscountEngine: Applies tier, volume, and region-based discounts with caps.
  - TaxCalculator: Computes tax based on region with rates.
  - InvoiceValidator: Validates invoice fields, returns list of errors.
  - InvoiceFormatter: Formats invoice into readable strings.
  - InvoiceService: Orchestrates processing, validation, and reporting.
  - Main: Entry point demonstrating the workflow.