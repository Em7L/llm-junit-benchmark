# Model Comparison Report

- Repository model: `deepseek-v4-flash`
- Benchmark profile: `high`
- Complexity: `high`
- Baseline repository: `run_outputs/runs/profile-high__repo-deepseek-v4-flash__tests-deepseek-v4-flash_gemini-3-flash-preview_gpt-4o-mini_gpt-5.4-mini/run-008/baseline_repo`

## Generation And Repair Summary

| Test model | Generation | Repair | Repair tries |
|---|---:|---:|---:|
| gpt-5.4-mini | passed | repair_successful | 1 |
| deepseek-v4-flash | passed | repair_partially_improved | 1 |
| gemini-3-flash-preview | passed | repair_partially_improved | 1 |
| gpt-4o-mini | passed | repair_not_needed | 0 |

## Initial Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | test_failures | 24 | 4 | 1 | 74.80% | 77.54% | 156 | 108 | 21 | 27 | 69.23% |
| deepseek-v4-flash | test_failures | 87 | 8 | 11 | 77.17% | 79.71% | N/A | N/A | N/A | N/A | N/A |
| gemini-3-flash-preview | test_failures | 18 | 4 | 0 | 61.02% | 61.59% | 156 | 83 | 27 | 46 | 53.21% |
| gpt-4o-mini | passed | 8 | 0 | 0 | 7.87% | 10.14% | 156 | 11 | 0 | 145 | 7.05% |

## Final Evaluated Test Suite

| Test model | Status | Tests | Test Failures | Test Errors | Line cov. | Branch cov. | Mutations | Killed | Survived | No coverage | Mutation score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| gpt-5.4-mini | passed | 24 | 0 | 0 | 86.61% | 87.68% | 156 | 121 | 21 | 14 | 77.56% |
| deepseek-v4-flash | test_failures | 82 | 1 | 0 | 87.40% | 89.86% | 156 | 136 | 12 | 8 | 87.18% |
| gemini-3-flash-preview | test_failures | 18 | 1 | 0 | 66.54% | 63.77% | 156 | 105 | 16 | 35 | 67.31% |
| gpt-4o-mini | passed | 8 | 0 | 0 | 7.87% | 10.14% | 156 | 11 | 0 | 145 | 7.05% |

## Mutant Set Consistency
- Comparable PIT suites: `6`
- Identical mutant IDs across suites: `True`
- Common mutant IDs: `156`
- Union mutant IDs: `156`
- `_final_selected/deepseek-v4-flash` mutant IDs: `156`
- `_final_selected/gemini-3-flash-preview` mutant IDs: `156`
- `_final_selected/gpt-4o-mini` mutant IDs: `156`
- `_final_selected/gpt-5.4-mini` mutant IDs: `156`
- `_initial_snapshot/gemini-3-flash-preview` mutant IDs: `156`
- `_initial_snapshot/gpt-5.4-mini` mutant IDs: `156`

## Classification Definitions
- `generation=passed`: The test-generation step produced a generated test suite that the pipeline accepted for downstream evaluation.
- `repair_successful`: One or more repair attempts were applied and the final generated test suite passed verification.
- `repair_partially_improved`: One or more repair attempts improved the verification outcome, but the final generated test suite still did not pass verification.
- `repair_not_needed`: The initial generated test suite already passed verification, so no repair attempt was needed.
- `maven_status=test_failures`: The tests compiled and ran, but at least one test assertion failed.
- `maven_status=passed`: The Maven validation run completed successfully with no remaining failing or errored tests.
- `disabling_not_needed`: No baseline-failing generated tests had to be disabled before mutation evaluation.
- `disabling_applied_successful`: Disabling baseline-failing generated tests resulted in a passing final evaluated test suite.