package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceServiceTest {

    private InvoiceService newService() {
        return new InvoiceService(new DiscountEngine(), new TaxCalculator(), new InvoiceValidator(), new InvoiceFormatter());
    }

    private Customer customer() {
        return new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
    }

    private Invoice invoice(String id, double price, int quantity) {
        Invoice invoice = new Invoice(id, customer(), "DOMESTIC", LocalDate.now());
        invoice.addLineItem(new LineItem("P1", "Widget", quantity, price));
        return invoice;
    }

    @Test
    void processInvoicePopulatesComputedFieldsAndMarksProcessed() {
        InvoiceService service = newService();
        Invoice invoice = invoice("INV-1", 100.0, 3);

        Invoice processed = service.processInvoice(invoice, customer());

        assertSame(invoice, processed);
        assertEquals(300.0, processed.getSubtotal(), 1e-9);
        assertEquals(15.0, processed.getDiscount(), 1e-9);
        assertEquals(21.0, processed.getTax(), 1e-9);
        assertEquals(306.0, processed.getGrandTotal(), 1e-9);
        assertTrue(processed.isProcessed());
    }

    @Test
    void processInvoiceRejectsValidationFailures() {
        InvoiceService service = newService();
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now());

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.processInvoice(invoice, customer()));
        assertTrue(ex.getMessage().contains("Validation failed:"));
        assertTrue(ex.getMessage().contains("Invoice must have at least one line item"));
    }

    @Test
    void processInvoicesSkipsInvalidInvoicesAndGeneratesReports() {
        InvoiceService service = newService();
        Invoice valid = invoice("INV-1", 200.0, 3);
        Invoice invalid = new Invoice("INV-2", customer(), "DOMESTIC", LocalDate.now());
        Invoice valid2 = invoice("INV-3", 500.0, 1);

        List<Invoice> processed = service.processInvoices(List.of(valid, invalid, valid2), customer());

        assertEquals(2, processed.size());
        assertEquals(List.of(valid, valid2), processed);
        assertTrue(processed.stream().allMatch(Invoice::isProcessed));

        String report = service.generateReport(processed);
        assertTrue(report.startsWith("=== Invoice Report ==="));
        assertTrue(report.contains("Invoice INV-1"));
        assertTrue(report.contains("Invoice INV-3"));
        assertTrue(report.endsWith("Total invoices: 2"));

        double revenue = service.calculateNetRevenue(processed);
        assertEquals(valid.getGrandTotal() + valid2.getGrandTotal(), revenue, 1e-9);
    }
}
