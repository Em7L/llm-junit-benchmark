package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class TaxCalculatorTest {

    private final TaxCalculator calculator = new TaxCalculator();

    private Invoice invoice(double unitPrice, int quantity, String region) {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, region);
        Invoice invoice = new Invoice("INV-1", customer, region, LocalDate.now());
        invoice.addLineItem(new LineItem("P1", "Item", quantity, unitPrice));
        return invoice;
    }

    @Test
    void calculatesTaxForEachKnownRegionAndDefaultsToZero() {
        assertEquals(7.0, calculator.calculateTax(invoice(100.0, 1, "DOMESTIC"), "DOMESTIC"), 1e-9);
        assertEquals(5.0, calculator.calculateTax(invoice(100.0, 1, "INTERNATIONAL"), "INTERNATIONAL"), 1e-9);
        assertEquals(10.0, calculator.calculateTax(invoice(100.0, 1, "SPECIAL"), "SPECIAL"), 1e-9);
        assertEquals(0.0, calculator.calculateTax(invoice(100.0, 1, "OTHER"), "OTHER"), 1e-9);
    }

    @Test
    void regionLookupIsCaseInsensitive() {
        assertEquals(7.0, calculator.calculateTax(invoice(100.0, 1, "DOMESTIC"), "domestic"), 1e-9);
        assertEquals(5.0, calculator.calculateTax(invoice(100.0, 1, "INTERNATIONAL"), "International"), 1e-9);
    }

    @Test
    void isTaxExemptReturnsFalseForNonEmptyInvoicesAndTrueWhenEmpty() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        Invoice empty = new Invoice("INV-EMPTY", customer, "DOMESTIC", LocalDate.now());
        assertTrue(calculator.isTaxExempt(empty));

        Invoice invoice = invoice(50.0, 1, "DOMESTIC");
        assertFalse(calculator.isTaxExempt(invoice));

        Invoice expensive = invoice(1500.0, 1, "DOMESTIC");
        assertFalse(calculator.isTaxExempt(expensive));
    }
}
