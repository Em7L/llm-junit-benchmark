package com.invoice;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LineItemTest {

    @Test
    void constructorRejectsInvalidProductQuantityAndPrice() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(null, "Desc", 1, 1.0));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("", "Desc", 1, 1.0));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("P1", "Desc", 0, 1.0));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("P1", "Desc", -1, 1.0));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("P1", "Desc", 1, -0.01));
    }

    @Test
    void descriptionDefaultsToEmptyStringAndTotalIsComputed() {
        LineItem item = new LineItem("P1", null, 3, 12.5);
        assertEquals("P1", item.getProductId());
        assertEquals("", item.getDescription());
        assertEquals(3, item.getQuantity());
        assertEquals(12.5, item.getUnitPrice(), 1e-9);
        assertEquals(37.5, item.getTotal(), 1e-9);
    }

    @Test
    void settersRejectInvalidValuesAndAcceptValidUpdates() {
        LineItem item = new LineItem("P1", "Widget", 2, 10.0);

        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(-3));
        assertThrows(IllegalArgumentException.class, () -> item.setUnitPrice(-1.0));

        item.setQuantity(5);
        item.setUnitPrice(12.0);

        assertEquals(5, item.getQuantity());
        assertEquals(12.0, item.getUnitPrice(), 1e-9);
        assertEquals(60.0, item.getTotal(), 1e-9);
    }
}
