package com.invoice;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorRejectsInvalidArguments() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(null, "Alice", Customer.Tier.GOLD, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "Alice", Customer.Tier.GOLD, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", null, Customer.Tier.GOLD, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "", Customer.Tier.GOLD, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Alice", null, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Alice", Customer.Tier.GOLD, null));
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Alice", Customer.Tier.GOLD, ""));
    }

    @Test
    void discountMultiplierMatchesTier() {
        assertEquals(0.0, new Customer("C1", "Bronze", Customer.Tier.BRONZE, "DOMESTIC").getDiscountMultiplier(), 1e-9);
        assertEquals(0.02, new Customer("C2", "Silver", Customer.Tier.SILVER, "DOMESTIC").getDiscountMultiplier(), 1e-9);
        assertEquals(0.05, new Customer("C3", "Gold", Customer.Tier.GOLD, "DOMESTIC").getDiscountMultiplier(), 1e-9);
        assertEquals(0.10, new Customer("C4", "Platinum", Customer.Tier.PLATINUM, "DOMESTIC").getDiscountMultiplier(), 1e-9);
    }

    @Test
    void highValueIsTrueOnlyForGoldAndPlatinum() {
        assertFalse(new Customer("C1", "Bronze", Customer.Tier.BRONZE, "DOMESTIC").isHighValue());
        assertFalse(new Customer("C2", "Silver", Customer.Tier.SILVER, "DOMESTIC").isHighValue());
        assertTrue(new Customer("C3", "Gold", Customer.Tier.GOLD, "DOMESTIC").isHighValue());
        assertTrue(new Customer("C4", "Platinum", Customer.Tier.PLATINUM, "DOMESTIC").isHighValue());
    }
}
