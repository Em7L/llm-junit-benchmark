package com.invoice;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceValidatorTest {

    private final InvoiceValidator validator = new InvoiceValidator();

    private Customer customer() {
        return new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
    }

    private Invoice invoiceWithOneItem() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now());
        invoice.addLineItem(new LineItem("P1", "Widget", 1, 10.0));
        return invoice;
    }

    @Test
    void validateReturnsSingleErrorForNullInvoice() {
        List<String> errors = validator.validate(null, customer());
        assertEquals(List.of("Invoice cannot be null"), errors);
        assertFalse(validator.isValid(null, customer()));
    }

    @Test
    void validateReportsMultipleFieldAndItemErrors() throws Exception {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now().minusDays(1));
        invoice.addLineItem(new LineItem("P1", "Widget", 1, 2.0));
        invoice.addLineItem(new LineItem("P2", "Widget 2", 1, 5.0));

        // Create invalid item state through reflection because the public API prevents it.
        LineItem first = invoice.getItems().get(0);
        Field quantityField = LineItem.class.getDeclaredField("quantity");
        quantityField.setAccessible(true);
        quantityField.setInt(first, 0);

        Field unitPriceField = LineItem.class.getDeclaredField("unitPrice");
        unitPriceField.setAccessible(true);
        unitPriceField.setDouble(first, -2.0);

        Customer validCustomer = customer();
        List<String> errors = validator.validate(invoice, validCustomer);

        assertTrue(errors.contains("Line item quantity must be positive (product: P1)"));
        assertTrue(errors.contains("Line item unit price cannot be negative (product: P1)"));
        assertFalse(errors.contains("Customer cannot be null"));
        assertFalse(errors.contains("Invoice date cannot be in the future"));
        assertTrue(validator.isValid(invoiceWithOneItem(), customer()));
    }

    @Test
    void validateRejectsFutureDateMissingItemsAndMissingRegion() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now().plusDays(1));
        List<String> errors = validator.validate(invoice, customer());
        assertTrue(errors.contains("Invoice must have at least one line item"));
        assertTrue(errors.contains("Invoice date cannot be in the future"));
    }

    @Test
    void validateFlagsNullCustomerAndMissingInvoiceFields() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        Invoice invoice = new Invoice("INV-1", customer, "DOMESTIC", LocalDate.now());
        invoice.addLineItem(new LineItem("P1", "Widget", 1, 10.0));

        List<String> errors = validator.validate(invoice, null);
        assertTrue(errors.contains("Customer cannot be null"));
    }
}
