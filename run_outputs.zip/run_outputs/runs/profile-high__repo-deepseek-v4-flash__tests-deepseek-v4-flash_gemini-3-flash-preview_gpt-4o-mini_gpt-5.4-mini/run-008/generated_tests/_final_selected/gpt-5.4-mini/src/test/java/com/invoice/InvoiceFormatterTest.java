package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceFormatterTest {

    private Invoice invoice() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        Invoice invoice = new Invoice("INV-1", customer, "DOMESTIC", LocalDate.of(2025, 1, 15));
        invoice.addLineItem(new LineItem("P1", "Widget", 2, 10.0));
        invoice.addLineItem(new LineItem("P2", "", 1, 5.5));
        invoice.setSubtotal(25.5);
        invoice.setDiscount(2.5);
        invoice.setTax(1.61);
        invoice.setGrandTotal(24.61);
        return invoice;
    }

    @Test
    void formatReturnsExpectedMultiLineOutput() {
        InvoiceFormatter formatter = new InvoiceFormatter();
        String formatted = formatter.format(invoice());

        assertTrue(formatted.contains("Invoice: INV-1"));
        assertTrue(formatted.contains("Customer: Alice"));
        assertTrue(formatted.contains("Date: 2025-01-15"));
        assertTrue(formatted.contains("Region: DOMESTIC"));
        assertTrue(formatted.contains(formatter.formatLineItem(new LineItem("P1", "Widget", 2, 10.0))));
        assertTrue(formatted.contains(formatter.formatLineItem(new LineItem("P2", "", 1, 5.5))));
        assertTrue(formatted.contains(String.format("Subtotal: $%.2f", 25.5)));
        assertTrue(formatted.contains(String.format("Discount: -$%.2f", 2.5)));
        assertTrue(formatted.contains(String.format("Tax: +$%.2f", 1.61)));
        assertTrue(formatted.contains(String.format("Total: $%.2f", 24.61)));
    }

    @Test
    void formatHandlesNullsAndSummaryUsesGrandTotal() {
        InvoiceFormatter formatter = new InvoiceFormatter();
        assertEquals("No invoice data.", formatter.format(null));
        assertEquals("", formatter.formatLineItem(null));
        assertEquals(String.format("Invoice INV-1: 2 items, total $%.2f", 24.61), formatter.formatSummary(invoice()));
    }
}
