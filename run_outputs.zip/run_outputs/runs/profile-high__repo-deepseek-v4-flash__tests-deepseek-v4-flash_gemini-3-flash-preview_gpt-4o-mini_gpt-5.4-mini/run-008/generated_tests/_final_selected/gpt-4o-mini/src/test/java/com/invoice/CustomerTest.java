package com.invoice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class CustomerTest {

    @Test
    void createsCustomerSuccessfully() {
        Customer customer = new Customer("C001", "John Doe", Customer.Tier.GOLD, "DOMESTIC");
        assertEquals("C001", customer.getId());
        assertEquals("John Doe", customer.getName());
        assertEquals(Customer.Tier.GOLD, customer.getTier());
        assertEquals("DOMESTIC", customer.getRegion());
    }

    @Test
    void rejectsNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(null, "John Doe", Customer.Tier.GOLD, "DOMESTIC"));
    }

    @Test
    void rejectsEmptyId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "John Doe", Customer.Tier.GOLD, "DOMESTIC"));
    }

    @Test
    void rejectsNullName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", null, Customer.Tier.GOLD, "DOMESTIC"));
    }

    @Test
    void rejectsEmptyName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "", Customer.Tier.GOLD, "DOMESTIC"));
    }

    @Test
    void rejectsNullTier() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "John Doe", null, "DOMESTIC"));
    }

    @Test
    void rejectsNullRegion() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "John Doe", Customer.Tier.GOLD, null));
    }

    @Test
    void rejectsEmptyRegion() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C001", "John Doe", Customer.Tier.GOLD, ""));
    }
}