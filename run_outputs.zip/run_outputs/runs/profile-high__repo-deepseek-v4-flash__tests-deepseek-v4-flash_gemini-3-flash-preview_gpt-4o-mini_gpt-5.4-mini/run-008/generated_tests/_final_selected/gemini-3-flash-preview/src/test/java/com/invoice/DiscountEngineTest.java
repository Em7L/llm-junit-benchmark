package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {
    private final DiscountEngine engine = new DiscountEngine();

    @Test
    void calculateDiscountAppliesTierAndVolume() {
        Customer customer = new Customer("C1", "Name", Customer.Tier.SILVER, "DOMESTIC");
        Invoice invoice = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        // 6 items to trigger volume discount (+2%)
        for (int i = 0; i < 6; i++) {
            invoice.addLineItem(new LineItem("P" + i, "Desc", 1, 100.0));
        }
        // Subtotal = 600. Silver = 2%. Volume = 2%. Total = 4% of 600 = 24.0
        double discount = engine.calculateDiscount(invoice, customer);
        assertEquals(24.0, discount, 0.001);
    }

    @Test
    void calculateDiscountCapsAtFifteenPercent() {
        Customer customer = new Customer("C1", "Name", Customer.Tier.PLATINUM, "INTERNATIONAL");
        // Note: The engine checks region on customer via "INTERNATIONAL" and region on invoice is irrelevant for caps but relevant for promotions.
        // Subtotal must be > 1000 for large order discount.
        Invoice invoice = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        
        // Item count > 5 for volume discount (2%)
        for (int i = 0; i < 6; i++) {
            invoice.addLineItem(new LineItem("P" + i, "S", 1, 400.0));
        }
        // Subtotal = 2400.0
        // Platinum (10%) + Volume (2%) + Large order (5%) + Intl (3%) = 20% potential
        // Cap is 15% of subtotal: 2400 * 0.15 = 360.0
        
        double discount = engine.calculateDiscount(invoice, customer);
        assertEquals(360.0, discount, 0.001);
    }

    @Test
    void qualifiesForPromotionChecksConditions() {
        Customer c = new Customer("C1", "N", Customer.Tier.BRONZE, "DOMESTIC");
        Invoice inv = new Invoice("I1", c, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "D", 1, 600.0));
        // Not enough items (need 3)
        assertFalse(engine.qualifiesForPromotion(inv));

        inv.addLineItem(new LineItem("P2", "D", 1, 1.0));
        inv.addLineItem(new LineItem("P3", "D", 1, 1.0));
        // Domestic, 3 items, > 500 subtotal
        assertTrue(engine.qualifiesForPromotion(inv));

        // International region fails
        Invoice intlInv = new Invoice("I2", c, "INTERNATIONAL", LocalDate.now());
        intlInv.addLineItem(new LineItem("P1", "D", 3, 200.0));
        assertFalse(engine.qualifiesForPromotion(intlInv));
    }
}