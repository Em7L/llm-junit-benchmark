package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Locale;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceFormatterTest {
    private final InvoiceFormatter formatter = new InvoiceFormatter();

    @Test
    void formatSummaryCreatesCorrectString() {
        // Set Locale to US to ensure decimal separator is '.' regardless of environment
        Locale.setDefault(Locale.US);
        Customer c = new Customer("C1", "N", Customer.Tier.BRONZE, "DOMESTIC");
        Invoice inv = new Invoice("INV-X", c, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "D", 1, 10.0));
        inv.setGrandTotal(10.70);

        String summary = formatter.formatSummary(inv);
        assertEquals("Invoice INV-X: 1 items, total $10.70", summary);
    }

    @Test
    void formatLineItemHandlesMissingDescription() {
        Locale.setDefault(Locale.US);
        LineItem item = new LineItem("P99", null, 2, 5.0);
        String formatted = formatter.formatLineItem(item);
        // LineItem constructor sets description to "" if null.
        // formatLineItem uses productId if description isEmpty.
        // "  P99 x2 @ $5.00 = $10.00"
        assertTrue(formatted.contains("P99 x2 @ $5.00 = $10.00"));
    }

    @Test
    void formatReturnsPlaceholderForNull() {
        assertEquals("No invoice data.", formatter.format(null));
    }
}