package com.invoice;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorThrowsExceptionOnInvalidInput() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(null, "Name", Customer.Tier.BRONZE, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("ID", "", Customer.Tier.BRONZE, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("ID", "Name", null, "DOMESTIC"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("ID", "Name", Customer.Tier.BRONZE, null));
    }

    @Test
    void getDiscountMultiplierReturnsCorrectValues() {
        Customer p = new Customer("1", "N", Customer.Tier.PLATINUM, "R");
        Customer g = new Customer("2", "N", Customer.Tier.GOLD, "R");
        Customer s = new Customer("3", "N", Customer.Tier.SILVER, "R");
        Customer b = new Customer("4", "N", Customer.Tier.BRONZE, "R");

        assertEquals(0.10, p.getDiscountMultiplier());
        assertEquals(0.05, g.getDiscountMultiplier());
        assertEquals(0.02, s.getDiscountMultiplier());
        assertEquals(0.0, b.getDiscountMultiplier());
    }

    @Test
    void isHighValueReturnsTrueOnlyForGoldAndPlatinum() {
        assertTrue(new Customer("1", "N", Customer.Tier.PLATINUM, "R").isHighValue());
        assertTrue(new Customer("2", "N", Customer.Tier.GOLD, "R").isHighValue());
        assertFalse(new Customer("3", "N", Customer.Tier.SILVER, "R").isHighValue());
        assertFalse(new Customer("4", "N", Customer.Tier.BRONZE, "R").isHighValue());
    }
}