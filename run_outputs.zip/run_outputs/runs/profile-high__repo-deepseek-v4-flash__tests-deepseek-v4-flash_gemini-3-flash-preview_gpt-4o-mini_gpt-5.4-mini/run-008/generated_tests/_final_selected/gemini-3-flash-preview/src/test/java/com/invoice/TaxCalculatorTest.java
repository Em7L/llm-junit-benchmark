package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class TaxCalculatorTest {
    private final TaxCalculator calculator = new TaxCalculator();

    @Test
    void calculateTaxVariesByRegion() {
        Customer c = new Customer("C1", "N", Customer.Tier.BRONZE, "DOMESTIC");
        Invoice inv = new Invoice("I1", c, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "D", 1, 100.0));

        assertEquals(7.0, calculator.calculateTax(inv, "DOMESTIC"), 0.001);
        assertEquals(5.0, calculator.calculateTax(inv, "INTERNATIONAL"), 0.001);
        assertEquals(10.0, calculator.calculateTax(inv, "SPECIAL"), 0.001);
        assertEquals(0.0, calculator.calculateTax(inv, "UNKNOWN"), 0.001);
    }

    @Test
    void isTaxExemptLogic() {
        Customer c = new Customer("C1", "N", Customer.Tier.BRONZE, "DOMESTIC");
        Invoice inv = new Invoice("I1", c, "DOMESTIC", LocalDate.now());
        
        // Empty invoice is exempt
        assertTrue(calculator.isTaxExempt(inv));

        // Normal items not exempt
        inv.addLineItem(new LineItem("P1", "D", 1, 100.0));
        assertFalse(calculator.isTaxExempt(inv));

        // High value low qty is not exempt (returns false)
        Invoice inv2 = new Invoice("I2", c, "DOMESTIC", LocalDate.now());
        inv2.addLineItem(new LineItem("P2", "Expensive", 1, 1500.0));
        assertFalse(calculator.isTaxExempt(inv2));
    }
}