package com.invoice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void constructorRejectsNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer(null, "Name", Customer.Tier.BRONZE, "DOMESTIC"));
    }

    @Test
    void constructorRejectsEmptyId() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("", "Name", Customer.Tier.BRONZE, "DOMESTIC"));
    }

    @Test
    void constructorRejectsNullName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", null, Customer.Tier.BRONZE, "DOMESTIC"));
    }

    @Test
    void constructorRejectsEmptyName() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "", Customer.Tier.BRONZE, "DOMESTIC"));
    }

    @Test
    void constructorRejectsNullTier() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Name", null, "DOMESTIC"));
    }

    @Test
    void constructorRejectsNullRegion() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Name", Customer.Tier.BRONZE, null));
    }

    @Test
    void constructorRejectsEmptyRegion() {
        assertThrows(IllegalArgumentException.class, () -> new Customer("C1", "Name", Customer.Tier.BRONZE, ""));
    }

    @Test
    void constructorValid() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        assertNotNull(c);
    }

    @Test
    void getDiscountMultiplierBronze() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.BRONZE, "DOMESTIC");
        assertEquals(0.0, c.getDiscountMultiplier());
    }

    @Test
    void getDiscountMultiplierSilver() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.SILVER, "DOMESTIC");
        assertEquals(0.02, c.getDiscountMultiplier());
    }

    @Test
    void getDiscountMultiplierGold() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        assertEquals(0.05, c.getDiscountMultiplier());
    }

    @Test
    void getDiscountMultiplierPlatinum() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.PLATINUM, "DOMESTIC");
        assertEquals(0.10, c.getDiscountMultiplier());
    }

    @Test
    void isHighValueTrueForPlatinum() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.PLATINUM, "DOMESTIC");
        assertTrue(c.isHighValue());
    }

    @Test
    void isHighValueTrueForGold() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        assertTrue(c.isHighValue());
    }

    @Test
    void isHighValueFalseForSilver() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.SILVER, "DOMESTIC");
        assertFalse(c.isHighValue());
    }

    @Test
    void isHighValueFalseForBronze() {
        Customer c = new Customer("C1", "Alice", Customer.Tier.BRONZE, "DOMESTIC");
        assertFalse(c.isHighValue());
    }
}
