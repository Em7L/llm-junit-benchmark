package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceValidatorTest {

    private InvoiceValidator validator = new InvoiceValidator();
    private Customer validCustomer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");

    @Test
    void validateNullInvoice() {
        List<String> errors = validator.validate(null, validCustomer);
        assertTrue(errors.contains("Invoice cannot be null"));
        assertEquals(1, errors.size());
    }

    @Test
    void validateNullCustomer() {
        Invoice inv = new Invoice("I1", validCustomer, "DOMESTIC", LocalDate.now());
        List<String> errors = validator.validate(inv, null);
        assertTrue(errors.contains("Customer cannot be null"));
    }

    @Test
    void validateNoLineItems() {
        Invoice inv = new Invoice("I1", validCustomer, "DOMESTIC", LocalDate.now());
        List<String> errors = validator.validate(inv, validCustomer);
        assertTrue(errors.contains("Invoice must have at least one line item"));
    }

    @Test
    void validateFutureDate() {
        Invoice inv = new Invoice("I1", validCustomer, "DOMESTIC", LocalDate.now().plusDays(1));
        inv.addLineItem(new LineItem("P1", "", 1, 10.0));
        List<String> errors = validator.validate(inv, validCustomer);
        assertTrue(errors.contains("Invoice date cannot be in the future"));
    }

    @Test
    void validateValidInvoiceReturnsNoErrors() {
        Invoice inv = new Invoice("I1", validCustomer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 10.0));
        List<String> errors = validator.validate(inv, validCustomer);
        assertTrue(errors.isEmpty());
    }

    @Test
    void isValidReturnsTrueForValidInvoice() {
        Invoice inv = new Invoice("I1", validCustomer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 10.0));
        assertTrue(validator.isValid(inv, validCustomer));
    }

    @Test
    void isValidReturnsFalseForInvalidInvoice() {
        Invoice inv = new Invoice("I1", validCustomer, "DOMESTIC", LocalDate.now());
        assertFalse(validator.isValid(inv, validCustomer));
    }
}
