package com.invoice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LineItemTest {

    @Test
    void constructorRejectsNullProductId() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(null, "desc", 1, 10.0));
    }

    @Test
    void constructorRejectsEmptyProductId() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem("", "desc", 1, 10.0));
    }

    @Test
    void constructorRejectsNonPositiveQuantity() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem("P1", "desc", 0, 10.0));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("P1", "desc", -1, 10.0));
    }

    @Test
    void constructorRejectsNegativeUnitPrice() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem("P1", "desc", 1, -0.01));
    }

    @Test
    void constructorAcceptsZeroUnitPrice() {
        LineItem item = new LineItem("P1", "desc", 1, 0.0);
        assertEquals(0.0, item.getUnitPrice());
    }

    @Test
    void getTotalCalculatesCorrectly() {
        LineItem item = new LineItem("P1", "Product", 3, 4.99);
        assertEquals(14.97, item.getTotal(), 1e-9);
    }

    @Test
    void descriptionDefaultsToEmpty() {
        LineItem item = new LineItem("P1", null, 1, 10.0);
        assertEquals("", item.getDescription());
    }

    @Test
    void setQuantityValid() {
        LineItem item = new LineItem("P1", "desc", 1, 10.0);
        item.setQuantity(5);
        assertEquals(5, item.getQuantity());
    }

    @Test
    void setQuantityRejectsNonPositive() {
        LineItem item = new LineItem("P1", "desc", 1, 10.0);
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(0));
        assertThrows(IllegalArgumentException.class, () -> item.setQuantity(-1));
    }

    @Test
    void setUnitPriceValid() {
        LineItem item = new LineItem("P1", "desc", 1, 10.0);
        item.setUnitPrice(15.5);
        assertEquals(15.5, item.getUnitPrice());
    }

    @Test
    void setUnitPriceRejectsNegative() {
        LineItem item = new LineItem("P1", "desc", 1, 10.0);
        assertThrows(IllegalArgumentException.class, () -> item.setUnitPrice(-1.0));
    }
}
