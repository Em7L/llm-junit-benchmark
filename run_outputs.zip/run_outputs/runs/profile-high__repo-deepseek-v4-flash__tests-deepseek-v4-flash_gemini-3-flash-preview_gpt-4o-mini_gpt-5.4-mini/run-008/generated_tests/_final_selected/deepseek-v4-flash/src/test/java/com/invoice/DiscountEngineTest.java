package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private DiscountEngine engine = new DiscountEngine();
    private Customer domesticPlatinum = new Customer("C1", "Alice", Customer.Tier.PLATINUM, "DOMESTIC");
    private Customer domesticGold = new Customer("C2", "Bob", Customer.Tier.GOLD, "DOMESTIC");
    private Customer domesticSilver = new Customer("C3", "Charlie", Customer.Tier.SILVER, "DOMESTIC");
    private Customer domesticBronze = new Customer("C4", "David", Customer.Tier.BRONZE, "DOMESTIC");
    private Customer internationalPlatinum = new Customer("C5", "Eve", Customer.Tier.PLATINUM, "INTERNATIONAL");

    @Test
    void tierDiscountOnlyPlatinum() {
        Invoice inv = new Invoice("I1", domesticPlatinum, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double discount = engine.calculateDiscount(inv, domesticPlatinum);
        assertEquals(10.0, discount, 1e-9);
    }

    @Test
    void tierDiscountGold() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 200.0));
        double discount = engine.calculateDiscount(inv, domesticGold);
        assertEquals(10.0, discount, 1e-9);
    }

    @Test
    void tierDiscountSilver() {
        Invoice inv = new Invoice("I1", domesticSilver, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double discount = engine.calculateDiscount(inv, domesticSilver);
        assertEquals(2.0, discount, 1e-9);
    }

    @Test
    void tierDiscountBronze() {
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double discount = engine.calculateDiscount(inv, domesticBronze);
        assertEquals(0.0, discount, 1e-9);
    }

    @Test
    void volumeDiscountAppliesWhenMoreThan5Items() {
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        for (int i = 0; i < 6; i++) {
            inv.addLineItem(new LineItem("P"+i, "", 1, 100.0));
        }
        double discount = engine.calculateDiscount(inv, domesticBronze);
        assertEquals(12.0, discount, 1e-9);
    }

    @Test
    void volumeDiscountDoesNotApplyExactly5Items() {
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        for (int i = 0; i < 5; i++) {
            inv.addLineItem(new LineItem("P"+i, "", 1, 100.0));
        }
        double discount = engine.calculateDiscount(inv, domesticBronze);
        assertEquals(0.0, discount, 1e-9);
    }

    @Test
    void largeOrderDiscountBelowCap() {
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 1100.0));
        double discount = engine.calculateDiscount(inv, domesticBronze);
        assertEquals(55.0, discount, 1e-9);
    }

    @Test
    void largeOrderDiscountCapped() {
        Invoice inv = new Invoice("I1", domesticPlatinum, "DOMESTIC", LocalDate.now());
        for (int i = 0; i < 6; i++) {
            inv.addLineItem(new LineItem("P"+i, "", 1, 200.0));
        }
        double discount = engine.calculateDiscount(inv, domesticPlatinum);
        assertEquals(180.0, discount, 1e-9);
    }

    @Test
    void internationalDiscountExtra3Percent() {
        Invoice inv = new Invoice("I1", internationalPlatinum, "INTERNATIONAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double discount = engine.calculateDiscount(inv, internationalPlatinum);
        assertEquals(13.0, discount, 1e-9);
    }

    @Test
    void qualifiesForPromotionTrue() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 200.0));
        inv.addLineItem(new LineItem("P2", "", 1, 200.0));
        inv.addLineItem(new LineItem("P3", "", 1, 200.0));
        assertTrue(engine.qualifiesForPromotion(inv));
    }

    @Test
    void qualifiesForPromotionFalseItemCountLessThan3() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 2, 600.0));
        assertFalse(engine.qualifiesForPromotion(inv));
    }

    @Test
    void qualifiesForPromotionFalseSubtotalNotExceed500() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 100.0));
        assertFalse(engine.qualifiesForPromotion(inv));
    }

    @Test
    void qualifiesForPromotionFalseInternational() {
        Invoice inv = new Invoice("I1", internationalPlatinum, "INTERNATIONAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 200.0));
        assertFalse(engine.qualifiesForPromotion(inv));
    }
}
