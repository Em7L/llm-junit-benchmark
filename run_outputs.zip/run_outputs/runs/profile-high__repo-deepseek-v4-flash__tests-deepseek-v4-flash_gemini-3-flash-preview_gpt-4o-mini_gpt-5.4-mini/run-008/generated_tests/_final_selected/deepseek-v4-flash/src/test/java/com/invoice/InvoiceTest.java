package com.invoice;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Locale;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceTest {

    private Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");

    @BeforeAll
    static void setLocale() {
        Locale.setDefault(Locale.US);
    }

    @Test
    void constructorRejectsNullId() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice(null, customer, "DOMESTIC", LocalDate.now()));
    }

    @Test
    void constructorRejectsEmptyId() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice("", customer, "DOMESTIC", LocalDate.now()));
    }

    @Test
    void constructorRejectsNullCustomer() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV1", null, "DOMESTIC", LocalDate.now()));
    }

    @Test
    void constructorRejectsNullRegion() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV1", customer, null, LocalDate.now()));
    }

    @Test
    void constructorRejectsEmptyRegion() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV1", customer, "", LocalDate.now()));
    }

    @Test
    void constructorRejectsNullDate() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV1", customer, "DOMESTIC", null));
    }

    @Test
    void addLineItemNullThrows() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        assertThrows(IllegalArgumentException.class, () -> inv.addLineItem(null));
    }

    @Test
    void removeLineItemExisting() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "desc", 1, 10.0));
        assertTrue(inv.removeLineItem("P1"));
        assertEquals(0, inv.getItemCount());
    }

    @Test
    void removeLineItemNonExisting() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "desc", 1, 10.0));
        assertFalse(inv.removeLineItem("P2"));
        assertEquals(1, inv.getItemCount());
    }

    @Test
    void computeSubtotalEmptyInvoice() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        assertEquals(0.0, inv.computeSubtotal());
    }

    @Test
    void computeSubtotalWithItems() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "desc", 2, 10.0));
        inv.addLineItem(new LineItem("P2", "desc", 3, 5.5));
        assertEquals(2*10.0 + 3*5.5, inv.computeSubtotal(), 1e-9);
    }

    @Test
    void getStatusMessageWhenProcessed() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        inv.setProcessed(true);
        inv.setGrandTotal(123.45);
        String msg = inv.getStatusMessage();
        assertTrue(msg.contains("finalized"));
        assertTrue(msg.contains("123.45"));
    }

    @Test
    void getStatusMessageWhenNotProcessed() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        assertEquals("Invoice INV1 pending. Items: 0", inv.getStatusMessage());
    }

    @Test
    void getItemsReturnsUnmodifiable() {
        Invoice inv = new Invoice("INV1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "desc", 1, 10.0));
        assertThrows(UnsupportedOperationException.class, () -> inv.getItems().add(null));
    }
}
