package com.invoice;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Locale;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceFormatterTest {

    private InvoiceFormatter formatter = new InvoiceFormatter();
    private Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");

    @BeforeAll
    static void setLocale() {
        Locale.setDefault(Locale.US);
    }

    @Test
    void formatNullInvoice() {
        assertEquals("No invoice data.", formatter.format(null));
    }

    @Test
    void formatInvoiceWithItems() {
        Invoice inv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.of(2024, 1, 15));
        inv.addLineItem(new LineItem("P1", "Widget", 3, 25.0));
        inv.setSubtotal(75.0);
        inv.setDiscount(5.0);
        inv.setTax(7.0);
        inv.setGrandTotal(77.0);
        String result = formatter.format(inv);
        assertTrue(result.contains("INV-001"));
        assertTrue(result.contains("Alice"));
        assertTrue(result.contains("2024-01-15"));
        assertTrue(result.contains("Subtotal: $75.00"));
        assertTrue(result.contains("Discount: -$5.00"));
        assertTrue(result.contains("Tax: +$7.00"));
        assertTrue(result.contains("Total: $77.00"));
        assertTrue(result.contains("Widget"));
    }

    @Test
    void formatLineItemNull() {
        assertEquals("", formatter.formatLineItem(null));
    }

    @Test
    void formatLineItemWithDescription() {
        LineItem item = new LineItem("P1", "Widget", 3, 25.0);
        String result = formatter.formatLineItem(item);
        assertTrue(result.contains("Widget"));
        assertTrue(result.contains("3"));
        assertTrue(result.contains("25.00"));
        assertTrue(result.contains("75.00"));
    }

    @Test
    void formatLineItemWithoutDescription() {
        LineItem item = new LineItem("P1", "", 1, 10.0);
        String result = formatter.formatLineItem(item);
        assertTrue(result.contains("P1"));
    }

    @Test
    void formatSummary() {
        Invoice inv = new Invoice("INV-002", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 2, 30.0));
        inv.setGrandTotal(60.0);
        String summary = formatter.formatSummary(inv);
        assertTrue(summary.startsWith("Invoice INV-002:"));
        assertTrue(summary.contains("2 items"));
        assertTrue(summary.contains("60.00"));
    }
}
