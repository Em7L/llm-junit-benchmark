package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class TaxCalculatorTest {

    private TaxCalculator calculator = new TaxCalculator();
    private Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");

    @Test
    void calculateTaxDomestic() {
        Invoice inv = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double tax = calculator.calculateTax(inv, "DOMESTIC");
        assertEquals(7.0, tax, 1e-9);
    }

    @Test
    void calculateTaxInternational() {
        Invoice inv = new Invoice("I1", customer, "INTERNATIONAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double tax = calculator.calculateTax(inv, "INTERNATIONAL");
        assertEquals(5.0, tax, 1e-9);
    }

    @Test
    void calculateTaxSpecial() {
        Invoice inv = new Invoice("I1", customer, "SPECIAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double tax = calculator.calculateTax(inv, "SPECIAL");
        assertEquals(10.0, tax, 1e-9);
    }

    @Test
    void calculateTaxUnknownRegion() {
        Invoice inv = new Invoice("I1", customer, "UNKNOWN", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double tax = calculator.calculateTax(inv, "UNKNOWN");
        assertEquals(0.0, tax, 1e-9);
    }

    @Test
    void calculateTaxCaseInsensitive() {
        Invoice inv = new Invoice("I1", customer, "domestic", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double tax = calculator.calculateTax(inv, "domestic");
        assertEquals(7.0, tax, 1e-9);
    }

    @Test
    void isTaxExemptEmptyInvoice() {
        Invoice inv = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        assertTrue(calculator.isTaxExempt(inv));
    }

    @Test
    void isTaxExemptNonExempt() {
        Invoice inv = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 2, 1500.0));
        assertFalse(calculator.isTaxExempt(inv));
    }

    @Test
    void isTaxExemptExemptBecausePriceNotHigh() {
        Invoice inv = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 500.0));
        assertFalse(calculator.isTaxExempt(inv));
    }

    @Test
    void isTaxExemptExemptBecauseQuantityHigh() {
        Invoice inv = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 1500.0));
        assertFalse(calculator.isTaxExempt(inv));
    }
}
