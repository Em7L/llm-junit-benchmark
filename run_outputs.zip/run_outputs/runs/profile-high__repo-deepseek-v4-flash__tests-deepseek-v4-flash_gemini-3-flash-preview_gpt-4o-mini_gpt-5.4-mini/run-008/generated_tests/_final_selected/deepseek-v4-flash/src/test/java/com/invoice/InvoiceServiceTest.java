package com.invoice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceServiceTest {

    private DiscountEngine discountEngine;
    private TaxCalculator taxCalculator;
    private InvoiceValidator validator;
    private InvoiceFormatter formatter;
    private InvoiceService service;
    private Customer customer;

    @BeforeEach
    void setUp() {
        discountEngine = new DiscountEngine();
        taxCalculator = new TaxCalculator();
        validator = new InvoiceValidator();
        formatter = new InvoiceFormatter();
        service = new InvoiceService(discountEngine, taxCalculator, validator, formatter);
        customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
    }

    @Test
    void processInvoiceSuccess() {
        Invoice inv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 2, 100.0));
        Invoice processed = service.processInvoice(inv, customer);
        assertTrue(processed.isProcessed());
        assertEquals(200.0, processed.getSubtotal());
        assertEquals(10.0, processed.getDiscount(), 1e-9);
        assertEquals(14.0, processed.getTax(), 1e-9);
        assertEquals(204.0, processed.getGrandTotal(), 1e-9);
    }

    @Test
    void processInvoiceValidationFailure() {
        Invoice inv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        assertThrows(IllegalArgumentException.class, () -> service.processInvoice(inv, customer));
    }

    @Test
    void processInvoicesFiltersInvalid() {
        Invoice validInv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        validInv.addLineItem(new LineItem("P1", "", 1, 100.0));
        Invoice invalidInv = new Invoice("INV-002", customer, "DOMESTIC", LocalDate.now());
        List<Invoice> invoices = Arrays.asList(validInv, invalidInv);
        List<Invoice> processed = service.processInvoices(invoices, customer);
        assertEquals(1, processed.size());
        assertTrue(processed.contains(validInv));
        assertFalse(processed.contains(invalidInv));
    }

    @Test
    void processInvoicesAllValid() {
        Invoice inv1 = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv1.addLineItem(new LineItem("P1", "", 1, 50.0));
        Invoice inv2 = new Invoice("I2", customer, "DOMESTIC", LocalDate.now());
        inv2.addLineItem(new LineItem("P2", "", 2, 25.0));
        List<Invoice> invoices = Arrays.asList(inv1, inv2);
        List<Invoice> processed = service.processInvoices(invoices, customer);
        assertEquals(2, processed.size());
        assertTrue(processed.get(0).isProcessed());
        assertTrue(processed.get(1).isProcessed());
    }

    @Test
    void generateReport() {
        Invoice inv1 = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv1.addLineItem(new LineItem("P1", "", 1, 100.0));
        inv1.setGrandTotal(107.0);
        Invoice inv2 = new Invoice("I2", customer, "DOMESTIC", LocalDate.now());
        inv2.addLineItem(new LineItem("P2", "", 2, 50.0));
        inv2.setGrandTotal(104.0);
        List<Invoice> invoices = Arrays.asList(inv1, inv2);
        String report = service.generateReport(invoices);
        assertTrue(report.contains("Invoice Report"));
        assertTrue(report.contains("I1"));
        assertTrue(report.contains("I2"));
        assertTrue(report.contains("Total invoices: 2"));
    }

    @Test
    void calculateNetRevenue() {
        Invoice inv1 = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv1.setGrandTotal(100.0);
        Invoice inv2 = new Invoice("I2", customer, "DOMESTIC", LocalDate.now());
        inv2.setGrandTotal(200.0);
        List<Invoice> invoices = Arrays.asList(inv1, inv2);
        assertEquals(300.0, service.calculateNetRevenue(invoices));
    }
}
