package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceFormatterTest {
    private final InvoiceFormatter formatter = new InvoiceFormatter();

    @Test
    void formatSummaryCreatesCorrectString() {
        Customer c = new Customer("C1", "N", Customer.Tier.BRONZE, "DOMESTIC");
        Invoice inv = new Invoice("INV-X", c, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "D", 1, 10.0));
        inv.setGrandTotal(10.70);

        String summary = formatter.formatSummary(inv);
        assertEquals("Invoice INV-X: 1 items, total $10.70", summary);
    }

    @Test
    void formatLineItemHandlesMissingDescription() {
        LineItem item = new LineItem("P99", null, 2, 5.0);
        String formatted = formatter.formatLineItem(item);
        // Schema: "  %s x%d @ $%.2f = $%.2f"
        // Description is empty string if null passed to constructor
        assertTrue(formatted.contains("P99 x2 @ $5.00 = $10.00"));
    }

    @Test
    void formatReturnsPlaceholderForNull() {
        assertEquals("No invoice data.", formatter.format(null));
    }
}