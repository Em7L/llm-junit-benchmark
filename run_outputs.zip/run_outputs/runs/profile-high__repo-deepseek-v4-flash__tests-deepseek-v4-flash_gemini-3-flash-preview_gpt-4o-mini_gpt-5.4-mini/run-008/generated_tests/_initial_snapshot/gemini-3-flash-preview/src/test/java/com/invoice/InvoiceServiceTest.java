package com.invoice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceServiceTest {
    private InvoiceService service;
    private Customer goldCustomer;

    @BeforeEach
    void setUp() {
        service = new InvoiceService(
            new DiscountEngine(), 
            new TaxCalculator(), 
            new InvoiceValidator(), 
            new InvoiceFormatter()
        );
        goldCustomer = new Customer("C001", "John", Customer.Tier.GOLD, "DOMESTIC");
    }

    @Test
    void processInvoiceCalculatesAllFields() {
        Invoice inv = new Invoice("INV-1", goldCustomer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "Item", 2, 50.0)); // Subtotal 100
        
        Invoice result = service.processInvoice(inv, goldCustomer);
        
        assertEquals(100.0, result.getSubtotal());
        assertEquals(5.0, result.getDiscount()); // Gold 5%
        assertEquals(7.0, result.getTax()); // Domestic 7% of 100
        assertEquals(102.0, result.getGrandTotal()); // 100 - 5 + 7
        assertTrue(result.isProcessed());
    }

    @Test
    void processInvoicesFiltersInvalid() {
        Invoice valid = new Invoice("V1", goldCustomer, "DOMESTIC", LocalDate.now());
        valid.addLineItem(new LineItem("P1", "Item", 1, 10.0));
        
        Invoice invalid = new Invoice("I1", goldCustomer, "DOMESTIC", LocalDate.now());
        // No items makes it invalid

        List<Invoice> results = service.processInvoices(Arrays.asList(valid, invalid), goldCustomer);
        
        assertEquals(1, results.size());
        assertEquals("V1", results.get(0).getInvoiceId());
    }

    @Test
    void processInvoiceThrowsOnValidationFailure() {
        Invoice inv = new Invoice("INV-1", goldCustomer, "DOMESTIC", LocalDate.now());
        // Missing items triggers validation error
        assertThrows(IllegalArgumentException.class, () -> service.processInvoice(inv, goldCustomer));
    }

    @Test
    void calculateNetRevenueAggregatesGrandTotals() {
        Invoice inv1 = new Invoice("I1", goldCustomer, "DOMESTIC", LocalDate.now());
        inv1.setGrandTotal(100.0);
        Invoice inv2 = new Invoice("I2", goldCustomer, "DOMESTIC", LocalDate.now());
        inv2.setGrandTotal(250.50);
        
        double total = service.calculateNetRevenue(Arrays.asList(inv1, inv2));
        assertEquals(350.50, total);
    }
}