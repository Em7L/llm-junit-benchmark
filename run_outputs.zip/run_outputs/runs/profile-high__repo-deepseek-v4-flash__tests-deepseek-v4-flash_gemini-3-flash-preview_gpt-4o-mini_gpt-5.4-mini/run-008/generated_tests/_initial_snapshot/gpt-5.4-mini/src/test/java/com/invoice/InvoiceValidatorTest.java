package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceValidatorTest {

    private final InvoiceValidator validator = new InvoiceValidator();

    private Customer customer() {
        return new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
    }

    private Invoice invoiceWithOneItem() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now());
        invoice.addLineItem(new LineItem("P1", "Widget", 1, 10.0));
        return invoice;
    }

    @Test
    void validateReturnsSingleErrorForNullInvoice() {
        List<String> errors = validator.validate(null, customer());
        assertEquals(List.of("Invoice cannot be null"), errors);
        assertFalse(validator.isValid(null, customer()));
    }

    @Test
    void validateReportsMultipleFieldAndItemErrors() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now().minusDays(1));
        invoice.addLineItem(new LineItem("P1", "Widget", 0, -2.0));
        invoice.addLineItem(new LineItem("P2", "Widget 2", 1, 5.0));

        Customer invalidCustomer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        List<String> errors = validator.validate(invoice, invalidCustomer);

        assertTrue(errors.contains("Line item quantity must be positive (product: P1)"));
        assertTrue(errors.contains("Line item unit price cannot be negative (product: P1)"));
        assertFalse(errors.contains("Customer cannot be null"));
        assertTrue(validator.isValid(invoiceWithOneItem(), customer()));
    }

    @Test
    void validateRejectsFutureDateMissingItemsAndMissingRegion() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now().plusDays(1));
        InvoiceValidator validator = new InvoiceValidator();

        List<String> errors = validator.validate(invoice, customer());
        assertTrue(errors.contains("Invoice must have at least one line item"));
        assertTrue(errors.contains("Invoice date cannot be in the future"));
    }

    @Test
    void validateFlagsNullCustomerAndMissingInvoiceFields() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        Invoice invoice = new Invoice("INV-1", customer, "DOMESTIC", LocalDate.now());
        invoice.addLineItem(new LineItem("P1", "Widget", 1, 10.0));

        List<String> errors = validator.validate(invoice, null);
        assertTrue(errors.contains("Customer cannot be null"));
    }
}
