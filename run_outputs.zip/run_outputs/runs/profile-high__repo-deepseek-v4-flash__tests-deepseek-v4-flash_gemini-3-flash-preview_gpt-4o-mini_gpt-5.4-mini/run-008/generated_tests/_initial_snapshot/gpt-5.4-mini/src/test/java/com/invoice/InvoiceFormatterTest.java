package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceFormatterTest {

    private Invoice invoice() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
        Invoice invoice = new Invoice("INV-1", customer, "DOMESTIC", LocalDate.of(2025, 1, 15));
        invoice.addLineItem(new LineItem("P1", "Widget", 2, 10.0));
        invoice.addLineItem(new LineItem("P2", "", 1, 5.5));
        invoice.setSubtotal(25.5);
        invoice.setDiscount(2.5);
        invoice.setTax(1.61);
        invoice.setGrandTotal(24.61);
        return invoice;
    }

    @Test
    void formatReturnsExpectedMultiLineOutput() {
        InvoiceFormatter formatter = new InvoiceFormatter();
        String formatted = formatter.format(invoice());

        assertTrue(formatted.contains("Invoice: INV-1"));
        assertTrue(formatted.contains("Customer: Alice"));
        assertTrue(formatted.contains("Date: 2025-01-15"));
        assertTrue(formatted.contains("Region: DOMESTIC"));
        assertTrue(formatted.contains("  Widget x2 @ $10.00 = $20.00"));
        assertTrue(formatted.contains("  P2 x1 @ $5.50 = $5.50"));
        assertTrue(formatted.contains("Subtotal: $25.50"));
        assertTrue(formatted.contains("Discount: -$2.50"));
        assertTrue(formatted.contains("Tax: +$1.61"));
        assertTrue(formatted.contains("Total: $24.61"));
    }

    @Test
    void formatHandlesNullsAndSummaryUsesGrandTotal() {
        InvoiceFormatter formatter = new InvoiceFormatter();
        assertEquals("No invoice data.", formatter.format(null));
        assertEquals("", formatter.formatLineItem(null));
        assertEquals("Invoice INV-1: 2 items, total $24.61", formatter.formatSummary(invoice()));
    }
}
