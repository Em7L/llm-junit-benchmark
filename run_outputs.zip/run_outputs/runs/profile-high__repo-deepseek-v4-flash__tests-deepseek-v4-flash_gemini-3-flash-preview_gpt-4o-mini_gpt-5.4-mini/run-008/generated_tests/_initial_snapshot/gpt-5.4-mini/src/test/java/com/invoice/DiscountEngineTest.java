package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private final DiscountEngine engine = new DiscountEngine();

    private Invoice invoiceWithItems(String region, LineItem... items) {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.BRONZE, region);
        Invoice invoice = new Invoice("INV-1", customer, region, LocalDate.now());
        for (LineItem item : items) {
            invoice.addLineItem(item);
        }
        return invoice;
    }

    @Test
    void calculatesTierVolumeLargeOrderAndInternationalDiscounts() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.PLATINUM, "INTERNATIONAL");
        Invoice invoice = invoiceWithItems("INTERNATIONAL",
                new LineItem("P1", "A", 3, 200.0),
                new LineItem("P2", "B", 3, 200.0));

        double discount = engine.calculateDiscount(invoice, customer);
        assertEquals(330.0, discount, 1e-9);
    }

    @Test
    void capsDiscountAtFifteenPercentForLargeOrders() {
        Customer customer = new Customer("C1", "Alice", Customer.Tier.PLATINUM, "DOMESTIC");
        Invoice invoice = invoiceWithItems("DOMESTIC",
                new LineItem("P1", "A", 1, 1000.0),
                new LineItem("P2", "B", 1, 1000.0));

        double discount = engine.calculateDiscount(invoice, customer);
        assertEquals(300.0, discount, 1e-9);
    }

    @Test
    void promotionRequiresThreeItemsHighSubtotalAndNonInternationalRegion() {
        Invoice promoInvoice = invoiceWithItems("DOMESTIC",
                new LineItem("P1", "A", 2, 200.0),
                new LineItem("P2", "B", 1, 200.0),
                new LineItem("P3", "C", 1, 150.0));
        assertTrue(engine.qualifiesForPromotion(promoInvoice));

        Invoice notEnoughItems = invoiceWithItems("DOMESTIC",
                new LineItem("P1", "A", 1, 400.0),
                new LineItem("P2", "B", 1, 200.0));
        assertFalse(engine.qualifiesForPromotion(notEnoughItems));

        Invoice international = invoiceWithItems("INTERNATIONAL",
                new LineItem("P1", "A", 2, 300.0),
                new LineItem("P2", "B", 1, 300.0),
                new LineItem("P3", "C", 1, 100.0));
        assertFalse(engine.qualifiesForPromotion(international));
    }
}
