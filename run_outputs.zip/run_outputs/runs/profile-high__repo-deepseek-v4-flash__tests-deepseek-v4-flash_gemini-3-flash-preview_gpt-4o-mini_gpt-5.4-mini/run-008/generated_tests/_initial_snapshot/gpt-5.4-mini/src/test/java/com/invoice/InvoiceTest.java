package com.invoice;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceTest {

    private Customer customer() {
        return new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
    }

    @Test
    void constructorRejectsInvalidArguments() {
        assertThrows(IllegalArgumentException.class, () -> new Invoice(null, customer(), "DOMESTIC", LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Invoice("", customer(), "DOMESTIC", LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV-1", null, "DOMESTIC", LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV-1", customer(), null, LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV-1", customer(), "", LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Invoice("INV-1", customer(), "DOMESTIC", null));
    }

    @Test
    void addAndRemoveLineItemsAffectCountAndSubtotal() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now());
        LineItem item1 = new LineItem("P1", "Widget", 2, 10.0);
        LineItem item2 = new LineItem("P2", "Gadget", 1, 15.5);

        invoice.addLineItem(item1);
        invoice.addLineItem(item2);

        assertEquals(2, invoice.getItemCount());
        assertEquals(35.5, invoice.computeSubtotal(), 1e-9);
        assertEquals(List.of(item1, item2), invoice.getItems());

        assertTrue(invoice.removeLineItem("P1"));
        assertEquals(1, invoice.getItemCount());
        assertEquals(15.5, invoice.computeSubtotal(), 1e-9);
        assertFalse(invoice.removeLineItem("missing"));
    }

    @Test
    void addLineItemRejectsNullAndStatusMessageReflectsProcessedState() {
        Invoice invoice = new Invoice("INV-1", customer(), "DOMESTIC", LocalDate.now());
        assertThrows(IllegalArgumentException.class, () -> invoice.addLineItem(null));

        invoice.addLineItem(new LineItem("P1", "Widget", 1, 20.0));
        assertEquals("Invoice INV-1 pending. Items: 1", invoice.getStatusMessage());

        invoice.setSubtotal(20.0);
        invoice.setDiscount(2.0);
        invoice.setTax(1.26);
        invoice.setGrandTotal(19.26);
        invoice.setProcessed(true);

        assertEquals("Invoice INV-1 finalized. Total: $19.26", invoice.getStatusMessage());
    }
}
