package com.invoice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceServiceTest {

    private DiscountEngine discountEngine;
    private TaxCalculator taxCalculator;
    private InvoiceValidator validator;
    private InvoiceFormatter formatter;
    private InvoiceService service;
    private Customer customer;

    @BeforeEach
    void setUp() {
        discountEngine = new DiscountEngine();
        taxCalculator = new TaxCalculator();
        validator = new InvoiceValidator();
        formatter = new InvoiceFormatter();
        service = new InvoiceService(discountEngine, taxCalculator, validator, formatter);
        customer = new Customer("C1", "Alice", Customer.Tier.GOLD, "DOMESTIC");
    }

    @Test
    void processInvoiceSuccess() {
        Invoice inv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 2, 100.0)); // subtotal=200
        Invoice processed = service.processInvoice(inv, customer);
        assertTrue(processed.isProcessed());
        assertEquals(200.0, processed.getSubtotal());
        // tier discount: gold 5% of 200 = 10; no volume, no large, no intl -> discount=10
        assertEquals(10.0, processed.getDiscount());
        // tax: domestic 7% of 200 = 14
        assertEquals(14.0, processed.getTax());
        // grand total = 200 - 10 + 14 = 204
        assertEquals(204.0, processed.getGrandTotal());
    }

    @Test
    void processInvoiceValidationFailure() {
        Invoice inv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        // no line items -> validation fails
        assertThrows(IllegalArgumentException.class, () -> service.processInvoice(inv, customer));
    }

    @Test
    void processInvoiceGrandTotalNotNegative() {
        // Ensure that if subtotal - discount + tax < 0, grandTotal is set to 0.
        // This can happen if discount is high relative to subtotal. Create situation with huge discount.
        // Use platinum, volume, large order, international but low subtotal.
        Customer intlPlatinum = new Customer("C2", "Bob", Customer.Tier.PLATINUM, "INTERNATIONAL");
        Invoice inv = new Invoice("INV-002", intlPlatinum, "INTERNATIONAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 10.0)); // subtotal=10
        // discount: tier 10% = 1, volume? no (1 item), large? no (subtotal=10<=1000), international 3% = 0.3 => total discount = 1.3
        // tax: international 5% = 0.5
        // grand total = 10 - 1.3 + 0.5 = 9.2, not negative. To force negative, we need bigger discount. But discount caps at 15%? Actually no cap for low subtotal? For low subtotal, large order doesn't apply. So we need a scenario where discount exceeds subtotal + tax? But discount cannot exceed subtotal? Actually discounts are percentages of subtotal, so they are less than subtotal. So grand total cannot be negative. The code has a safety check. We can still test with a case where discount > subtotal? Not possible because discount is calculated as percentage of subtotal (max 15%+3% if all apply = 18%? Actually max tier 10% + volume 2% + large order 5% capped at 15% total + international 3% = 18% but cap for large order reduces to 15% overall? Actually the cap in large order branch applies to total discount so far + additional, cap to 15% of subtotal. So max discount is 15% + 3% = 18% if international? But the cap only applies in large order branch. If subtotal <=1000, no large order, so max discount = tier (10% platinum) + volume (2%) + international (3%) = 15%. So discount <= 15% of subtotal. Tax is 7% domestic or 5% international maximum 10%. So grand total = subtotal - discount + tax >= subtotal - 0.15*subtotal + 0 = 0.85*subtotal > 0. So negative grand total impossible given current rates. But code has check, we can test with mock? But we cannot mock. So we skip this test.
    }

    @Test
    void processInvoicesFiltersInvalid() {
        Invoice validInv = new Invoice("INV-001", customer, "DOMESTIC", LocalDate.now());
        validInv.addLineItem(new LineItem("P1", "", 1, 100.0));
        Invoice invalidInv = new Invoice("INV-002", customer, "DOMESTIC", LocalDate.now());
        // no line items -> invalid
        List<Invoice> invoices = Arrays.asList(validInv, invalidInv);
        List<Invoice> processed = service.processInvoices(invoices, customer);
        assertEquals(1, processed.size());
        assertTrue(processed.contains(validInv));
        assertFalse(processed.contains(invalidInv));
    }

    @Test
    void processInvoicesAllValid() {
        Invoice inv1 = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv1.addLineItem(new LineItem("P1", "", 1, 50.0));
        Invoice inv2 = new Invoice("I2", customer, "DOMESTIC", LocalDate.now());
        inv2.addLineItem(new LineItem("P2", "", 2, 25.0));
        List<Invoice> invoices = Arrays.asList(inv1, inv2);
        List<Invoice> processed = service.processInvoices(invoices, customer);
        assertEquals(2, processed.size());
        assertTrue(processed.get(0).isProcessed());
        assertTrue(processed.get(1).isProcessed());
    }

    @Test
    void generateReport() {
        Invoice inv1 = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv1.addLineItem(new LineItem("P1", "", 1, 100.0));
        inv1.setGrandTotal(107.0); // after processing would be different but we just set for testing
        Invoice inv2 = new Invoice("I2", customer, "DOMESTIC", LocalDate.now());
        inv2.addLineItem(new LineItem("P2", "", 2, 50.0));
        inv2.setGrandTotal(104.0);
        List<Invoice> invoices = Arrays.asList(inv1, inv2);
        String report = service.generateReport(invoices);
        assertTrue(report.contains("Invoice Report"));
        assertTrue(report.contains("I1"));
        assertTrue(report.contains("I2"));
        assertTrue(report.contains("Total invoices: 2"));
    }

    @Test
    void calculateNetRevenue() {
        Invoice inv1 = new Invoice("I1", customer, "DOMESTIC", LocalDate.now());
        inv1.setGrandTotal(100.0);
        Invoice inv2 = new Invoice("I2", customer, "DOMESTIC", LocalDate.now());
        inv2.setGrandTotal(200.0);
        List<Invoice> invoices = Arrays.asList(inv1, inv2);
        assertEquals(300.0, service.calculateNetRevenue(invoices));
    }
}
