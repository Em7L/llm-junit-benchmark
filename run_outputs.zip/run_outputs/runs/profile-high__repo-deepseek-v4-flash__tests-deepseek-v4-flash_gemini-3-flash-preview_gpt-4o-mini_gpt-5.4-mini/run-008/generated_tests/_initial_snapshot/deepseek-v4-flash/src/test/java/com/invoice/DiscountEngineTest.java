package com.invoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class DiscountEngineTest {

    private DiscountEngine engine = new DiscountEngine();
    private Customer domesticPlatinum = new Customer("C1", "Alice", Customer.Tier.PLATINUM, "DOMESTIC");
    private Customer domesticGold = new Customer("C2", "Bob", Customer.Tier.GOLD, "DOMESTIC");
    private Customer domesticSilver = new Customer("C3", "Charlie", Customer.Tier.SILVER, "DOMESTIC");
    private Customer domesticBronze = new Customer("C4", "David", Customer.Tier.BRONZE, "DOMESTIC");
    private Customer internationalPlatinum = new Customer("C5", "Eve", Customer.Tier.PLATINUM, "INTERNATIONAL");

    @Test
    void tierDiscountOnlyPlatinum() {
        Invoice inv = new Invoice("I1", domesticPlatinum, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0)); // subtotal=100
        double discount = engine.calculateDiscount(inv, domesticPlatinum);
        // tier: 10% of 100 = 10; no volume; no large order; no international
        assertEquals(10.0, discount, 1e-9);
    }

    @Test
    void tierDiscountGold() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 200.0));
        double discount = engine.calculateDiscount(inv, domesticGold);
        assertEquals(10.0, discount, 1e-9); // 5% of 200 = 10
    }

    @Test
    void tierDiscountSilver() {
        Invoice inv = new Invoice("I1", domesticSilver, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double discount = engine.calculateDiscount(inv, domesticSilver);
        assertEquals(2.0, discount, 1e-9); // 2% of 100 = 2
    }

    @Test
    void tierDiscountBronze() {
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0));
        double discount = engine.calculateDiscount(inv, domesticBronze);
        assertEquals(0.0, discount, 1e-9);
    }

    @Test
    void volumeDiscountAppliesWhenMoreThan5Items() {
        // Create invoice with 6 items, subtotal 100 each? But we want to isolate volume discount.
        // Use bronze to avoid tier discount.
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        for (int i = 0; i < 6; i++) {
            inv.addLineItem(new LineItem("P"+i, "", 1, 100.0));
        }
        double discount = engine.calculateDiscount(inv, domesticBronze);
        // subtotal = 600; no tier; volume: 2% of 600 = 12; no large order (subtotal 600 <= 1000); no intl
        assertEquals(12.0, discount, 1e-9);
    }

    @Test
    void volumeDiscountDoesNotApplyExactly5Items() {
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        for (int i = 0; i < 5; i++) {
            inv.addLineItem(new LineItem("P"+i, "", 1, 100.0));
        }
        double discount = engine.calculateDiscount(inv, domesticBronze);
        // subtotal=500; no tier; no volume; no large order
        assertEquals(0.0, discount, 1e-9);
    }

    @Test
    void largeOrderDiscountBelowCap() {
        // Subtotal > 1000, add extra 5% but total discount < 15% of subtotal
        // Use bronze to avoid tier, and no volume (<=5 items), no international.
        Invoice inv = new Invoice("I1", domesticBronze, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 1100.0)); // subtotal=1100
        double discount = engine.calculateDiscount(inv, domesticBronze);
        // No tier, no volume (1 item <=5), large order: additional 5% = 55, total discount = 55, cap 15% of 1100=165, so no cap
        assertEquals(55.0, discount, 1e-9);
    }

    @Test
    void largeOrderDiscountCapped() {
        // Subtotal > 1000, but combined discount would exceed 15% cap.
        // Use platinum tier (10%) + volume (2%) + large order (5%) = 17% > 15% cap.
        Invoice inv = new Invoice("I1", domesticPlatinum, "DOMESTIC", LocalDate.now());
        for (int i = 0; i < 6; i++) {
            inv.addLineItem(new LineItem("P"+i, "", 1, 200.0)); // subtotal=1200
        }
        double discount = engine.calculateDiscount(inv, domesticPlatinum);
        // tier: 10% of 1200 = 120; volume: 2% = 24; large order: 5% = 60; total before cap = 204; 15% of 1200 = 180; cap applied => 180
        assertEquals(180.0, discount, 1e-9);
    }

    @Test
    void internationalDiscountExtra3Percent() {
        Invoice inv = new Invoice("I1", internationalPlatinum, "INTERNATIONAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 1, 100.0)); // subtotal=100
        double discount = engine.calculateDiscount(inv, internationalPlatinum);
        // tier: 10% = 10; international: 3% = 3; no volume, no large order => total 13
        assertEquals(13.0, discount, 1e-9);
    }

    @Test
    void qualifiesForPromotionTrue() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 200.0)); // 3 items, subtotal=600 > 500, domestic
        assertTrue(engine.qualifiesForPromotion(inv));
    }

    @Test
    void qualifiesForPromotionFalseItemCountLessThan3() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 2, 600.0)); // 2 items, subtotal=1200
        assertFalse(engine.qualifiesForPromotion(inv));
    }

    @Test
    void qualifiesForPromotionFalseSubtotalNotExceed500() {
        Invoice inv = new Invoice("I1", domesticGold, "DOMESTIC", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 100.0)); // subtotal=300
        assertFalse(engine.qualifiesForPromotion(inv));
    }

    @Test
    void qualifiesForPromotionFalseInternational() {
        Invoice inv = new Invoice("I1", internationalPlatinum, "INTERNATIONAL", LocalDate.now());
        inv.addLineItem(new LineItem("P1", "", 3, 200.0)); // 3 items, subtotal=600 >500 but international
        assertFalse(engine.qualifiesForPromotion(inv));
    }
}
