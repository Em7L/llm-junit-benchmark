package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CatalogTest {

    @Test
    void rejectsEmptyOrNullItems() {
        assertThrows(IllegalArgumentException.class, () -> new Catalog());
        assertThrows(IllegalArgumentException.class, () -> new Catalog((List<MenuItem>) null));
    }

    @Test
    void managesSkusCaseInsensitively() {
        MenuItem item = MenuItem.of("coffee", "Coffee", "drink", new BigDecimal("2.00"), true);
        Catalog catalog = new Catalog(item);
        
        assertNotNull(catalog.find("COFFEE"));
        assertNotNull(catalog.find("coffee "));
        assertEquals(item, catalog.require("CoFfEe"));
    }

    @Test
    void rejectsDuplicateSkus() {
        MenuItem item1 = MenuItem.of("A", "Name", "Cat", new BigDecimal("1.00"), true);
        MenuItem item2 = MenuItem.of("a", "Name", "Cat", new BigDecimal("2.00"), true);
        assertThrows(IllegalArgumentException.class, () -> new Catalog(item1, item2));
    }

    @Test
    void checksCategoryExistence() {
        Catalog catalog = new Catalog(MenuItem.of("TEA", "Tea", "Drink", new BigDecimal("1.0"), true));
        assertTrue(catalog.containsCategory("drink"));
        assertTrue(catalog.containsCategory("DRINK "));
        assertFalse(catalog.containsCategory("food"));
        assertFalse(catalog.containsCategory(null));
    }
}