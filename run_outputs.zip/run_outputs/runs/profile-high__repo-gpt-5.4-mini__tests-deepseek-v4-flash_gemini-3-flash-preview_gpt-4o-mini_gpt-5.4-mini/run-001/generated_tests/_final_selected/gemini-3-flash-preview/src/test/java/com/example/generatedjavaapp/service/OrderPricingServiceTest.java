package com.example.generatedjavaapp.service;

import com.example.generatedjavaapp.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class OrderPricingServiceTest {
    private OrderPricingService service;
    private Catalog catalog;

    @BeforeEach
    void setup() {
        catalog = new Catalog(
            MenuItem.of("COFFEE", "Coffee", "drink", new BigDecimal("4.00"), true),
            MenuItem.of("BREAD", "Bread", "food", new BigDecimal("5.00"), false)
        );
        service = new OrderPricingService(catalog);
    }

    @Test
    void calculatesBasicPricingWithNoDiscounts() {
        Order order = new Order("ORD1", "STANDARD", false);
        order.addLine(new LineItem("BREAD", 1, "")); // 5.00, non-taxable

        PricingSummary summary = service.price(order);
        assertEquals(new BigDecimal("5.00"), summary.subtotal());
        assertEquals(new BigDecimal("0.00"), summary.discount());
        // Bread is non-taxable in our setup, so taxableBase is 0. Tax must be 0.00
        assertEquals(new BigDecimal("0.00"), summary.tax());
        assertEquals(new BigDecimal("5.00"), summary.total());
    }

    @Test
    void appliesDrinkDiscount() {
        Order order = new Order("ORD2", "STANDARD", false);
        order.addLine(new LineItem("COFFEE", 2, "")); // 4.00 * 2 = 8.00. Drink discount 10% = 0.80

        PricingSummary summary = service.price(order);
        assertEquals(new BigDecimal("0.80"), summary.discount());
    }

    @Test
    void appliesNoNutsDiscount() {
        Order order = new Order("ORD3", "STANDARD", false);
        order.addLine(new LineItem("BREAD", 1, "no nuts"));

        PricingSummary summary = service.price(order);
        assertEquals(new BigDecimal("0.15"), summary.discount());
    }

    @Test
    void calculatesLoyaltyPointsCorrect() {
        // Member (10) + Subtotal 50/5 (10) + Gold (5) = 25
        Order order = new Order("L1", "GOLD", true);
        order.addLine(new LineItem("BREAD", 10, "")); // 50.00 (bulk price 0.95 * 50 = 47.50)

        PricingSummary summary = service.price(order);
        // Subtotal = 47.50. 47.50 / 5 = 9 points. Base member = 10. Gold = 5. Total = 24. 
        // Also total > 25 and isBulkOrder -> +4 points = 28.
        assertEquals(28, summary.loyaltyPoints());
    }

    @Test
    void complexTaxCalculationForGoldMember() {
        // Gold member: 6% base - 0.5% gold = 5.5%
        Order order = new Order("T1", "GOLD", true);
        order.addLine(new LineItem("COFFEE", 1, "")); // 4.00 taxable

        BigDecimal tax = service.calculateTax(new BigDecimal("4.00"), new BigDecimal("4.00"), order);
        // 4.00 * 0.055 = 0.22
        assertEquals(new BigDecimal("0.22"), tax);
    }
}