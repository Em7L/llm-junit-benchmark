package com.example.generatedjavaapp.rules;

import com.example.generatedjavaapp.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderRuleEngineTest {
    private OrderRuleEngine engine;
    private Catalog catalog;

    @BeforeEach
    void setup() {
        engine = new OrderRuleEngine();
        catalog = new Catalog(MenuItem.of("ITEM1", "Item 1", "food", new BigDecimal("5.00"), false));
    }

    @Test
    void rejectsEmptyOrder() {
        Order order = new Order("O1", "STANDARD", false);
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("order must contain at least one line item"));
    }

    @Test
    void enforcesTierSelectionForStandardMembersWithManyItems() {
        Order order = new Order("O1", "STANDARD", true);
        order.addLine(new LineItem("ITEM1", 3, ""));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("standard members with 3+ items must select a tier"));
    }

    @Test
    void validatesNoteLengthAndQuantity() {
        Order order = new Order("O1", "GOLD", true);
        order.addLine(new LineItem("ITEM1", 21, "This note is intentionally written to be extremely long to trigger the validation error"));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.stream().anyMatch(p -> p.contains("quantity too large")));
        assertTrue(problems.stream().anyMatch(p -> p.contains("note too long")));
    }

    @Test
    void ensuresBulkOrderHasLargeLineItem() {
        Order order = new Order("O1", "GOLD", true);
        // Total 8 items but no single line >= 5
        order.addLine(new LineItem("ITEM1", 4, ""));
        order.addLine(new LineItem("ITEM1", 4, ""));
        assertTrue(order.isBulkOrder());
        
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("bulk order requires at least one large line item"));
    }
}