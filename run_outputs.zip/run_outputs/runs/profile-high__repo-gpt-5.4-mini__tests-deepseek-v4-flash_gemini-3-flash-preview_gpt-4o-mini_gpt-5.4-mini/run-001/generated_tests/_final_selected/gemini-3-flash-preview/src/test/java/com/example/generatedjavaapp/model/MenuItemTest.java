package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class MenuItemTest {

    @Test
    void bulkPricingAppliesCorrectDiscounts() {
        MenuItem item = MenuItem.of("S1", "Soda", "drink", new BigDecimal("10.00"), true);
        
        // Standard price (1-4)
        assertEquals(new BigDecimal("10.00"), item.bulkPrice(1));
        assertEquals(new BigDecimal("40.00"), item.bulkPrice(4));
        
        // 3% discount (5-9)
        // 5 * 10 * 0.97 = 48.5
        assertEquals(0, new BigDecimal("48.500").compareTo(item.bulkPrice(5)));
        
        // 5% discount (10+)
        // 10 * 10 * 0.95 = 95
        assertEquals(0, new BigDecimal("95.000").compareTo(item.bulkPrice(10)));
    }

    @Test
    void validationRejectsInvalidInputs() {
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of(" ", "N", "C", BigDecimal.ONE, true));
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("S", " ", "C", BigDecimal.ONE, true));
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("S", "N", "C", BigDecimal.ZERO, true));
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("S", "N", "C", new BigDecimal("-1.0"), true));
    }
}