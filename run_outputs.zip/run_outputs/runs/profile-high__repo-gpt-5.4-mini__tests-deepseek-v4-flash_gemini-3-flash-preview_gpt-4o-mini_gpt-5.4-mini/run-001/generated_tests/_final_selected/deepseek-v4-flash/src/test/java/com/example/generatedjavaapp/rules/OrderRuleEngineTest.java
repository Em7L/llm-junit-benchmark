package com.example.generatedjavaapp.rules;

import com.example.generatedjavaapp.model.Catalog;
import com.example.generatedjavaapp.model.LineItem;
import com.example.generatedjavaapp.model.MenuItem;
import com.example.generatedjavaapp.model.Order;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OrderRuleEngineTest {

    private OrderRuleEngine engine;
    private Catalog catalog;

    @BeforeEach
    void setUp() {
        engine = new OrderRuleEngine();
        catalog = new Catalog(
            MenuItem.of("A", "Item A", "drink", new BigDecimal("1.00"), true),
            MenuItem.of("B", "Item B", "food", new BigDecimal("1.00"), false)
        );
    }

    @Test
    void validateReturnsErrorForNullOrder() {
        List<String> problems = engine.validate(null, catalog);
        assertEquals(List.of("order is required"), problems);
    }

    @Test
    void validateReturnsErrorForNullCatalog() {
        Order order = new Order("1", "STANDARD", false);
        List<String> problems = engine.validate(order, null);
        assertEquals(List.of("catalog is required"), problems);
    }

    @Test
    void validateReturnsErrorForEmptyOrder() {
        Order order = new Order("1", "STANDARD", false);
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("order must contain at least one line item"));
    }

    @Test
    void validateReturnsWarningForStandardMemberWithThreeOrMoreItems() {
        Order order = new Order("1", "STANDARD", true)
                .addLine(new LineItem("A", 1, ""))
                .addLine(new LineItem("B", 1, ""))
                .addLine(new LineItem("A", 1, ""));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("standard members with 3+ items must select a tier"));
    }

    @Test
    void validateDoesNotWarnForNonMemberWithThreeOrMoreItems() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 1, ""))
                .addLine(new LineItem("B", 1, ""))
                .addLine(new LineItem("A", 1, ""));
        List<String> problems = engine.validate(order, catalog);
        assertFalse(problems.contains("standard members with 3+ items must select a tier"));
    }

    @Test
    void validateDetectsUnknownSku() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("UNKNOWN", 1, ""));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("unknown sku: UNKNOWN"));
    }

    @Test
    void validateDetectsQuantityTooLarge() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 21, ""));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("quantity too large for sku: A"));
    }

    @Test
    void validateDetectsNoteTooLong() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 1, "a" .repeat(31)));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("note too long for sku: A"));
    }

    @Test
    void validateDetectsBulkOrderWithoutLargeLine() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 4, ""))
                .addLine(new LineItem("B", 4, ""));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.contains("bulk order requires at least one large line item"));
    }

    @Test
    void validateAllowsValidOrder() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 1, ""));
        List<String> problems = engine.validate(order, catalog);
        assertTrue(problems.isEmpty());
    }

    @Test
    void ensureValidThrowsOnProblems() {
        Order order = new Order("1", "STANDARD", false);
        assertThrows(IllegalArgumentException.class, () -> engine.ensureValid(order, catalog));
    }

    @Test
    void ensureValidDoesNotThrowOnValid() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 1, ""));
        assertDoesNotThrow(() -> engine.ensureValid(order, catalog));
    }

    @Test
    void qualifiesForMemberPricingReturnsTrueForNonStandardMember() {
        Order order = new Order("1", "GOLD", true);
        assertTrue(engine.qualifiesForMemberPricing(order));
    }

    @Test
    void qualifiesForMemberPricingReturnsFalseForStandardMember() {
        Order order = new Order("1", "STANDARD", true);
        assertFalse(engine.qualifiesForMemberPricing(order));
    }

    @Test
    void qualifiesForMemberPricingReturnsFalseForNonMember() {
        Order order = new Order("1", "GOLD", false);
        assertFalse(engine.qualifiesForMemberPricing(order));
    }
}