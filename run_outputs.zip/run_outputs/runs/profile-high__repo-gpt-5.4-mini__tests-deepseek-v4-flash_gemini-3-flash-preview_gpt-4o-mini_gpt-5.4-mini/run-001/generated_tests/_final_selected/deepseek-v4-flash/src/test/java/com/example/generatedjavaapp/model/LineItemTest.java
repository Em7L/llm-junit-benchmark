package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LineItemTest {

    @Test
    void constructorRejectsNullSku() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(null, 1, ""));
    }

    @Test
    void constructorRejectsBlankSku() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem(" ", 1, ""));
    }

    @Test
    void constructorRejectsNonPositiveQuantity() {
        assertThrows(IllegalArgumentException.class, () -> new LineItem("A", 0, ""));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("A", -1, ""));
    }

    @Test
    void constructorTrimsSkuAndConvertsToUpperCase() {
        LineItem item = new LineItem(" coffee ", 2, "");
        assertEquals("COFFEE", item.sku());
    }

    @Test
    void constructorTrimsNoteAndDefaultsNullToEmpty() {
        LineItem item = new LineItem("A", 1, null);
        assertEquals("", item.note());
    }

    @Test
    void hasNoteReturnsTrueForNonBlank() {
        LineItem item = new LineItem("A", 1, "extra hot");
        assertTrue(item.hasNote());
    }

    @Test
    void hasNoteReturnsFalseForBlank() {
        LineItem item = new LineItem("A", 1, " ");
        assertFalse(item.hasNote());
    }

    @Test
    void isLargeOrderLineReturnsTrueWhenQuantityAtLeastFive() {
        LineItem item = new LineItem("A", 5, "");
        assertTrue(item.isLargeOrderLine());
    }

    @Test
    void isLargeOrderLineReturnsFalseWhenQuantityBelowFive() {
        LineItem item = new LineItem("A", 4, "");
        assertFalse(item.isLargeOrderLine());
    }

    @Test
    void equalsAndHashCode() {
        LineItem a = new LineItem("A", 1, "note");
        LineItem b = new LineItem("A", 1, "note");
        LineItem c = new LineItem("A", 2, "note");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
    }
}