package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CatalogTest {

    @Test
    void constructorWithCollectionRejectsNull() {
        assertThrows(IllegalArgumentException.class, () -> new Catalog((List<MenuItem>) null));
    }

    @Test
    void constructorWithCollectionRejectsEmpty() {
        assertThrows(IllegalArgumentException.class, () -> new Catalog(List.of()));
    }

    @Test
    void constructorWithVarargsAcceptsValidItems() {
        MenuItem item = MenuItem.of("A", "Item A", "drink", new BigDecimal("1.00"), true);
        Catalog catalog = new Catalog(item);
        assertEquals(1, catalog.size());
    }

    @Test
    void constructorRejectsDuplicateSku() {
        MenuItem item = MenuItem.of("A", "Item A", "drink", new BigDecimal("1.00"), true);
        assertThrows(IllegalArgumentException.class, () -> new Catalog(item, item));
    }

    @Test
    void findReturnsNullForNullSku() {
        Catalog catalog = new Catalog(MenuItem.of("A", "A", "drink", BigDecimal.ONE, true));
        assertNull(catalog.find(null));
    }

    @Test
    void findReturnsNullForBlankSku() {
        Catalog catalog = new Catalog(MenuItem.of("A", "A", "drink", BigDecimal.ONE, true));
        assertNull(catalog.find(" "));
    }

    @Test
    void findIgnoresCaseAndTrims() {
        Catalog catalog = new Catalog(MenuItem.of("COFFEE", "Coffee", "drink", new BigDecimal("3.50"), true));
        assertNotNull(catalog.find(" coffee "));
    }

    @Test
    void requireReturnsItemIfFound() {
        Catalog catalog = new Catalog(MenuItem.of("TEA", "Tea", "drink", new BigDecimal("2.00"), true));
        assertEquals("Tea", catalog.require("tea").name());
    }

    @Test
    void requireThrowsForUnknownSku() {
        Catalog catalog = new Catalog(MenuItem.of("A", "A", "drink", BigDecimal.ONE, true));
        assertThrows(IllegalArgumentException.class, () -> catalog.require("B"));
    }

    @Test
    void containsCategoryReturnsTrueIfPresent() {
        Catalog catalog = new Catalog(MenuItem.of("C", "C", "food", BigDecimal.ONE, false));
        assertTrue(catalog.containsCategory("food"));
    }

    @Test
    void containsCategoryReturnsFalseIfNotPresent() {
        Catalog catalog = new Catalog(MenuItem.of("C", "C", "drink", BigDecimal.ONE, true));
        assertFalse(catalog.containsCategory("food"));
    }

    @Test
    void containsCategoryReturnsFalseForNull() {
        Catalog catalog = new Catalog(MenuItem.of("A", "A", "drink", BigDecimal.ONE, true));
        assertFalse(catalog.containsCategory(null));
    }

    @Test
    void sizeMatchesNumberOfUniqueItems() {
        MenuItem a = MenuItem.of("A", "A", "drink", BigDecimal.ONE, true);
        MenuItem b = MenuItem.of("B", "B", "food", BigDecimal.ONE, false);
        Catalog catalog = new Catalog(a, b);
        assertEquals(2, catalog.size());
    }
}