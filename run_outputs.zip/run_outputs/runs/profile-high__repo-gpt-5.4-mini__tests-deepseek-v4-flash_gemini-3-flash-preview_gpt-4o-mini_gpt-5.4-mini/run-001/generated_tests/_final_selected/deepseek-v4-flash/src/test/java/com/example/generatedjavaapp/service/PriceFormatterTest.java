package com.example.generatedjavaapp.service;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class PriceFormatterTest {

    private final PriceFormatter formatter = new PriceFormatter();

    @Test
    void moneyReturnsFormattedString() {
        assertEquals("$10.50", formatter.money(new BigDecimal("10.5")));
    }

    @Test
    void moneyThrowsOnNull() {
        assertThrows(IllegalArgumentException.class, () -> formatter.money(null));
    }

    @Test
    void parseMoneyHandlesDollarSign() {
        assertEquals(new BigDecimal("10.50"), formatter.parseMoney("$10.50"));
    }

    @Test
    void parseMoneyHandlesPlainNumber() {
        assertEquals(new BigDecimal("10.50"), formatter.parseMoney("10.50"));
    }

    @Test
    void parseMoneyThrowsOnNull() {
        assertThrows(IllegalArgumentException.class, () -> formatter.parseMoney(null));
    }

    @Test
    void parseMoneyThrowsOnBlank() {
        assertThrows(IllegalArgumentException.class, () -> formatter.parseMoney(" "));
    }

    @Test
    void slugConvertsToLowercaseAndReplacesSpaces() {
        assertEquals("hello-world", formatter.slug("Hello World"));
    }

    @Test
    void slugReturnsUnknownForNull() {
        assertEquals("unknown", formatter.slug(null));
    }

    @Test
    void slugHandlesAlreadyClean() {
        assertEquals("test", formatter.slug("test"));
    }

    @Test
    void joinLinesJoinsWithLineSeparator() {
        String result = formatter.joinLines("Line1", "Line2");
        assertEquals("Line1" + System.lineSeparator() + "Line2", result);
    }

    @Test
    void joinLinesSkipsNullAndBlank() {
        String result = formatter.joinLines("Line1", null, " ", "Line2");
        assertEquals("Line1" + System.lineSeparator() + "Line2", result);
    }

    @Test
    void joinLinesReturnsEmptyForEmptyInput() {
        assertEquals("", formatter.joinLines());
    }

    @Test
    void quantityLabelReturnsNoneForNonPositive() {
        assertEquals("none", formatter.quantityLabel(0));
        assertEquals("none", formatter.quantityLabel(-1));
    }

    @Test
    void quantityLabelReturnsSingleForOne() {
        assertEquals("single", formatter.quantityLabel(1));
    }

    @Test
    void quantityLabelReturnsSmallForTwoToFour() {
        assertEquals("small", formatter.quantityLabel(2));
        assertEquals("small", formatter.quantityLabel(4));
    }

    @Test
    void quantityLabelReturnsBulkForFiveOrMore() {
        assertEquals("bulk", formatter.quantityLabel(5));
        assertEquals("bulk", formatter.quantityLabel(100));
    }
}