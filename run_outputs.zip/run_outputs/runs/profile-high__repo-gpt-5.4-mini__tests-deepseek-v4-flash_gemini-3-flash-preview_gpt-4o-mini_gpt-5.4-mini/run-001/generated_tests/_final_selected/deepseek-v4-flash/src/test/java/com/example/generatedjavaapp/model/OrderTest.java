package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @Test
    void constructorRejectsBlankOrderId() {
        assertThrows(IllegalArgumentException.class, () -> new Order(" ", "STANDARD", false));
        assertThrows(IllegalArgumentException.class, () -> new Order(null, "STANDARD", false));
    }

    @Test
    void constructorDefaultsLoyaltyTierToStandardIfNull() {
        Order order = new Order("1", null, false);
        assertEquals("STANDARD", order.loyaltyTier());
    }

    @Test
    void constructorTrimsAndUppercasesLoyaltyTier() {
        Order order = new Order("1", " gold ", false);
        assertEquals("GOLD", order.loyaltyTier());
    }

    @Test
    void addLineReturnsSelfForChaining() {
        Order order = new Order("1", "STANDARD", false);
        assertSame(order, order.addLine(new LineItem("A", 1, "")));
    }

    @Test
    void addLineRejectsNull() {
        Order order = new Order("1", "STANDARD", false);
        assertThrows(NullPointerException.class, () -> order.addLine(null));
    }

    @Test
    void itemCountSumsAllQuantities() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 2, ""))
                .addLine(new LineItem("B", 3, ""));
        assertEquals(5, order.itemCount());
    }

    @Test
    void isEmptyReturnsTrueWhenNoItems() {
        Order order = new Order("1", "STANDARD", false);
        assertTrue(order.isEmpty());
    }

    @Test
    void isEmptyReturnsFalseWhenItemsPresent() {
        Order order = new Order("1", "STANDARD", false).addLine(new LineItem("A", 1, ""));
        assertFalse(order.isEmpty());
    }

    @Test
    void isBulkOrderReturnsTrueWhenItemCountAtLeastEight() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 8, ""));
        assertTrue(order.isBulkOrder());
    }

    @Test
    void isBulkOrderReturnsFalseWhenItemCountBelowEight() {
        Order order = new Order("1", "STANDARD", false)
                .addLine(new LineItem("A", 7, ""));
        assertFalse(order.isBulkOrder());
    }

    @Test
    void itemsReturnsUnmodifiableList() {
        Order order = new Order("1", "STANDARD", false).addLine(new LineItem("A", 1, ""));
        assertThrows(UnsupportedOperationException.class, () -> order.items().add(new LineItem("B", 1, "")));
    }
}