package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class PricingSummaryTest {

    @Test
    void constructorRejectsNullFields() {
        assertThrows(NullPointerException.class, () -> new PricingSummary(null, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, 0, ""));
        assertThrows(NullPointerException.class, () -> new PricingSummary(BigDecimal.ZERO, null, BigDecimal.ZERO, BigDecimal.ZERO, 0, ""));
        assertThrows(NullPointerException.class, () -> new PricingSummary(BigDecimal.ZERO, BigDecimal.ZERO, null, BigDecimal.ZERO, 0, ""));
        assertThrows(NullPointerException.class, () -> new PricingSummary(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, null, 0, ""));
        assertThrows(NullPointerException.class, () -> new PricingSummary(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, 0, null));
    }

    @Test
    void hasDiscountReturnsTrueForPositiveDiscount() {
        PricingSummary summary = new PricingSummary(BigDecimal.TEN, BigDecimal.ONE, BigDecimal.ZERO, BigDecimal.TEN, 0, "");
        assertTrue(summary.hasDiscount());
    }

    @Test
    void hasDiscountReturnsFalseForZeroDiscount() {
        PricingSummary summary = new PricingSummary(BigDecimal.TEN, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.TEN, 0, "");
        assertFalse(summary.hasDiscount());
    }

    @Test
    void gettersReturnConstructorValues() {
        BigDecimal subtotal = new BigDecimal("10.00");
        BigDecimal discount = new BigDecimal("1.00");
        BigDecimal tax = new BigDecimal("0.50");
        BigDecimal total = new BigDecimal("9.50");
        int points = 10;
        String receipt = "Receipt";
        PricingSummary summary = new PricingSummary(subtotal, discount, tax, total, points, receipt);
        assertAll(
            () -> assertEquals(subtotal, summary.subtotal()),
            () -> assertEquals(discount, summary.discount()),
            () -> assertEquals(tax, summary.tax()),
            () -> assertEquals(total, summary.total()),
            () -> assertEquals(points, summary.loyaltyPoints()),
            () -> assertEquals(receipt, summary.receipt())
        );
    }
}