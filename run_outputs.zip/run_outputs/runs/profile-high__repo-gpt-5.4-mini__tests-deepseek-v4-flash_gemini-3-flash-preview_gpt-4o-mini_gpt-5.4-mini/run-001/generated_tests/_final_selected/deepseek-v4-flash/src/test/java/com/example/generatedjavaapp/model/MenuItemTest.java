package com.example.generatedjavaapp.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class MenuItemTest {

    @Test
    void ofRejectsNullSku() {
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of(null, "Name", "drink", BigDecimal.ONE, true));
    }

    @Test
    void ofRejectsBlankName() {
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("A", " ", "drink", BigDecimal.ONE, true));
    }

    @Test
    void ofRejectsNullCategory() {
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("A", "Name", null, BigDecimal.ONE, true));
    }

    @Test
    void ofRejectsNonPositivePrice() {
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("A", "Name", "drink", BigDecimal.ZERO, true));
        assertThrows(IllegalArgumentException.class, () -> MenuItem.of("A", "Name", "drink", new BigDecimal("-1"), true));
    }

    @Test
    void ofTrimsAndNormalizesFields() {
        MenuItem item = MenuItem.of(" SKU ", " Name ", " DRINK ", new BigDecimal("1.50"), true);
        assertEquals("SKU", item.sku());
        assertEquals("Name", item.name());
        assertEquals("drink", item.category());
    }

    @Test
    void bulkPriceReturnsExtendedForQuantityBelowFive() {
        MenuItem item = MenuItem.of("A", "A", "drink", new BigDecimal("2.00"), true);
        assertEquals(new BigDecimal("6.00"), item.bulkPrice(3));
    }

    @Test
    void bulkPriceAppliesThreePercentDiscountForQuantityFiveToNine() {
        MenuItem item = MenuItem.of("A", "A", "drink", new BigDecimal("2.00"), true);
        BigDecimal expected = new BigDecimal("10.00").multiply(new BigDecimal("0.97"));
        assertEquals(expected, item.bulkPrice(5));
    }

    @Test
    void bulkPriceAppliesFivePercentDiscountForQuantityTenOrMore() {
        MenuItem item = MenuItem.of("A", "A", "drink", new BigDecimal("2.00"), true);
        BigDecimal expected = new BigDecimal("20.00").multiply(new BigDecimal("0.95"));
        assertEquals(expected, item.bulkPrice(10));
    }

    @Test
    void isCategoryMatchesIgnoreCase() {
        MenuItem item = MenuItem.of("A", "A", "Food", BigDecimal.ONE, false);
        assertTrue(item.isCategory("food"));
        assertTrue(item.isCategory("FOOD"));
        assertFalse(item.isCategory("drink"));
    }

    @Test
    void isCategoryReturnsFalseForNull() {
        MenuItem item = MenuItem.of("A", "A", "food", BigDecimal.ONE, false);
        assertFalse(item.isCategory(null));
    }
}