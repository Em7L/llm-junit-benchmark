# generated-java-app

A small, deterministic Java 21 Maven application that models a cafe order pipeline. It validates menu orders, applies discounts, calculates tax and loyalty points, and produces a formatted receipt.

Run it with:

```bash
mvn test
mvn exec:java
```

## Complexity Summary

- Classes: 9
- Total public methods: 28
- Methods with >= 3 branches: 5
- `App`: command-line entry point that builds a sample order and prints a receipt.
- `Catalog`: in-memory menu lookup and aggregation helpers.
- `LineItem`: represents a single ordered item with quantity and notes.
- `MenuItem`: immutable product definition with pricing and category rules.
- `Order`: aggregates line items and customer state for the pricing workflow.
- `OrderPricingService`: orchestrates validation, discounting, tax, loyalty, and receipt creation.
- `OrderRuleEngine`: validation and business-rule enforcement for orders.
- `PriceFormatter`: parses and formats monetary and receipt text values.
- `PricingSummary`: immutable result object holding all computed totals.
