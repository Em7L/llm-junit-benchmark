package com.example.generatedjavaapp.model;

import java.math.BigDecimal;
import java.util.Objects;

public final class MenuItem {
    private final String sku;
    private final String name;
    private final String category;
    private final BigDecimal unitPrice;
    private final boolean taxable;

    private MenuItem(String sku, String name, String category, BigDecimal unitPrice, boolean taxable) {
        this.sku = Objects.requireNonNull(sku, "sku");
        this.name = Objects.requireNonNull(name, "name");
        this.category = Objects.requireNonNull(category, "category");
        this.unitPrice = Objects.requireNonNull(unitPrice, "unitPrice");
        this.taxable = taxable;
    }

    public static MenuItem of(String sku, String name, String category, BigDecimal unitPrice, boolean taxable) {
        if (sku == null || sku.isBlank()) {
            throw new IllegalArgumentException("sku must be provided");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("name must be provided");
        }
        if (category == null || category.isBlank()) {
            throw new IllegalArgumentException("category must be provided");
        }
        if (unitPrice == null || unitPrice.signum() <= 0) {
            throw new IllegalArgumentException("unitPrice must be positive");
        }
        return new MenuItem(sku.trim().toUpperCase(), name.trim(), category.trim().toLowerCase(), unitPrice, taxable);
    }

    public String sku() {
        return sku;
    }

    public String name() {
        return name;
    }

    public String category() {
        return category;
    }

    public BigDecimal unitPrice() {
        return unitPrice;
    }

    public boolean taxable() {
        return taxable;
    }

    public boolean isCategory(String expectedCategory) {
        return expectedCategory != null && category.equalsIgnoreCase(expectedCategory.trim());
    }

    public BigDecimal bulkPrice(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("quantity must be positive");
        }
        BigDecimal extended = unitPrice.multiply(BigDecimal.valueOf(quantity));
        if (quantity >= 10) {
            return extended.multiply(new BigDecimal("0.95"));
        }
        if (quantity >= 5) {
            return extended.multiply(new BigDecimal("0.97"));
        }
        return extended;
    }
}
