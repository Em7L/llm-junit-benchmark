package com.example.generatedjavaapp.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

public final class PriceFormatter {

    public String money(BigDecimal value) {
        if (value == null) {
            throw new IllegalArgumentException("value is required");
        }
        return "$" + value.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    public BigDecimal parseMoney(String text) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("text is required");
        }
        String normalized = text.trim().replace("$", "");
        return new BigDecimal(normalized);
    }

    public String slug(String text) {
        if (text == null || text.isBlank()) {
            return "unknown";
        }
        return text.trim().toLowerCase(Locale.ROOT).replace(' ', '-');
    }

    public String joinLines(String... lines) {
        if (lines == null || lines.length == 0) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (String line : lines) {
            if (line == null || line.isBlank()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(System.lineSeparator());
            }
            builder.append(line);
        }
        return builder.toString();
    }

    public String quantityLabel(int quantity) {
        if (quantity <= 0) {
            return "none";
        }
        if (quantity == 1) {
            return "single";
        }
        if (quantity < 5) {
            return "small";
        }
        return "bulk";
    }
}
