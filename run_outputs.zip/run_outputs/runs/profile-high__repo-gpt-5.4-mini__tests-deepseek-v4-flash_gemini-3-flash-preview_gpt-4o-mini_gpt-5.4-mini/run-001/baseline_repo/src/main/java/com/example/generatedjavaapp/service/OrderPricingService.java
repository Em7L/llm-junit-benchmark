package com.example.generatedjavaapp.service;

import com.example.generatedjavaapp.model.Catalog;
import com.example.generatedjavaapp.model.LineItem;
import com.example.generatedjavaapp.model.MenuItem;
import com.example.generatedjavaapp.model.Order;
import com.example.generatedjavaapp.model.PricingSummary;
import com.example.generatedjavaapp.rules.OrderRuleEngine;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public final class OrderPricingService {
    private final Catalog catalog;
    private final OrderRuleEngine ruleEngine;
    private final PriceFormatter formatter;

    public OrderPricingService(Catalog catalog) {
        this(catalog, new OrderRuleEngine(), new PriceFormatter());
    }

    public OrderPricingService(Catalog catalog, OrderRuleEngine ruleEngine, PriceFormatter formatter) {
        this.catalog = catalog;
        this.ruleEngine = ruleEngine;
        this.formatter = formatter;
    }

    public PricingSummary price(Order order) {
        ruleEngine.ensureValid(order, catalog);

        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal discount = BigDecimal.ZERO;
        BigDecimal taxableBase = BigDecimal.ZERO;
        List<String> receiptLines = new ArrayList<>();

        for (LineItem line : order.items()) {
            MenuItem item = catalog.require(line.sku());
            BigDecimal lineBase = item.bulkPrice(line.quantity());
            BigDecimal lineDiscount = calculateLineDiscount(item, line, lineBase, order);
            subtotal = subtotal.add(lineBase);
            discount = discount.add(lineDiscount);
            if (item.taxable()) {
                taxableBase = taxableBase.add(lineBase.subtract(lineDiscount));
            }
            receiptLines.add(describeLine(item, line, lineBase, lineDiscount));
        }

        BigDecimal afterDiscount = subtotal.subtract(discount);
        BigDecimal tax = calculateTax(afterDiscount, taxableBase, order);
        BigDecimal total = afterDiscount.add(tax).setScale(2, RoundingMode.HALF_UP);
        int loyaltyPoints = calculatePoints(order, total, subtotal, discount);

        receiptLines.add("Subtotal: " + formatter.money(subtotal));
        receiptLines.add("Discount: -" + formatter.money(discount));
        receiptLines.add("Tax: " + formatter.money(tax));
        receiptLines.add("Total: " + formatter.money(total));
        receiptLines.add("Loyalty points: " + loyaltyPoints);

        return new PricingSummary(subtotal, discount, tax, total, loyaltyPoints, formatter.joinLines(receiptLines.toArray(String[]::new)));
    }

    public BigDecimal calculateTax(BigDecimal afterDiscount, BigDecimal taxableBase, Order order) {
        if (afterDiscount == null || taxableBase == null || order == null) {
            throw new IllegalArgumentException("arguments are required");
        }
        BigDecimal rate = order.member() ? new BigDecimal("0.06") : new BigDecimal("0.08");
        if (order.isBulkOrder() && taxableBase.compareTo(new BigDecimal("40.00")) > 0) {
            rate = rate.subtract(new BigDecimal("0.01"));
        }
        if (order.loyaltyTier().equals("GOLD")) {
            rate = rate.subtract(new BigDecimal("0.005"));
        } else if (order.loyaltyTier().equals("SILVER")) {
            rate = rate.subtract(new BigDecimal("0.002"));
        }
        if (rate.signum() < 0) {
            rate = BigDecimal.ZERO;
        }
        return taxableBase.multiply(rate).setScale(2, RoundingMode.HALF_UP);
    }

    public int calculatePoints(Order order, BigDecimal total, BigDecimal subtotal, BigDecimal discount) {
        if (order == null || total == null || subtotal == null || discount == null) {
            throw new IllegalArgumentException("arguments are required");
        }
        int points = order.member() ? 10 : 0;
        points += subtotal.divideToIntegralValue(new BigDecimal("5")).intValue();
        if (discount.compareTo(new BigDecimal("10.00")) >= 0) {
            points += 2;
        }
        if (total.compareTo(new BigDecimal("25.00")) >= 0 && order.isBulkOrder()) {
            points += 4;
        }
        if (order.loyaltyTier().equals("GOLD")) {
            points += 5;
        } else if (order.loyaltyTier().equals("SILVER")) {
            points += 3;
        }
        return points;
    }

    private BigDecimal calculateLineDiscount(MenuItem item, LineItem line, BigDecimal lineBase, Order order) {
        BigDecimal discount = BigDecimal.ZERO;
        if (item.isCategory("drink") && line.quantity() >= 2) {
            discount = lineBase.multiply(new BigDecimal("0.10"));
        }
        if (item.isCategory("food") && order.member() && line.quantity() >= 3) {
            discount = discount.add(lineBase.multiply(new BigDecimal("0.05")));
        }
        if (line.hasNote() && line.note().toLowerCase().contains("no nuts")) {
            discount = discount.add(new BigDecimal("0.15"));
        }
        if (line.quantity() >= 8) {
            discount = discount.add(lineBase.multiply(new BigDecimal("0.03")));
        }
        return discount.min(lineBase).setScale(2, RoundingMode.HALF_UP);
    }

    private String describeLine(MenuItem item, LineItem line, BigDecimal lineBase, BigDecimal lineDiscount) {
        BigDecimal finalPrice = lineBase.subtract(lineDiscount).setScale(2, RoundingMode.HALF_UP);
        return item.name() + " x" + line.quantity() + " (" + formatter.quantityLabel(line.quantity()) + ")"
                + " = " + formatter.money(finalPrice) + (line.hasNote() ? " [" + line.note() + "]" : "");
    }
}
