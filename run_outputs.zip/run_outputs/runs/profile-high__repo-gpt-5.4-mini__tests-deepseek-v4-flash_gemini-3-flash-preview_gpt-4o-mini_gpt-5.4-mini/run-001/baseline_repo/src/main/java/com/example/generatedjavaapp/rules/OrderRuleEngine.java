package com.example.generatedjavaapp.rules;

import com.example.generatedjavaapp.model.Catalog;
import com.example.generatedjavaapp.model.LineItem;
import com.example.generatedjavaapp.model.Order;

import java.util.ArrayList;
import java.util.List;

public final class OrderRuleEngine {

    public List<String> validate(Order order, Catalog catalog) {
        List<String> problems = new ArrayList<>();
        if (order == null) {
            problems.add("order is required");
            return problems;
        }
        if (catalog == null) {
            problems.add("catalog is required");
            return problems;
        }
        if (order.isEmpty()) {
            problems.add("order must contain at least one line item");
        }
        if (order.member() && order.loyaltyTier().equals("STANDARD") && order.itemCount() >= 3) {
            problems.add("standard members with 3+ items must select a tier");
        }
        for (LineItem item : order.items()) {
            if (catalog.find(item.sku()) == null) {
                problems.add("unknown sku: " + item.sku());
            }
            if (item.quantity() > 20) {
                problems.add("quantity too large for sku: " + item.sku());
            }
            if (item.hasNote() && item.note().length() > 30) {
                problems.add("note too long for sku: " + item.sku());
            }
        }
        if (order.isBulkOrder() && order.items().stream().noneMatch(LineItem::isLargeOrderLine)) {
            problems.add("bulk order requires at least one large line item");
        }
        return problems;
    }

    public void ensureValid(Order order, Catalog catalog) {
        List<String> problems = validate(order, catalog);
        if (!problems.isEmpty()) {
            throw new IllegalArgumentException(String.join(", ", problems));
        }
    }

    public boolean qualifiesForMemberPricing(Order order) {
        return order != null && order.member() && !order.loyaltyTier().equals("STANDARD");
    }
}
