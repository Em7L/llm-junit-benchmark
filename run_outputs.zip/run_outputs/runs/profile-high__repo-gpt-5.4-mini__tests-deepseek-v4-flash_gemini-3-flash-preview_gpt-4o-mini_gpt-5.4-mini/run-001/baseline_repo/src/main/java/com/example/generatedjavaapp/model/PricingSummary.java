package com.example.generatedjavaapp.model;

import java.math.BigDecimal;
import java.util.Objects;

public final class PricingSummary {
    private final BigDecimal subtotal;
    private final BigDecimal discount;
    private final BigDecimal tax;
    private final BigDecimal total;
    private final int loyaltyPoints;
    private final String receipt;

    public PricingSummary(BigDecimal subtotal, BigDecimal discount, BigDecimal tax, BigDecimal total, int loyaltyPoints, String receipt) {
        this.subtotal = Objects.requireNonNull(subtotal, "subtotal");
        this.discount = Objects.requireNonNull(discount, "discount");
        this.tax = Objects.requireNonNull(tax, "tax");
        this.total = Objects.requireNonNull(total, "total");
        this.loyaltyPoints = loyaltyPoints;
        this.receipt = Objects.requireNonNull(receipt, "receipt");
    }

    public BigDecimal subtotal() {
        return subtotal;
    }

    public BigDecimal discount() {
        return discount;
    }

    public BigDecimal tax() {
        return tax;
    }

    public BigDecimal total() {
        return total;
    }

    public int loyaltyPoints() {
        return loyaltyPoints;
    }

    public String receipt() {
        return receipt;
    }

    public boolean hasDiscount() {
        return discount.signum() > 0;
    }
}
