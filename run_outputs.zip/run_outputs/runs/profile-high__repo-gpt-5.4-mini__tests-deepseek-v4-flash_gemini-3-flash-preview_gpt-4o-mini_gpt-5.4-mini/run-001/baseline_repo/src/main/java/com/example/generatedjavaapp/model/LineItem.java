package com.example.generatedjavaapp.model;

import java.util.Objects;

public final class LineItem {
    private final String sku;
    private final int quantity;
    private final String note;

    public LineItem(String sku, int quantity, String note) {
        if (sku == null || sku.isBlank()) {
            throw new IllegalArgumentException("sku must be provided");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("quantity must be positive");
        }
        this.sku = sku.trim().toUpperCase();
        this.quantity = quantity;
        this.note = note == null ? "" : note.trim();
    }

    public String sku() {
        return sku;
    }

    public int quantity() {
        return quantity;
    }

    public String note() {
        return note;
    }

    public boolean hasNote() {
        return !note.isBlank();
    }

    public boolean isLargeOrderLine() {
        return quantity >= 5;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LineItem lineItem)) return false;
        return quantity == lineItem.quantity && sku.equals(lineItem.sku) && note.equals(lineItem.note);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sku, quantity, note);
    }
}
