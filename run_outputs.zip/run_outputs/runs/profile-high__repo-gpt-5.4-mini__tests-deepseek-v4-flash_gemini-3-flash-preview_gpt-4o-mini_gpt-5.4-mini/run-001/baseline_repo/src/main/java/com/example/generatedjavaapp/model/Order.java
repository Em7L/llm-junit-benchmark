package com.example.generatedjavaapp.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Order {
    private final String orderId;
    private final String loyaltyTier;
    private final boolean member;
    private final List<LineItem> items;

    public Order(String orderId, String loyaltyTier, boolean member) {
        if (orderId == null || orderId.isBlank()) {
            throw new IllegalArgumentException("orderId must be provided");
        }
        this.orderId = orderId.trim();
        this.loyaltyTier = loyaltyTier == null ? "STANDARD" : loyaltyTier.trim().toUpperCase();
        this.member = member;
        this.items = new ArrayList<>();
    }

    public Order addLine(LineItem item) {
        items.add(Objects.requireNonNull(item, "item"));
        return this;
    }

    public String orderId() {
        return orderId;
    }

    public String loyaltyTier() {
        return loyaltyTier;
    }

    public boolean member() {
        return member;
    }

    public List<LineItem> items() {
        return Collections.unmodifiableList(items);
    }

    public int itemCount() {
        int total = 0;
        for (LineItem item : items) {
            total += item.quantity();
        }
        return total;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public boolean isBulkOrder() {
        return itemCount() >= 8;
    }
}
