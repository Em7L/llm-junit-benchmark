package com.example.generatedjavaapp.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public final class Catalog {
    private final Map<String, MenuItem> bySku;

    public Catalog(Collection<MenuItem> items) {
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("items must not be empty");
        }
        this.bySku = new HashMap<>();
        for (MenuItem item : items) {
            addInternal(item);
        }
    }

    public Catalog(MenuItem... items) {
        this(java.util.List.of(items));
    }

    public MenuItem find(String sku) {
        if (sku == null || sku.isBlank()) {
            return null;
        }
        return bySku.get(sku.trim().toUpperCase());
    }

    public MenuItem require(String sku) {
        MenuItem item = find(sku);
        if (item == null) {
            throw new IllegalArgumentException("Unknown sku: " + sku);
        }
        return item;
    }

    public int size() {
        return bySku.size();
    }

    public boolean containsCategory(String category) {
        if (category == null || category.isBlank()) {
            return false;
        }
        for (MenuItem item : bySku.values()) {
            if (item.isCategory(category)) {
                return true;
            }
        }
        return false;
    }

    private void addInternal(MenuItem item) {
        MenuItem safe = Objects.requireNonNull(item, "item");
        MenuItem previous = bySku.putIfAbsent(safe.sku(), safe);
        if (previous != null) {
            throw new IllegalArgumentException("Duplicate sku: " + safe.sku());
        }
    }
}
