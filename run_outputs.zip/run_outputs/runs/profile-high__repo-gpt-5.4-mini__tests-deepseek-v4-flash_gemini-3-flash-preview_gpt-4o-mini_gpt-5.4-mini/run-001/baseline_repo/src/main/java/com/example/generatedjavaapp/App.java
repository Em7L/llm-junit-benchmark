package com.example.generatedjavaapp;

import com.example.generatedjavaapp.model.Catalog;
import com.example.generatedjavaapp.model.LineItem;
import com.example.generatedjavaapp.model.MenuItem;
import com.example.generatedjavaapp.model.Order;
import com.example.generatedjavaapp.service.OrderPricingService;

import java.math.BigDecimal;

public final class App {

    public static void main(String[] args) {
        Catalog catalog = new Catalog(
                MenuItem.of("COFFEE", "House Coffee", "drink", new BigDecimal("3.50"), true),
                MenuItem.of("TEA", "Green Tea", "drink", new BigDecimal("2.80"), true),
                MenuItem.of("MUFFIN", "Blueberry Muffin", "food", new BigDecimal("4.20"), false),
                MenuItem.of("SANDWICH", "Turkey Sandwich", "food", new BigDecimal("8.90"), false),
                MenuItem.of("COOKIE", "Chocolate Cookie", "snack", new BigDecimal("1.90"), false)
        );

        Order order = new Order("C-1001", "STANDARD", true)
                .addLine(new LineItem("COFFEE", 2, "extra hot"))
                .addLine(new LineItem("MUFFIN", 3, ""))
                .addLine(new LineItem("COOKIE", 5, "no nuts"));

        OrderPricingService service = new OrderPricingService(catalog);
        System.out.println(service.price(order).receipt());
    }
}
